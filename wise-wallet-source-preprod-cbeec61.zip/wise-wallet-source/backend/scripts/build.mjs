import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=new URL('../',import.meta.url);
for(const dir of ['runtime','commands']){
  await mkdir(new URL(`dist/${dir}/`,root),{recursive:true});
  for(const name of await readdir(new URL(`${dir}/`,root))){
    if(!name.endsWith('.mjs'))continue;
    const source=(await readFile(new URL(`${dir}/${name}`,root),'utf8')).replaceAll('../../packages/finance-domain/','../domain/');
    await writeFile(new URL(`dist/${dir}/${name}`,root),source);
  }
}
await mkdir(new URL('dist/domain/',root),{recursive:true});
await writeFile(new URL('dist/domain/index.mjs',root),await readFile(new URL('../packages/finance-domain/index.mjs',root)));
await writeFile(new URL('dist/domain/bulk-transactions.mjs',root),await readFile(new URL('../packages/finance-domain/bulk-transactions.mjs',root)));
console.log(`Backend prepared: ${fileURLToPath(new URL('dist/',root))}`);
