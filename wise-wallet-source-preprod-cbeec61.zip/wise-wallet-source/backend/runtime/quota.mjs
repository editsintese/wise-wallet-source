import {createHash} from 'node:crypto';
import {CommandError} from '../commands/transfer.mjs';
export function createQuota({db,now=()=>Date.now(),limit=30}) {
  return uid=>db.runTransaction(async tx=>{
    const ref=db.doc(`commandQuotas/${createHash('sha256').update(uid).digest('hex')}`);
    const snapshot=await tx.get(ref),time=now(),prior=snapshot.exists?snapshot.data():null;
    const same=prior&&time>=prior.startedAtMs&&time-prior.startedAtMs<60000;
    const count=same?prior.count:0;
    if(count>=limit)throw new CommandError('rate-limited');
    tx.set(ref,{startedAtMs:same?prior.startedAtMs:time,count:count+1});
  });
}
