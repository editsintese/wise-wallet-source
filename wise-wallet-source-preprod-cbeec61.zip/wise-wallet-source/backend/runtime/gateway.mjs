import {CommandError} from '../commands/transfer.mjs';

// Mirrors the two verified identities allowed by the transitional family-wallet rules.
const familyWalletEmails=new Set(['family-user@example.invalid', 'family-user@example.invalid']);
const mapped={ 'bank-reference-conflict':'failed-precondition','invalid-argument':'invalid-argument',unauthenticated:'unauthenticated','permission-denied':'permission-denied','not-found':'not-found','failed-precondition':'failed-precondition','version-conflict':'aborted','idempotency-conflict':'already-exists','invalid-invitation':'failed-precondition','already-exists':'already-exists','already-member':'already-exists','rate-limited':'resource-exhausted' };

export function createGateway({operations,consumeQuota,HttpsError,requireAppCheck=true}) {
  return async request=>{
    if(!request.auth?.uid)throw new HttpsError('unauthenticated','Entre na sua conta.');
    if(requireAppCheck&&!request.app)throw new HttpsError('failed-precondition','Não foi possível validar o aplicativo.');
    if(request.auth.token?.firebase?.sign_in_provider==='password'&&request.auth.token.email_verified!==true)throw new HttpsError('permission-denied','Confirme seu e-mail para continuar.');
    const data=request.data;
    if(!data||typeof data!=='object'||Array.isArray(data)||Object.keys(data).length!==3||!['schemaVersion','operation','payload'].every(k=>Object.hasOwn(data,k))||data.schemaVersion!==1||typeof data.operation!=='string'||!Object.hasOwn(operations,data.operation))throw new HttpsError('invalid-argument','Comando inválido.');
    if(data.payload && data.payload.householdId==='family-wallet' && (request.auth.token?.email_verified!==true || !familyWalletEmails.has(request.auth.token?.email)))throw new HttpsError('permission-denied','Esta conta não tem acesso à carteira.');
    let size;try{size=Buffer.byteLength(JSON.stringify(data));}catch{throw new HttpsError('invalid-argument','Comando inválido.');}
    const maximumBytes=data.operation==='bulkTransactions'?128*1024:4096;
    if(size>maximumBytes)throw new HttpsError('invalid-argument','Comando acima do limite.');
    try{
      await consumeQuota(request.auth.uid);
      return await operations[data.operation](request.auth.uid,data.payload);
    }catch(error){
      if(error instanceof CommandError&&mapped[error.code])throw new HttpsError(mapped[error.code],'Não foi possível concluir o comando.',{reason:error.code});
      // Never return SDK messages, payloads, tokens or personal data.
      throw new HttpsError('internal','Não foi possível concluir. Tente novamente.');
    }
  };
}
