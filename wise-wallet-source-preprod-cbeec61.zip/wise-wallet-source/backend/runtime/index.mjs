import {initializeApp} from 'firebase-admin/app';
import {getFirestore,FieldValue} from 'firebase-admin/firestore';
import {onCall,HttpsError} from 'firebase-functions/v2/https';
import {defineSecret} from 'firebase-functions/params';
import {createHouseholdService} from '../commands/households.mjs';
import {createMembershipHandler} from '../commands/membership.mjs';
import {createTransferHandler} from '../commands/transfer.mjs';
import {createAccountHandler} from '../commands/accounts.mjs';
import {createManualEntryHandler} from '../commands/manual-entry.mjs';
import {createBulkTransactionHandler} from '../commands/bulk-transactions.mjs';
import {createCancelManualInstallmentsHandler} from '../commands/cancel-manual-installments.mjs';
import {createAmendManualHandler} from '../commands/amend-manual.mjs';
import {createTransactionHandler} from '../commands/transactions.mjs';
import {createInvestmentHandler} from '../commands/investments.mjs';
import {createCardHandler} from '../commands/cards.mjs';
import {createCardPurchaseHandler} from '../commands/card-purchases.mjs';
import {createRecurrenceHandler} from '../commands/recurrences.mjs';
import {createGoalHandler} from '../commands/goals.mjs';
import {createCardPaymentHandler,createCardPaymentReversalHandler} from '../commands/card-payments.mjs';
import {createCancelCardInstallmentsHandler} from '../commands/cancel-card-installments.mjs';
import {createRecurrenceOccurrenceHandler} from '../commands/recurrence-occurrences.mjs';
import {createRecurrenceRuleHandler} from '../commands/recurrence-rules.mjs';
import {createRecurrenceForecastHandler} from '../commands/recurrence-forecast.mjs';
import {createCardRecurrenceHandler} from '../commands/card-recurrences.mjs';
import {createPartialCardPaymentHandler} from '../commands/partial-card-payments.mjs';
import {createGateway} from './gateway.mjs';
import {createQuota} from './quota.mjs';

initializeApp();
const secret=defineSecret('INVITATION_SECRET_HEX');
const db=getFirestore(),serverTimestamp=()=>FieldValue.serverTimestamp();
let gateway;
const emulator=process.env.FUNCTIONS_EMULATOR==='true';
export const walletCommand=onCall({region:'southamerica-east1',enforceAppCheck:!emulator,secrets:[secret],maxInstances:5,timeoutSeconds:30},async request=>{
  if(!gateway){
    const encoded=secret.value();
    if(!/^[a-fA-F0-9]{64}$/.test(encoded))throw new HttpsError('internal','Serviço indisponível.');
    const households=createHouseholdService({db,serverTimestamp,invitationSecret:Buffer.from(encoded,'hex')});
    gateway=createGateway({HttpsError,consumeQuota:createQuota({db}),requireAppCheck:!emulator,operations:{
      createHousehold:households.create,inviteMember:households.invite,acceptInvitation:households.accept,
      revokeInvitation:households.revoke,transferOwnership:households.transferOwnership,
      manageAccount:createAccountHandler({db,serverTimestamp}),
      manageInvestment:createInvestmentHandler({db,serverTimestamp}),
      createManualEntry:createManualEntryHandler({db,serverTimestamp}),
      bulkTransactions:createBulkTransactionHandler({db,serverTimestamp}),
      amendManualEntry:createAmendManualHandler({db,serverTimestamp}),
      cancelManualInstallments:createCancelManualInstallmentsHandler({db,serverTimestamp}),
      manageTransaction:createTransactionHandler({db,serverTimestamp}),
      manageRecurrenceOccurrence:createRecurrenceOccurrenceHandler({db,serverTimestamp}),
      manageRecurrenceRule:createRecurrenceRuleHandler({db,serverTimestamp}),
      editRecurrenceForecast:createRecurrenceForecastHandler({db,serverTimestamp}),
      manageCardRecurrence:createCardRecurrenceHandler({db,serverTimestamp}),
      settleCardInvoice:createCardPaymentHandler({db,serverTimestamp}),
      managePartialCardPayment:createPartialCardPaymentHandler({db,serverTimestamp}),
      manageCardPurchase:createCardPurchaseHandler({db,serverTimestamp}),
      manageCard:createCardHandler({db,serverTimestamp}),
      manageGoal:createGoalHandler({db,serverTimestamp}),
      cancelCardInstallments:createCancelCardInstallmentsHandler({db,serverTimestamp}),
      reverseCardPayment:createCardPaymentReversalHandler({db,serverTimestamp}),
      manageRecurrence:createRecurrenceHandler({db,serverTimestamp}),
      updateMembership:createMembershipHandler({db,serverTimestamp}),transfer:createTransferHandler({db,serverTimestamp}),
    }});
  }
  return gateway(request);
});
