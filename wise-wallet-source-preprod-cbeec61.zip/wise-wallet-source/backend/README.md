# Wise Wallet — backend v1

A base implementa comandos de família, membros, contas, receitas/despesas e transferências, com entrada Firebase callable e regras de leitura por associação. O pacote foi validado localmente; não foi publicado nem conectado ao protótipo ou aos dados reais.

## Entrada e segurança

`runtime/index.mjs` exporta `walletCommand`, callable de segunda geração com App Check obrigatório, região southamerica-east1, timeout de 30 segundos e até cinco instâncias. Envelope: `{schemaVersion:1, operation, payload}`. O UID vem exclusivamente da autenticação verificada. Login por senha exige email verificado. O gateway rejeita operações desconhecidas, campos extras e envelopes acima de 4096 bytes; erros internos não expõem mensagens de SDK, tokens ou payloads.

`runtime/quota.mjs` limita a 30 tentativas por UID a cada janela de 60 segundos, usando transação Firestore compartilhada entre instâncias. Reenvios consomem quota. Os recibos financeiros não expiram automaticamente; remover recibos sem política de rejeição de comandos antigos reabriria duplicação.

| Operação | Comportamento |
|---|---|
| createHousehold | Cria família BRL/America/Sao_Paulo, owner e índice pessoal atomicamente; repetição não duplica |
| inviteMember | Owner/admin convidam member/viewer por token opaco válido por 48 horas |
| acceptInvitation | Consome convite uma única vez e cria associação/índice na mesma transação |
| revokeInvitation | Revoga convite pendente; não remove membros já admitidos |
| transferOwnership | Troca owner e converte o anterior em admin, com versão esperada e recibo |
| updateMembership | Altera papel ou remove acesso preservando fatos financeiros; admin não administra pares ou owner |
| manageAccount | Owner/admin criam, editam, arquivam/restauram contas e corrigem saldo inicial com histórico |
| manageTransaction | Owner/admin/member criam, corrigem, liquidam, cancelam e arquivam/restauram receitas/despesas manuais |
| settleCardInvoice | Debita uma conta canônica e registra uma única liquidação para o total exato da fatura |
| transfer | Move centavos entre duas contas manuais com duas pernas vinculadas e efeito familiar zero |

Os contratos estritos estão nos módulos `commands/`. Transferências usam contas canônicas com schemaVersion 1, version >= 1, currency BRL e balanceCents inteiro seguro. Rejeitam conta arquivada, versões antigas, overflow e data futura; não executam transferências bancárias. Saldo negativo é permitido em contas manuais. O fuso padrão deste primeiro comando é America/Sao_Paulo; a composição futura deve atender famílias com outro fuso.

O [contrato de receitas/despesas](../docs/ios/transactions-contract.md) separa previsão, liquidação e arquivamento. Correções financeiras acrescentam reversão e novo efeito datados; revisões ficam privadas do servidor. A liquidação de fatura soma as compras do cartão e da competência no servidor, rejeita duplicidade e atualiza conta, livro-razão, auditoria e recibo na mesma transação.

## Convites e segredos

INVITATION_SECRET_HEX deve conter 64 dígitos hexadecimais de segredo aleatório, provisionado por ambiente no Secret Manager. Tokens são derivados por HMAC e somente seu hash é persistido como ID; repetição não altera o prazo. Não registrar retornos de inviteMember em logs. Nenhum email ou mensagem é enviado automaticamente.

Rotação de chave ainda exige protocolo versionado antes de produção: trocar a chave diretamente muda o token de uma repetição. Associações removidas não são reativadas por convite. Reativação, exclusão de conta e encerramento familiar ainda precisam de comandos próprios.

## Regras e dados

`backend/firestore.rules` nega todas as escritas do cliente. Leituras financeiras exigem associação ativa com papel conhecido; listagens exigem limit <= 100. Convites, recibos, auditoria e quotas são privados do servidor. Índices pessoais de famílias só são legíveis pelo próprio usuário. Preferências e notificações permanecem negadas até receberem contratos específicos.

As regras e configuração da raiz, usadas pela web atual, permanecem separadas. Não aplicar o schema novo sobre dados legados sem migrador e reconciliação. O comando de contas está disponível no gateway; a integração com a interface permanece pendente. Ver [contrato de contas](../docs/ios/accounts-contract.md).

## Dependências e execução

Backend tem package.json, pnpm-workspace.yaml e pnpm-lock.yaml próprios. Runtime declarado: Node 22. Testes de emulador exigem Java 21.

1. `pnpm --dir backend install --frozen-lockfile`
2. `node backend/scripts/build.mjs`
3. `node --test backend/tests/*.test.mjs tests/finance-domain.test.mjs tests/legacy-audit.test.mjs`
4. `pnpm --dir backend run test:rules`

O build copia código e domínio canônico para dist, de modo que a função não dependa de arquivos externos ao diretório publicado. Os testes usam apenas demo-wise-wallet e Firestore em 127.0.0.1:8087, e recusam rodar sem FIRESTORE_EMULATOR_HOST.

Neste Windows, Java portátil e emulador estão em backend/.runtime, ignorado pelo Git. Adicionar seu diretório bin ao PATH e definir FIREBASE_EMULATORS_PATH para backend/.runtime/emulators ao repetir localmente. Não foi instalado Java globalmente. Os testes locais usam Node 24; Node 22 está configurado no workflow e ainda precisa de execução em CI.

## Evidências e limites

Em 2026-09-06 passaram 47 testes unitários e oito testes de integração no Firestore Emulator 1.22.0. Integração cobre quatro papéis, membro removido, acesso anônimo, outra família, escrita direta, paginação, dados privados, índice pessoal, cinco transferências concorrentes com um único efeito e quota concorrente. Também cobre criação concorrente de conta, transferência, correção do saldo inicial, arquivamento e restauração preservando saldos. Receitas/despesas têm ciclo completo, reenvios simultâneos e conflito entre duas intenções distintas validados no Firestore. O export walletCommand foi carregado com o SDK oficial após geração do pacote.

`.github/workflows/backend.yml` prepara build e testes em PRs e execução manual, sem deploy automático. O workflow não foi enviado ao GitHub nem executado remotamente nesta sessão. App Check real e transporte callable ainda precisam de testes no ambiente de homologação; testes de Firestore não demonstram atestação real do aplicativo. Também faltam segredos e projetos separados, integração do cliente, migração, operação/alertas, backup e validação nativa. O gate global de backend continua aberto.

Referências: [callable Firebase](https://firebase.google.com/docs/functions/callable), [testes de Rules](https://firebase.google.com/docs/rules/unit-tests), [transações Firestore](https://firebase.google.com/docs/firestore/manage-data/transactions).
