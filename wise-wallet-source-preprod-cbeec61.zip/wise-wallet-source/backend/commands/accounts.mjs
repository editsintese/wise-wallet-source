import {createHash} from 'node:crypto';
import {assertCents,civilDate,sumCents} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';
const fail=c=>{throw new CommandError(c);};
const hash=s=>createHash('sha256').update(s).digest('hex');
const fields=(x,names)=>{if(!x||typeof x!=='object'||Array.isArray(x)||Object.keys(x).length!==names.length||names.some(k=>!Object.hasOwn(x,k)))fail('invalid-argument');};
const id=x=>{if(typeof x!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(x))fail('invalid-argument');return x;};
const text=(x,max)=>{if(typeof x!=='string'||!x.trim()||x.length>max)fail('invalid-argument');return x.trim();};
const version=x=>{if(!Number.isSafeInteger(x)||x<1||x>=Number.MAX_SAFE_INTEGER)fail('invalid-argument');return x;};
const type=x=>{if(!['checking','savings','cash','other','benefit'].includes(x))fail('invalid-argument');return x;};

export function createAccountHandler({db,serverTimestamp,today=timeZone=>new Intl.DateTimeFormat('en-CA',{timeZone}).format(new Date())}) {
  return async(uid,input)=>{
    if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
    fields(input,['householdId','idempotencyKey','action','payload']);const householdId=id(input.householdId);id(input.idempotencyKey);
    const p=input.payload;let payload;
    if(input.action==='create'){
      fields(p,['name','type','openingBalanceCents','openingDate','currency']);
      try{assertCents(p.openingBalanceCents);civilDate(p.openingDate);}catch{fail('invalid-argument');}
      if(p.currency!=='BRL')fail('invalid-argument');payload={name:text(p.name,80),type:type(p.type),openingBalanceCents:p.openingBalanceCents,openingDate:p.openingDate,currency:'BRL'};
    }else if(input.action==='update'){
      const withOpening=Object.hasOwn(p||{},'openingBalanceCents')||Object.hasOwn(p||{},'reason');
      fields(p,withOpening?['accountId','expectedVersion','name','type','openingBalanceCents','reason']:['accountId','expectedVersion','name','type']);
      payload={accountId:id(p.accountId),expectedVersion:p.expectedVersion===0?0:version(p.expectedVersion),name:text(p.name,80),type:type(p.type)};
      if(withOpening){try{assertCents(p.openingBalanceCents);}catch{fail('invalid-argument');}payload.openingBalanceCents=p.openingBalanceCents;payload.reason=text(p.reason,240);}
    }else if(['archive','restore'].includes(input.action)){
      fields(p,['accountId','expectedVersion']);payload={accountId:id(p.accountId),expectedVersion:p.expectedVersion===0?0:version(p.expectedVersion)};
    }else if(input.action==='correctOpening'){
      fields(p,['accountId','expectedVersion','openingBalanceCents','reason']);try{assertCents(p.openingBalanceCents);}catch{fail('invalid-argument');}
      payload={accountId:id(p.accountId),expectedVersion:p.expectedVersion===0?0:version(p.expectedVersion),openingBalanceCents:p.openingBalanceCents,reason:text(p.reason,240)};
    }else fail('invalid-argument');
    const root=`households/${householdId}`,ref=p=>db.doc(p),commandId=hash(JSON.stringify([uid,input.idempotencyKey]));
    const fingerprint=hash(JSON.stringify(['accounts',householdId,input.action,payload]));
    return db.runTransaction(async tx=>{
      const member=await tx.get(ref(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin'].includes(member.data().role))fail('permission-denied');
      const receiptRef=ref(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);
      if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
      const household=await tx.get(ref(root));if(!household.exists)fail('not-found');
      const accountId=input.action==='create'?commandId:payload.accountId,accountRef=ref(`${root}/accounts/${accountId}`);
      const snapshot=await tx.get(accountRef),at=serverTimestamp();let result,entry;
      if(input.action==='create'){
        if(snapshot.exists)fail('already-exists');
        let cutoff;try{cutoff=civilDate(today(household.data().timeZone));}catch{fail('failed-precondition');}if(payload.openingDate>cutoff)fail('failed-precondition');
        tx.create(accountRef,{schemaVersion:1,version:1,...payload,balanceCents:payload.openingBalanceCents,openingBalanceVersion:1,archivedAt:null,createdBy:uid,createdAt:at,updatedAt:at});
        result={accountId,version:1};entry={type:'openingBalance',amountCents:payload.openingBalanceCents,effectiveDate:payload.openingDate,openingBalanceVersion:1};
      }else{
        if(!snapshot.exists)fail('not-found');const account=snapshot.data();
        if(account.schemaVersion!==1){
          if(account.schemaVersion!=null||account.version!=null||account.balanceCents!=null||account.openingBalanceCents!=null||!Number.isSafeInteger(Math.round((account.openingBalance??0)*100))||Math.abs((account.openingBalance??0)-Math.round((account.openingBalance??0)*100)/100)>1e-7)fail('failed-precondition');
          const legacyRevision=account.legacyRevision??0;if(!Number.isSafeInteger(legacyRevision)||legacyRevision<0||legacyRevision>=Number.MAX_SAFE_INTEGER||legacyRevision!==payload.expectedVersion)fail('version-conflict');
          const archived=account.archived===true||account.archivedAt!=null;if(input.action==='restore'?!archived:archived)fail('failed-precondition');
          const patch={legacyRevision:legacyRevision+1,accountManaged:true,updatedAt:at,updatedBy:uid};
          if(input.action==='update')Object.assign(patch,{name:payload.name,type:payload.type});
          if(Object.hasOwn(payload,'openingBalanceCents'))patch.openingBalance=payload.openingBalanceCents/100;
          if(input.action==='archive')Object.assign(patch,{archived:true,archivedAt:at});if(input.action==='restore')Object.assign(patch,{archived:false,archivedAt:null});
          tx.update(accountRef,patch);tx.create(ref(`${root}/accounts/${accountId}/revisions/legacy-${patch.legacyRevision}`),{previous:account,next:{...account,...patch},action:input.action,reason:payload.reason??null,commandId});
          const result={accountId,version:null,legacyRevision:patch.legacyRevision};tx.create(ref(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`account.${input.action}`,actorId:uid,accountId,createdAt:at});tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
        }
        if(account.currency!=='BRL'||!Number.isSafeInteger(account.version)||account.version<1||account.version>=Number.MAX_SAFE_INTEGER)fail('failed-precondition');
        if(account.version!==payload.expectedVersion)fail('version-conflict');
        if(input.action==='restore'?account.archivedAt==null:account.archivedAt!=null)fail('failed-precondition');
        const patch={version:account.version+1,updatedAt:at,updatedBy:uid};
        if(input.action==='update'){
          patch.name=payload.name;patch.type=payload.type;
          if(Object.hasOwn(payload,'openingBalanceCents')&&payload.openingBalanceCents!==account.openingBalanceCents){
            try{
              const previousOpeningBalance=assertCents(account.openingBalanceCents);
              const previousOpeningVersion=account.openingBalanceVersion==null?1:version(account.openingBalanceVersion);
              const effectiveDate=account.openingDate==null||account.openingDate===''?civilDate(today(household.data().timeZone)):civilDate(account.openingDate);
              patch.balanceCents=sumCents([assertCents(account.balanceCents),payload.openingBalanceCents,-previousOpeningBalance]);
              patch.openingBalanceCents=payload.openingBalanceCents;patch.openingBalanceVersion=previousOpeningVersion+1;
              entry={type:'openingBalanceAdjustment',amountCents:sumCents([payload.openingBalanceCents,-previousOpeningBalance]),effectiveDate,openingBalanceVersion:patch.openingBalanceVersion,reason:payload.reason};
            }catch{fail('failed-precondition');}
          }
        }
        if(input.action==='archive')patch.archivedAt=at;
        if(input.action==='restore')patch.archivedAt=null;
        if(input.action==='correctOpening'){
          try{
            const previousOpeningBalance=assertCents(account.openingBalanceCents);
            const previousOpeningVersion=account.openingBalanceVersion==null?1:version(account.openingBalanceVersion);
            const effectiveDate=account.openingDate==null||account.openingDate===''?civilDate(today(household.data().timeZone)):civilDate(account.openingDate);
            patch.balanceCents=sumCents([assertCents(account.balanceCents),payload.openingBalanceCents,-previousOpeningBalance]);
            patch.openingBalanceCents=payload.openingBalanceCents;patch.openingBalanceVersion=previousOpeningVersion+1;
            entry={type:'openingBalanceAdjustment',amountCents:sumCents([payload.openingBalanceCents,-previousOpeningBalance]),effectiveDate,openingBalanceVersion:patch.openingBalanceVersion,reason:payload.reason};
          }catch{fail('failed-precondition');}
        }
        if(Object.hasOwn(patch,'openingBalanceCents')&&account.bankCheckedAt&&Number.isSafeInteger(account.bankBalanceCents))patch.bankBalanceStale=true;
        tx.update(accountRef,patch);result={accountId,version:patch.version};
      }
      if(entry)tx.create(ref(`${root}/ledgerEntries/${commandId}`),{schemaVersion:1,...entry,accountId,currency:'BRL',createdBy:uid,createdAt:at});
      tx.create(ref(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`account.${input.action}`,actorId:uid,accountId,createdAt:at});
      tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
    });
  };
}
