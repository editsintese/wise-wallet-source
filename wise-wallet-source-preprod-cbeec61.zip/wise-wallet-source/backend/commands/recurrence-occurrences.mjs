import {cashReferencePatch} from './cash-reference.mjs';
import {createHash} from 'node:crypto';
import {assertCents,civilDate,sumCents,weeklyDatesForMonth} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const id=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))fail('invalid-argument');return value;};
const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))fail('invalid-argument');};
const ver=value=>{if(value!==null&&(!Number.isSafeInteger(value)||value<1||value>=Number.MAX_SAFE_INTEGER))fail('invalid-argument');return value;};
const date=value=>{try{return civilDate(value);}catch{fail('invalid-argument');}};
const occurrenceKey=value=>{if(typeof value==='string'&&/^\d{4}-(0[1-9]|1[0-2])$/.test(value))return value;return date(value);};
export function activeInMonth(rule,m,{allowCard=false}={}){if(rule.active===false||(!allowCard&&rule.cardId))return false;const start=String(rule.startDate||'').slice(0,7),end=String(rule.endDate||'').slice(0,7);if((start&&!/^\d{4}-(0[1-9]|1[0-2])$/.test(start))||(end&&!/^\d{4}-(0[1-9]|1[0-2])$/.test(end))||(start&&m<start)||(end&&m>end))return false;const frequency=String(rule.frequency||'monthly').toLowerCase();if(frequency==='weekly'){try{return weeklyDatesForMonth(rule.startDate,m,rule.endDate||'').length>0;}catch{return false;}}if(!['monthly','yearly','annual','anual'].includes(frequency))return false;if(['yearly','annual','anual'].includes(frequency)){const selected=(Array.isArray(rule.monthsOfYear)?rule.monthsOfYear:[]).map(Number).filter(n=>n>=1&&n<=12);return selected.length?selected.includes(Number(m.slice(5))):(!start||m.slice(5)===start.slice(5));}return true;}
export function createRecurrenceOccurrenceHandler({db,serverTimestamp,today=timeZone=>new Intl.DateTimeFormat('en-CA',{timeZone}).format(new Date())}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  exact(input,['householdId','idempotencyKey','action','payload']);const householdId=id(input.householdId),key=id(input.idempotencyKey),action=input.action,p=input.payload;
  if(action==='settle'||action==='confirm')exact(p,['recurrenceId','month','accountId','amountCents','date','expectedAccountVersion']);else if(action==='undo')exact(p,['recurrenceId','month','expectedAccountVersion','expectedTransactionVersion']);else fail('invalid-argument');
  const recurrenceId=id(p.recurrenceId),occurrenceMonth=occurrenceKey(p.month),expectedAccountVersion=ver(p.expectedAccountVersion);let accountId,amountCents,effectiveDate,expectedTransactionVersion;const confirming=action==='confirm';
  if(action!=='undo'){accountId=id(p.accountId);amountCents=p.amountCents;try{assertCents(amountCents);}catch{fail('invalid-argument');}if(amountCents<=0)fail('invalid-argument');effectiveDate=date(p.date);}else expectedTransactionVersion=ver(p.expectedTransactionVersion);
  const root=`households/${householdId}`,commandId=hash([uid,key]),fingerprint=hash(['recurrence-occurrence',householdId,action,p]);
  return db.runTransaction(async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const recurrenceRef=db.doc(`${root}/recurrences/${recurrenceId}`),recurrenceSnapshot=await tx.get(recurrenceRef),household=await tx.get(db.doc(root));if(!recurrenceSnapshot.exists||!household.exists)fail('not-found');
   const recurrence=recurrenceSnapshot.data();if(recurrence.cardId)fail('failed-precondition');const months=Array.isArray(recurrence.settledMonths)?recurrence.settledMonths:[],links=recurrence.occurrenceTransactions&&typeof recurrence.occurrenceTransactions==='object'&&!Array.isArray(recurrence.occurrenceTransactions)?{...recurrence.occurrenceTransactions}:{};
   const pending=recurrence.pendingOccurrenceTransactions&&typeof recurrence.pendingOccurrenceTransactions==='object'&&!Array.isArray(recurrence.pendingOccurrenceTransactions)?{...recurrence.pendingOccurrenceTransactions}:{};
   let transactionId,old,transactionRef,pendingOld;
   if(action!=='undo'){
    const existing=await tx.get(db.collection(`${root}/transactions`).where('recurrenceId','==',recurrenceId));
    const matching=existing.docs.filter(entry=>{const row=entry.data();return row.occurrenceMonth===occurrenceMonth&&row.status!=='cancelled'&&row.deletedAt==null&&row.archived!==true&&row.archivedAt==null;});
    if(months.includes(occurrenceMonth)||links[occurrenceMonth])fail('failed-precondition');
    if(confirming&&(pending[occurrenceMonth]||matching.length))fail('failed-precondition');
    if(pending[occurrenceMonth]){
     transactionId=id(pending[occurrenceMonth]);
     if(matching.length!==1||matching[0].id!==transactionId)fail('failed-precondition');
     pendingOld=matching[0].data();
     if(pendingOld.status!=='planned'||pendingOld.recurrencePending!==true||(!pendingOld.manualEntryId&&!pendingOld.occurrenceRegistrationId)||pendingOld.accountId!==accountId||pendingOld.balanceImpact===false||pendingOld.historicalOnly===true||pendingOld.cardId||!['income','expense'].includes(pendingOld.type||pendingOld.kind))fail('failed-precondition');
     const scheduled=date(pendingOld.scheduledDate);
     if(occurrenceMonth!==(occurrenceMonth.length===10?scheduled:scheduled.slice(0,7)))fail('failed-precondition');
     if(pendingOld.schemaVersion===1){ver(pendingOld.version);if(pendingOld.version==null||pendingOld.currency!=='BRL'||pendingOld.settlementDate!=null||!Number.isSafeInteger(pendingOld.amountCents)||pendingOld.amountCents<=0)fail('failed-precondition');}
     else if(pendingOld.schemaVersion!=null||pendingOld.amountCents!=null||typeof pendingOld.amount!=='number'||pendingOld.amount<=0||Math.abs(pendingOld.amount-Math.round(pendingOld.amount*100)/100)>1e-7||pendingOld.paidAt!=null)fail('failed-precondition');
     transactionRef=db.doc(`${root}/transactions/${transactionId}`);
    }else{
     if(matching.length)fail('failed-precondition');
     const weekly=String(recurrence.frequency||'monthly').toLowerCase()==='weekly';
     if(weekly){let dates;try{dates=weeklyDatesForMonth(recurrence.startDate,occurrenceMonth.slice(0,7),recurrence.endDate||'');}catch{fail('failed-precondition');}if(occurrenceMonth.length!==10||!dates.includes(occurrenceMonth)||months.includes(occurrenceMonth.slice(0,7))||links[occurrenceMonth.slice(0,7)])fail('failed-precondition');}
     else if(occurrenceMonth.length!==7)fail('failed-precondition');
     if(!activeInMonth(recurrence,occurrenceMonth.slice(0,7))||!['income','expense'].includes(recurrence.kind))fail('failed-precondition');
     if(confirming){const month=occurrenceMonth.slice(0,7),year=Number(month.slice(0,4)),number=Number(month.slice(5)),anchor=Math.max(1,Math.min(31,Number(recurrence.dueDay||String(recurrence.startDate||'').slice(8,10))||1)),last=new Date(Date.UTC(year,number,0)).getUTCDate(),scheduled=weekly?occurrenceMonth:`${month}-${String(Math.min(anchor,last)).padStart(2,'0')}`;if(effectiveDate!==scheduled)fail('invalid-argument');}
     transactionId=commandId;transactionRef=db.doc(`${root}/transactions/${transactionId}`);if((await tx.get(transactionRef)).exists)fail('already-exists');
    }
   }
   else {if(!months.includes(occurrenceMonth)||!links[occurrenceMonth]||typeof links[occurrenceMonth]!=='string')fail('failed-precondition');transactionId=id(links[occurrenceMonth]);transactionRef=db.doc(`${root}/transactions/${transactionId}`);const snapshot=await tx.get(transactionRef);if(!snapshot.exists)fail('not-found');old=snapshot.data();if(old.status!=='realized'||old.cardId||old.historicalOnly===true||old.balanceImpact===false||!['income','expense'].includes(old.type||old.kind))fail('failed-precondition');if(old.recurrenceId!==recurrenceId||old.occurrenceMonth!==occurrenceMonth)fail('failed-precondition');accountId=id(old.accountId);effectiveDate=date(old.settlementDate||old.paidAt||old.transactionDate);amountCents=Number.isSafeInteger(old.amountCents)?old.amountCents:Math.round(Number(old.amount)*100);try{assertCents(amountCents);}catch{fail('failed-precondition');}if(amountCents<=0||(!Number.isSafeInteger(old.amountCents)&&(!Number.isFinite(old.amount)||Math.abs(old.amount-amountCents/100)>1e-7)))fail('failed-precondition');if(old.schemaVersion===1?old.version!==expectedTransactionVersion:expectedTransactionVersion!==null)fail('version-conflict');}
   const accountRef=db.doc(`${root}/accounts/${accountId}`),accountSnapshot=await tx.get(accountRef);if(!accountSnapshot.exists)fail('not-found');const account=accountSnapshot.data(),legacy=account.schemaVersion!==1;if(account.archived===true||account.archivedAt!=null||(!legacy&&account.currency!=='BRL'))fail('failed-precondition');if(legacy?expectedAccountVersion!==null:account.version!==expectedAccountVersion)fail('version-conflict');
   if(pendingOld&&((pendingOld.schemaVersion===1)!==(!legacy)))fail('failed-precondition');
   if(action==='undo' && ((old.schemaVersion===1)!==(!legacy)))fail('failed-precondition');
   if(action==='settle'){let cutoff;try{cutoff=civilDate(today(household.data().timeZone));}catch{fail('failed-precondition');}if(effectiveDate>cutoff||(!legacy&&effectiveDate<date(account.openingDate)))fail('failed-precondition');}
   const kind=action!=='undo'?(pendingOld?(pendingOld.type||pendingOld.kind):recurrence.kind):(old.type||old.kind),sign=kind==='income'?1:-1,delta=confirming?0:(action==='settle'?1:-1)*sign*amountCents;let balanceCents;if(!legacy&&!confirming){try{balanceCents=sumCents([account.balanceCents,delta]);}catch{fail('failed-precondition');}}
   const at=serverTimestamp(),nextMonths=action==='settle'?[...new Set([...months,occurrenceMonth])]:confirming?months:months.filter(v=>v!==occurrenceMonth);if(action==='settle'){links[occurrenceMonth]=transactionId;delete pending[occurrenceMonth];}else if(confirming)pending[occurrenceMonth]=transactionId;else delete links[occurrenceMonth];
   const result={transactionId,accountVersion:legacy?null:confirming?account.version:account.version+1,status:confirming?'planned':action==='settle'?'realized':'cancelled'};
   if(confirming){
    const common={description:String(recurrence.description||''),category:String(recurrence.category||'Outros'),subcategory:String(recurrence.subcategory||''),owner:String(recurrence.owner||'Família'),status:'planned',accountId,recurrenceId,occurrenceMonth,scheduledDate:effectiveDate,recurrencePending:true,occurrenceRegistrationId:commandId,purchaseDate:effectiveDate,createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid};
    const row=legacy?{...common,amount:amountCents/100,kind,transactionDate:effectiveDate,paidAt:null,clientGeneration:'post-cutover',occurrenceRevision:1}:{...common,schemaVersion:1,version:1,type:kind,currency:'BRL',amountCents,competenceDate:effectiveDate,dueDate:effectiveDate,settlementDate:null,effectiveDate:null,installmentNumber:null,installmentCount:null,installmentGroupId:null,archivedAt:null,deletedAt:null};
    tx.create(transactionRef,row);tx.create(db.doc(`${root}/transactions/${transactionId}/revisions/1`),{...row,action:'recurrence.confirm',commandId});
   }
   else if(action==='settle'){
    if(pendingOld){
     const row={...pendingOld,status:'realized',recurrencePending:false,updatedAt:at,updatedBy:uid,...(legacy?{amount:amountCents/100,paidAt:effectiveDate,occurrenceRevision:(pendingOld.occurrenceRevision||1)+1}:{amountCents,version:pendingOld.version+1,settlementDate:effectiveDate,effectiveDate,settledAt:at})};
     tx.update(transactionRef,row);
     tx.create(db.doc(`${root}/transactions/${transactionId}/revisions/${legacy?row.occurrenceRevision:row.version}`),{...row,previous:pendingOld,action:'recurrence.settle-pending',commandId});
    }
    else if(legacy)tx.create(transactionRef,{description:String(recurrence.description||''),category:String(recurrence.category||'Outros'),subcategory:String(recurrence.subcategory||''),owner:String(recurrence.owner||'Família'),amount:amountCents/100,kind,status:'realized',accountId,transactionDate:effectiveDate,purchaseDate:effectiveDate,paidAt:effectiveDate,recurrenceId,occurrenceMonth,clientGeneration:'post-cutover',createdAt:at,createdBy:uid,updatedAt:at});
    else {const row={schemaVersion:1,version:1,description:String(recurrence.description||''),category:String(recurrence.category||'Outros'),subcategory:String(recurrence.subcategory||''),owner:String(recurrence.owner||'Família'),amountCents,type:kind,currency:'BRL',status:'realized',accountId,purchaseDate:effectiveDate,competenceDate:effectiveDate,dueDate:effectiveDate,settlementDate:effectiveDate,effectiveDate,installmentNumber:null,installmentCount:null,installmentGroupId:null,recurrenceId,occurrenceMonth,archivedAt:null,deletedAt:null,createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid,settledAt:at};tx.create(transactionRef,row);tx.create(db.doc(`${root}/transactions/${transactionId}/revisions/1`),{...row,action:'recurrence.settle',commandId});}
   }else{const patch={status:'cancelled',updatedAt:at,updatedBy:uid,cancelledAt:at,cancelledBy:uid,...(old.schemaVersion===1?{version:old.version+1}:{})};tx.update(transactionRef,patch);if(old.schemaVersion===1)tx.create(db.doc(`${root}/transactions/${transactionId}/revisions/${old.version+1}`),{...old,...patch,action:'recurrence.undo',commandId});}
   if(!legacy&&!confirming){tx.update(accountRef,{...cashReferencePatch(account),balanceCents,version:account.version+1,updatedAt:at,updatedBy:uid});tx.create(db.doc(`${root}/ledgerEntries/${commandId}`),{schemaVersion:1,type:action==='settle'?kind:'transactionReversal',amountCents:delta,effectiveDate,transactionId,accountId,currency:'BRL',createdAt:at,createdBy:uid});}
   tx.update(recurrenceRef,{settledMonths:nextMonths,occurrenceTransactions:links,pendingOccurrenceTransactions:pending,updatedAt:at,updatedBy:uid});tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`recurrence.${action}`,actorId:uid,recurrenceId,occurrenceMonth,transactionId,createdAt:at});tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
  });
 };
}
