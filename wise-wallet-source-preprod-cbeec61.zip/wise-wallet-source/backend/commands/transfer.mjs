import {cashReferencePatch} from './cash-reference.mjs';
import { createHash } from 'node:crypto';
import { assertCents, civilDate, sumCents } from '../../packages/finance-domain/index.mjs';

export class CommandError extends Error {
  constructor(code) { super(code); this.code = code; }
}
const fail = code => { throw new CommandError(code); };
const id = value => {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(value)) fail('invalid-argument');
  return value;
};
const exact = (value, fields) => {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== fields.length || fields.some(k => !Object.hasOwn(value, k))) fail('invalid-argument');
};

export function validateTransfer(input) {
  exact(input, ['schemaVersion', 'type', 'householdId', 'idempotencyKey', 'payload']);
  if (input.schemaVersion !== 1 || input.type !== 'transfer') fail('invalid-argument');
  const householdId = id(input.householdId), idempotencyKey = id(input.idempotencyKey);
  exact(input.payload, ['fromAccountId', 'toAccountId', 'amountCents', 'currency', 'effectiveDate', 'fromVersion', 'toVersion']);
  const p = input.payload;
  const fromAccountId = id(p.fromAccountId), toAccountId = id(p.toAccountId);
  if (fromAccountId === toAccountId || p.currency !== 'BRL') fail('invalid-argument');
  try { assertCents(p.amountCents); civilDate(p.effectiveDate); } catch { fail('invalid-argument'); }
  if (p.amountCents <= 0 || [p.fromVersion, p.toVersion].some(v => v!==null&&(!Number.isSafeInteger(v) || v < 1 || v === Number.MAX_SAFE_INTEGER))) fail('invalid-argument');
  // Explicit order guarantees stable fingerprints independent of JSON key order.
  return { schemaVersion: 1, type: 'transfer', householdId, idempotencyKey,
    payload: { fromAccountId, toAccountId, amountCents: p.amountCents, currency: 'BRL', effectiveDate: p.effectiveDate, fromVersion: p.fromVersion, toVersion: p.toVersion } };
}

const hash = value => createHash('sha256').update(value).digest('hex');

/** Server-only core. db is Admin Firestore; uid MUST come from verified auth.
 * Caller owns App Check, throttling and mapping CommandError to callable errors.
 * No network endpoint is exposed by this module.
 */
export function createTransferHandler({ db, serverTimestamp, today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo' }).format(new Date()) }) {
  return async (uid, input) => {
    if (!uid) fail('unauthenticated');
    // UID is a document path segment; support Firebase custom UIDs safely.
    if (typeof uid !== 'string' || uid.length > 128 || /[/\x00-\x1f]/.test(uid) || ['.', '..'].includes(uid)) fail('unauthenticated');
    const command = validateTransfer(input), p = command.payload;
    const root = `households/${command.householdId}`;
    const commandId = hash(JSON.stringify([uid, command.idempotencyKey]));
    const fingerprint = hash(JSON.stringify(command));
    return db.runTransaction(async tx => {
      const member = await tx.get(db.doc(`${root}/members/${uid}`));
      if (!member.exists || member.data().status !== 'active' || !['owner', 'admin', 'member'].includes(member.data().role)) fail('permission-denied');
      const receiptRef = db.doc(`${root}/commandReceipts/${commandId}`);
      const receipt = await tx.get(receiptRef);
      if (receipt.exists) {
        if (receipt.data().fingerprint !== fingerprint) fail('idempotency-conflict');
        return receipt.data().result;
      }
      // This command confirms cash now; future scheduling needs a separate command.
      if (p.effectiveDate > civilDate(today())) fail('failed-precondition');
      const fromRef = db.doc(`${root}/accounts/${p.fromAccountId}`), toRef = db.doc(`${root}/accounts/${p.toAccountId}`);
      const from = await tx.get(fromRef), to = await tx.get(toRef);
      if (!from.exists || !to.exists) fail('not-found');
      const a = from.data(), b = to.data();
      for(const account of [a,b]){
        if(account.archivedAt!=null||account.archived===true||account.deletedAt!=null)fail('failed-precondition');
        if(account.schemaVersion===1){if(account.currency!=='BRL'||!Number.isSafeInteger(account.balanceCents)||!Number.isSafeInteger(account.version)||account.version<1||account.version>=Number.MAX_SAFE_INTEGER)fail('failed-precondition');}
        else if(account.schemaVersion!=null||account.version!=null||account.balanceCents!=null||account.openingBalanceCents!=null||!Number.isSafeInteger(Math.round((account.openingBalance??0)*100))||Math.abs((account.openingBalance??0)-Math.round((account.openingBalance??0)*100)/100)>1e-7)fail('failed-precondition');
      }
      let historical=false;
      try { historical=[a,b].some(account => account.schemaVersion===1 && account.openingDate && p.effectiveDate < civilDate(account.openingDate)); } catch { fail('failed-precondition'); }
      if ((a.schemaVersion===1?a.version:null) !== p.fromVersion || (b.schemaVersion===1?b.version:null) !== p.toVersion) fail('version-conflict');
      let fromBalance, toBalance;
      if(!historical)try { if(a.schemaVersion===1)fromBalance = sumCents([a.balanceCents, -p.amountCents]); if(b.schemaVersion===1)toBalance = sumCents([b.balanceCents, p.amountCents]); } catch { fail('failed-precondition'); }
      const at = serverTimestamp();
      const result = { schemaVersion: 1, commandId, historical, fromVersion:a.schemaVersion===1?(historical?a.version:a.version+1):null, toVersion:b.schemaVersion===1?(historical?b.version:b.version+1):null };
      if(!historical){
        if(a.schemaVersion===1)tx.update(fromRef, { ...cashReferencePatch(a),balanceCents: fromBalance, version: result.fromVersion, updatedAt: at, updatedBy: uid });
        if(b.schemaVersion===1)tx.update(toRef, { ...cashReferencePatch(b),balanceCents: toBalance, version: result.toVersion, updatedAt: at, updatedBy: uid });
      }
      for (const [suffix, accountId, amountCents] of [['debit', p.fromAccountId, -p.amountCents], ['credit', p.toAccountId, p.amountCents]]) {
        tx.create(db.doc(`${root}/ledgerEntries/${commandId}_${suffix}`), { schemaVersion: 1, transferId: commandId, accountId, amountCents, currency: 'BRL', effectiveDate: p.effectiveDate, type: 'transfer', balanceImpact:!historical, createdAt: at, createdBy: uid });
      }
      tx.create(db.doc(`${root}/auditEvents/${commandId}`), { schemaVersion: 1, type: 'transfer.confirmed', actorId: uid, commandId, createdAt: at });
      tx.create(receiptRef, { schemaVersion: 1, fingerprint, result, createdAt: at });
      return result;
    });
  };
}
