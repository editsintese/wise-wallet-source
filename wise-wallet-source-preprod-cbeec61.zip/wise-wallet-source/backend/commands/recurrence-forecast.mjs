import {runCardTransaction} from './card-transaction.mjs';
import {createHash} from 'node:crypto';
import {assertCents} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';
import {activeInMonth} from './recurrence-occurrences.mjs';
const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const id=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))fail('invalid-argument');return value;};
const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)))fail('invalid-argument');};
export function createRecurrenceForecastHandler({db,serverTimestamp}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  exact(input,['householdId','idempotencyKey','payload']);const householdId=id(input.householdId),key=id(input.idempotencyKey),p=input.payload;exact(p,['recurrenceId','month','amountCents']);const recurrenceId=id(p.recurrenceId),month=p.month,amountCents=p.amountCents;
  if(typeof month!=='string'||!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))fail('invalid-argument');try{assertCents(amountCents);}catch{fail('invalid-argument');}if(amountCents<=0)fail('invalid-argument');
  const root=`households/${householdId}`,commandId=hash([uid,key]),fingerprint=hash(['recurrence-forecast',householdId,recurrenceId,month,amountCents]);
  return runCardTransaction(db,async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const ref=db.doc(`${root}/recurrences/${recurrenceId}`),snapshot=await tx.get(ref);if(!snapshot.exists)fail('not-found');const rule=snapshot.data();if(rule.closedForFuture===true||!activeInMonth(rule,month,{allowCard:true})||rule.settledMonths?.includes(month)||rule.occurrenceTransactions?.[month])fail('failed-precondition');
   const existing=await tx.get(db.collection(`${root}/transactions`).where('recurrenceId','==',recurrenceId));if(existing.docs.some(doc=>{const row=doc.data();return row.occurrenceMonth===month&&row.status!=='cancelled'&&row.deletedAt==null&&row.archived!==true&&row.archivedAt==null;}))fail('failed-precondition');
   let guardRef;if(rule.cardId){const cardId=id(rule.cardId);guardRef=db.doc(`${root}/cardOperationLocks/${cardId}`);await tx.get(guardRef);const payments=await tx.get(db.collection(`${root}/cardPayments`).where('cardId','==',cardId));for(const doc of payments.docs){const payment=doc.data();if(payment.reversedAt!=null||payment.status==='reversed'||payment.status==='cancelled')continue;if(typeof payment.competence!=='string'||!/^\d{4}-(0[1-9]|1[0-2])$/.test(payment.competence))fail('failed-precondition');if(payment.competence!==month)continue;const amount=payment.amountCents!=null?Number(payment.amountCents):Number(payment.amount)*100;if(!Number.isFinite(amount)||amount>0)fail('failed-precondition');}}
   const at=serverTimestamp(),result={recurrenceId,month,amountCents};if(guardRef)tx.set(guardRef,{updatedAt:at});tx.update(ref,{[`monthlyAmounts.${month}`]:amountCents/100,updatedAt:at,updatedBy:uid});tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:'recurrence.forecast',actorId:uid,recurrenceId,month,amountCents,createdAt:at});tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
  });
 };
}
