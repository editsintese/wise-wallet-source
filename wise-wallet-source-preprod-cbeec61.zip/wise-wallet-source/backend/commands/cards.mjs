import {createHash} from 'node:crypto';
import {assertCents} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';
const fail = code => { throw new CommandError(code); };
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const exact = (value, keys) => { if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== keys.length || keys.some(key => !Object.hasOwn(value,key))) fail('invalid-argument'); };
const id = value => { if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(value)) fail('invalid-argument'); return value; };
const version = value => { if (!Number.isSafeInteger(value) || value < 1 || value >= Number.MAX_SAFE_INTEGER) fail('invalid-argument'); return value; };
const text = (value,max,required=true) => { if (typeof value !== 'string' || value.length > max || (required && !value.trim())) fail('invalid-argument'); return value.trim(); };
const cents = value => { try { assertCents(value); } catch { fail('invalid-argument'); } return value; };
const day = value => { if (!Number.isSafeInteger(value) || value < 0 || value > 31) fail('invalid-argument'); return value; };

export function createCardHandler({db,serverTimestamp}) {
  return async (uid,input) => {
    if (typeof uid !== 'string' || !uid || uid.length > 128 || /[/\x00-\x1f]/.test(uid) || ['.','..'].includes(uid)) fail('unauthenticated');
    exact(input,['householdId','idempotencyKey','action','payload']); const householdId=id(input.householdId), idempotencyKey=id(input.idempotencyKey), p=input.payload;
    let payload;
    if (input.action === 'create') {
      exact(p,['name','holder','limitCents','closingDay','dueDay','accountId','availableFromBankCents','usedFromBankCents','currentInvoiceFromBankCents','bankCheckedAt','invoiceCheckedAt','observations']);
      payload={name:text(p.name,160),holder:text(p.holder,80),limitCents:cents(p.limitCents),closingDay:day(p.closingDay),dueDay:day(p.dueDay),accountId:p.accountId === '' ? '' : id(p.accountId),availableFromBankCents:p.availableFromBankCents===null?null:cents(p.availableFromBankCents),usedFromBankCents:p.usedFromBankCents===null?null:cents(p.usedFromBankCents),currentInvoiceFromBankCents:p.currentInvoiceFromBankCents===null?null:cents(p.currentInvoiceFromBankCents),bankCheckedAt:text(p.bankCheckedAt,20,false),invoiceCheckedAt:text(p.invoiceCheckedAt,20,false),observations:text(p.observations,1000,false)};
      if (payload.limitCents <= 0) fail('invalid-argument');
    } else if (input.action === 'update') {
      exact(p,['cardId','expectedVersion','name','holder','limitCents','closingDay','dueDay','accountId','availableFromBankCents','usedFromBankCents','currentInvoiceFromBankCents','bankCheckedAt','invoiceCheckedAt','observations']);
      payload={cardId:id(p.cardId),expectedVersion:version(p.expectedVersion),name:text(p.name,160),holder:text(p.holder,80),limitCents:cents(p.limitCents),closingDay:day(p.closingDay),dueDay:day(p.dueDay),accountId:p.accountId === '' ? '' : id(p.accountId),availableFromBankCents:p.availableFromBankCents===null?null:cents(p.availableFromBankCents),usedFromBankCents:p.usedFromBankCents===null?null:cents(p.usedFromBankCents),currentInvoiceFromBankCents:p.currentInvoiceFromBankCents===null?null:cents(p.currentInvoiceFromBankCents),bankCheckedAt:text(p.bankCheckedAt,20,false),invoiceCheckedAt:text(p.invoiceCheckedAt,20,false),observations:text(p.observations,1000,false)};
      if (payload.limitCents <= 0) fail('invalid-argument');
    } else if (input.action === 'archive' || input.action === 'restore') { exact(p,['cardId','expectedVersion']); payload={cardId:id(p.cardId),expectedVersion:version(p.expectedVersion)}; }
    else fail('invalid-argument');
    const root=`households/${householdId}`,commandId=hash([uid,idempotencyKey]),fingerprint=hash(['cards',input.action,payload]);
    return db.runTransaction(async tx => {
      const member=await tx.get(db.doc(`${root}/members/${uid}`)); if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role)) fail('permission-denied');
      const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef); if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
      const cardId=input.action==='create'?commandId:payload.cardId,cardRef=db.doc(`${root}/cards/${cardId}`),snapshot=await tx.get(cardRef),old=snapshot.exists?snapshot.data():null;
      if(input.action==='create'){if(old)fail('already-exists');}else{if(!old)fail('not-found');if(old.schemaVersion!==1||old.deletedAt!=null)fail('failed-precondition');if(old.version!==payload.expectedVersion)fail('version-conflict');if(input.action==='restore'?old.archivedAt==null:old.archivedAt!=null)fail('failed-precondition');}
      const at=serverTimestamp();let next=old?{...old,version:old.version+1,updatedAt:at,updatedBy:uid}: {schemaVersion:1,version:1,currency:'BRL',archivedAt:null,deletedAt:null,createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid};
      if(input.action==='create'||input.action==='update')Object.assign(next,payload);if(input.action==='archive')next.archivedAt=at;if(input.action==='restore')next.archivedAt=null;
      if(old)tx.update(cardRef,next);else tx.create(cardRef,next);const result={cardId,version:next.version};tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`card.${input.action}`,actorId:uid,cardId,createdAt:at});tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
    });
  };
}
