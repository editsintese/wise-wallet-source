import {createHash, createHmac} from 'node:crypto';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const hash=s=>createHash('sha256').update(s).digest('hex');
const segment=s=>{if(typeof s!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(s))fail('invalid-argument');return s;};
const actor=uid=>{if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');};
const fields=(input,names)=>{if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length!==names.length||names.some(n=>!Object.hasOwn(input,n)))fail('invalid-argument');};
const version=v=>{if(!Number.isSafeInteger(v)||v<1||v>=Number.MAX_SAFE_INTEGER)fail('invalid-argument');};
const active=m=>m.exists&&m.data().status==='active';
const manager=m=>active(m)&&['owner','admin'].includes(m.data().role);

/** Server-only methods. Auth UID, db, clock and secret are trusted dependencies.
 * No email sending, HTTP endpoint or production configuration in this module.
 */
export function createHouseholdService({db,serverTimestamp,invitationSecret,now=()=>Date.now()}) {
  if(!Buffer.isBuffer(invitationSecret)||invitationSecret.length<32)throw new TypeError('invitation-secret-required');
  const secret=Buffer.from(invitationSecret);
  const ref=p=>db.doc(p);
  const audit=(tx,root,id,type,uid)=>tx.create(ref(`${root}/auditEvents/${id}`),{schemaVersion:1,type,actorId:uid,createdAt:serverTimestamp()});
  return {
    async create(uid,input) {
      actor(uid);fields(input,['idempotencyKey','name']);segment(input.idempotencyKey);
      if(typeof input.name!=='string'||input.name.trim().length<1||input.name.length>80)fail('invalid-argument');
      const name=input.name.trim(),householdId=hash(JSON.stringify([uid,input.idempotencyKey]));const root=`households/${householdId}`;
      return db.runTransaction(async tx=>{
        const existing=await tx.get(ref(root));const member=await tx.get(ref(`${root}/members/${uid}`));
        if(existing.exists){if(!active(member))fail('permission-denied');if(existing.data().creationName!==name)fail('idempotency-conflict');return {householdId};}
        const at=serverTimestamp();tx.create(ref(root),{schemaVersion:1,version:1,name,creationName:name,ownerId:uid,timeZone:'America/Sao_Paulo',currency:'BRL',createdAt:at});
        tx.create(ref(`${root}/members/${uid}`),{schemaVersion:1,version:1,role:'owner',status:'active',createdAt:at});
        tx.create(ref(`users/${uid}/households/${householdId}`),{householdId,status:'active'});audit(tx,root,'created','household.created',uid);return {householdId};
      });
    },
    async invite(uid,input) {
      actor(uid);fields(input,['householdId','idempotencyKey','role']);const householdId=segment(input.householdId);segment(input.idempotencyKey);
      if(!['member','viewer'].includes(input.role))fail('invalid-argument');
      const root=`households/${householdId}`;
      // Stable secret-derived token supports retry without storing bearer credentials.
      const token=createHmac('sha256',secret).update(JSON.stringify([householdId,uid,input.idempotencyKey])).digest('hex');const invitationId=hash(token);
      return db.runTransaction(async tx=>{
        const member=await tx.get(ref(`${root}/members/${uid}`));if(!manager(member))fail('permission-denied');
        const invitation=await tx.get(ref(`${root}/invitations/${invitationId}`));
        if(invitation.exists){const prior=invitation.data();if(prior.role!==input.role)fail('idempotency-conflict');if(prior.status!=='pending'||prior.expiresAtMs<=now())fail('failed-precondition');return {householdId,invitationId,token,expiresAtMs:prior.expiresAtMs};}
        const expiresAtMs=now()+48*60*60*1000;
        tx.create(ref(`${root}/invitations/${invitationId}`),{schemaVersion:1,createdBy:uid,role:input.role,status:'pending',expiresAtMs,createdAt:serverTimestamp()});
        audit(tx,root,`invite_${invitationId}`,'invitation.created',uid);return {householdId,invitationId,token,expiresAtMs};
      });
    },
    async accept(uid,input) {
      actor(uid);fields(input,['householdId','token']);const householdId=segment(input.householdId);
      if(typeof input.token!=='string'||!/^[a-f0-9]{64}$/.test(input.token))fail('invalid-argument');
      const root=`households/${householdId}`,invitationId=hash(input.token);
      return db.runTransaction(async tx=>{
        const invitation=await tx.get(ref(`${root}/invitations/${invitationId}`));if(!invitation.exists)fail('invalid-invitation');const data=invitation.data();
        const membershipRef=ref(`${root}/members/${uid}`),member=await tx.get(membershipRef);
        if(data.status==='accepted'){if(data.acceptedBy!==uid||!active(member))fail('invalid-invitation');return {householdId,role:member.data().role};}
        if(data.status!=='pending'||data.expiresAtMs<=now())fail('invalid-invitation');
        const inviter=await tx.get(ref(`${root}/members/${data.createdBy}`));if(!manager(inviter))fail('invalid-invitation');
        // Reactivating removed members needs an explicit administrator action.
        if(member.exists)fail('already-member');
        const index=await tx.get(ref(`users/${uid}/households/${householdId}`));if(index.exists)fail('failed-precondition');
        const at=serverTimestamp();tx.create(membershipRef,{schemaVersion:1,version:1,role:data.role,status:'active',createdAt:at});
        tx.create(ref(`users/${uid}/households/${householdId}`),{householdId,status:'active'});
        tx.update(ref(`${root}/invitations/${invitationId}`),{status:'accepted',acceptedBy:uid,acceptedAt:at});audit(tx,root,`accept_${invitationId}`,'invitation.accepted',uid);return {householdId,role:data.role};
      });
    },
    async revoke(uid,input) {
      actor(uid);fields(input,['householdId','invitationId']);const root=`households/${segment(input.householdId)}`;segment(input.invitationId);
      return db.runTransaction(async tx=>{
        const member=await tx.get(ref(`${root}/members/${uid}`));if(!manager(member))fail('permission-denied');
        const path=ref(`${root}/invitations/${input.invitationId}`),invitation=await tx.get(path);if(!invitation.exists)fail('not-found');
        if(invitation.data().status==='revoked')return {revoked:true};if(invitation.data().status!=='pending')fail('failed-precondition');
        tx.update(path,{status:'revoked',revokedAt:serverTimestamp()});audit(tx,root,`revoke_${input.invitationId}`,'invitation.revoked',uid);return {revoked:true};
      });
    },
    async transferOwnership(uid,input) {
      actor(uid);fields(input,['householdId','targetUid','expectedVersion','idempotencyKey']);segment(input.idempotencyKey);actor(input.targetUid);version(input.expectedVersion);if(uid===input.targetUid)fail('invalid-argument');
      const householdId=segment(input.householdId),root=`households/${householdId}`;
      const commandId=hash(JSON.stringify([uid,input.idempotencyKey]));
      const fingerprint=hash(JSON.stringify(['ownership',householdId,input.targetUid,input.expectedVersion]));
      return db.runTransaction(async tx=>{
        const member=await tx.get(ref(`${root}/members/${uid}`));if(!active(member))fail('permission-denied');
        const receipt=await tx.get(ref(`${root}/commandReceipts/${commandId}`));
        if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
        const household=await tx.get(ref(root)),target=await tx.get(ref(`${root}/members/${input.targetUid}`));
        if(!household.exists||household.data().ownerId!==uid||!active(member)||member.data().role!=='owner')fail('permission-denied');
        if(household.data().version!==input.expectedVersion)fail('version-conflict');if(!active(target))fail('failed-precondition');version(member.data().version);version(target.data().version);
        tx.update(ref(root),{ownerId:input.targetUid,version:input.expectedVersion+1,updatedAt:serverTimestamp()});
        tx.update(ref(`${root}/members/${uid}`),{role:'admin',version:member.data().version+1});tx.update(ref(`${root}/members/${input.targetUid}`),{role:'owner',version:target.data().version+1});
        const result={householdId,ownerId:input.targetUid,version:input.expectedVersion+1};
        tx.create(ref(`${root}/commandReceipts/${commandId}`),{schemaVersion:1,fingerprint,result,createdAt:serverTimestamp()});
        audit(tx,root,`ownership_${input.expectedVersion}`,'household.ownership-transferred',uid);return result;
      });
    },
  };
}
