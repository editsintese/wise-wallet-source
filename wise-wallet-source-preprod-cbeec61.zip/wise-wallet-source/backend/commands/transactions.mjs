import {cashReferencePatch} from './cash-reference.mjs';
import {createHash} from 'node:crypto';
import {assertCents, civilDate, sumCents} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';

const fail = code => { throw new CommandError(code); };
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const exact = (value, keys) => {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== keys.length || keys.some(key => !Object.hasOwn(value,key))) fail('invalid-argument');
};
const id = value => {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(value)) fail('invalid-argument');
  return value;
};
const version = value => {
  if (!Number.isSafeInteger(value) || value < 1 || value >= Number.MAX_SAFE_INTEGER) fail('invalid-argument');
  return value;
};
const text = (value,max) => {
  if (typeof value !== 'string' || !value.trim() || value.length > max) fail('invalid-argument');
  return value.trim();
};
const date = value => { try { return civilDate(value); } catch { fail('invalid-argument'); } };
const detailsKeys = ['description','category','subcategory','owner','amountCents','purchaseDate','competenceDate','dueDate','settlementDate','installmentNumber','installmentCount','installmentGroupId'];
function details(p) {
  try { assertCents(p.amountCents); } catch { fail('invalid-argument'); }
  if (p.amountCents <= 0) fail('invalid-argument');
  if ((p.installmentNumber === null) !== (p.installmentCount === null) || (p.installmentCount === null) !== (p.installmentGroupId === null)) fail('invalid-argument');
  if (p.installmentNumber !== null && (!Number.isSafeInteger(p.installmentNumber) || !Number.isSafeInteger(p.installmentCount) || p.installmentNumber < 1 || p.installmentCount < 2 || p.installmentNumber > p.installmentCount)) fail('invalid-argument');
  return {description:text(p.description,240),category:text(p.category,80),subcategory:p.subcategory === '' ? '' : text(p.subcategory,80),owner:text(p.owner,80),amountCents:p.amountCents,purchaseDate:date(p.purchaseDate),competenceDate:date(p.competenceDate),dueDate:date(p.dueDate),settlementDate:p.settlementDate === null ? null : date(p.settlementDate),installmentNumber:p.installmentNumber,installmentCount:p.installmentCount,installmentGroupId:p.installmentGroupId === null ? null : id(p.installmentGroupId)};
}
function validate(input) {
  exact(input,['householdId','idempotencyKey','action','payload']);
  const householdId=id(input.householdId),idempotencyKey=id(input.idempotencyKey),rawPayload=input.payload || {},p=(input.action === 'create' || input.action === 'update') ? {...rawPayload,subcategory:rawPayload.subcategory ?? ''} : rawPayload;
  let payload;
  if (input.action === 'createHistoricalIncome') {
    exact(p,['description','category','subcategory','owner','amountCents','date']);
    try { assertCents(p.amountCents); } catch { fail('invalid-argument'); }
    if (p.amountCents <= 0) fail('invalid-argument');
    payload={description:text(p.description,240),category:text(p.category,80),subcategory:p.subcategory === '' ? '' : text(p.subcategory,80),owner:text(p.owner,80),amountCents:p.amountCents,date:date(p.date)};
  } else if (input.action === 'updateHistoricalIncome') {
    exact(p,['transactionId','expectedVersion','reason','description','category','subcategory','owner','amountCents','date']);
    try { assertCents(p.amountCents); } catch { fail('invalid-argument'); }
    if (p.amountCents <= 0) fail('invalid-argument');
    payload={transactionId:id(p.transactionId),expectedVersion:version(p.expectedVersion),reason:text(p.reason,240),description:text(p.description,240),category:text(p.category,80),subcategory:p.subcategory === '' ? '' : text(p.subcategory,80),owner:text(p.owner,80),amountCents:p.amountCents,date:date(p.date)};
  } else if (input.action === 'create') {
    exact(p,['accountId','expectedAccountVersion','type','currency','status',...detailsKeys]);
    if (!['income','expense'].includes(p.type) || p.currency !== 'BRL' || !['planned','realized'].includes(p.status)) fail('invalid-argument');
    payload={accountId:id(p.accountId),expectedAccountVersion:version(p.expectedAccountVersion),type:p.type,currency:'BRL',status:p.status,...details(p)};
    if ((p.status === 'realized') !== (payload.settlementDate !== null)) fail('invalid-argument');
  } else if (input.action === 'update') {
    exact(p,['transactionId','expectedVersion','expectedAccountVersion','reason',...detailsKeys]);
    payload={transactionId:id(p.transactionId),expectedVersion:version(p.expectedVersion),expectedAccountVersion:version(p.expectedAccountVersion),reason:text(p.reason,240),...details(p)};
  } else if (input.action === 'settle' || input.action === 'cancel') {
    exact(p,['transactionId','expectedVersion','expectedAccountVersion',input.action === 'settle' ? 'settlementDate' : 'reason']);
    payload={transactionId:id(p.transactionId),expectedVersion:version(p.expectedVersion),expectedAccountVersion:version(p.expectedAccountVersion),...(input.action === 'settle' ? {settlementDate:date(p.settlementDate)} : {reason:text(p.reason,240)})};
  } else if (input.action === 'archive' || input.action === 'restore') {
    exact(p,['transactionId','expectedVersion']);
    payload={transactionId:id(p.transactionId),expectedVersion:version(p.expectedVersion)};
  } else fail('invalid-argument');
  return {householdId,idempotencyKey,action:input.action,payload};
}

/** Manual BRL cash entries only; card purchases and invoice payments use separate contracts. */
export function createTransactionHandler({db,serverTimestamp,today=timeZone=>new Intl.DateTimeFormat('en-CA',{timeZone}).format(new Date())}) {
  return async (uid,input) => {
    if (typeof uid !== 'string' || !uid || uid.length > 128 || /[/\x00-\x1f]/.test(uid) || ['.','..'].includes(uid)) fail('unauthenticated');
    const command=validate(input),{action,payload:p}=command;
    const root=`households/${command.householdId}`,commandId=hash([uid,command.idempotencyKey]);
    const fingerprint=hash(['transactions',command]);
    return db.runTransaction(async tx => {
      const member=await tx.get(db.doc(`${root}/members/${uid}`));
      if (!member.exists || member.data().status !== 'active' || !['owner','admin','member'].includes(member.data().role)) fail('permission-denied');
      const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);
      if (receipt.exists) {
        if (receipt.data().fingerprint !== fingerprint) fail('idempotency-conflict');
        return receipt.data().result;
      }
      const historicalCreate=action === 'createHistoricalIncome',historicalUpdate=action === 'updateHistoricalIncome';
      const transactionId=action === 'create' || historicalCreate ? commandId : p.transactionId;
      const transactionRef=db.doc(`${root}/transactions/${transactionId}`),snapshot=await tx.get(transactionRef);
      const old=snapshot.exists ? snapshot.data() : null;
      if(action==='cancel'&&old?.installmentGroupId&&old.installmentCount>1)fail('failed-precondition');
      if (action === 'create' || historicalCreate) { if (old) fail('already-exists'); }
      else {
        if (!old) fail('not-found');
        if (old.investmentId) fail('failed-precondition');
        if (old.cardId && old.installmentGroupId && old.installmentCount > 1) fail('failed-precondition');
        if (old.recurrenceId && action !== 'update') fail('failed-precondition');
        if (old.schemaVersion !== 1 || old.currency !== 'BRL' || !['income','expense'].includes(old.type) || !['planned','realized','cancelled'].includes(old.status) || old.deletedAt != null) fail('failed-precondition');
        if (old.version !== p.expectedVersion) fail('version-conflict');
        if (action === 'restore' ? old.archivedAt == null : old.archivedAt != null) fail('failed-precondition');
        if (historicalUpdate && (old.type !== 'income' || old.historicalOnly !== true || old.status !== 'realized')) fail('failed-precondition');
      }
      const at=serverTimestamp(),organize=['archive','restore'].includes(action);
      const historyDate=p.date;
      if (historicalCreate || historicalUpdate) {
        const household=await tx.get(db.doc(root));
        if (!household.exists) fail('not-found');
        let cutoff;try { cutoff=civilDate(today(household.data().timeZone)); } catch { fail('failed-precondition'); }
        if (historyDate > cutoff) fail('failed-precondition');
      }
      const historicalFields=historicalCreate || historicalUpdate ? {accountId:'',type:'income',currency:'BRL',status:'realized',description:p.description,category:p.category,subcategory:p.subcategory,owner:p.owner,amountCents:p.amountCents,purchaseDate:historyDate,competenceDate:historyDate,dueDate:historyDate,settlementDate:historyDate,installmentNumber:null,installmentCount:null,installmentGroupId:null,historicalOnly:true,balanceImpact:false} : null;
      let next=historicalUpdate ? {...old,...historicalFields,version:old.version+1,updatedAt:at,updatedBy:uid} : old ? {...old,version:old.version+1,updatedAt:at,updatedBy:uid} : historicalCreate ? {
        schemaVersion:1,version:1,...historicalFields,archivedAt:null,deletedAt:null,createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid,settledAt:at,
      } : {
        schemaVersion:1,version:1,accountId:p.accountId,type:p.type,currency:'BRL',status:p.status,...details(p),
        archivedAt:null,deletedAt:null,createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid,settledAt:p.status === 'realized' ? at : null,
      };
      if (action === 'archive') next.archivedAt=at;
      if (action === 'restore') next.archivedAt=null;
      if (!organize && old) {
        if (old.status === 'cancelled') fail('failed-precondition');
        if (action === 'update') {
          if ((old.status === 'realized') !== (p.settlementDate !== null)) fail('invalid-argument');
          Object.assign(next,details(p));
        }
        if (action === 'settle') {
          if (old.status !== 'planned') fail('failed-precondition');
          Object.assign(next,{status:'realized',settlementDate:p.settlementDate,settledAt:at});
        }
        if (action === 'cancel') next.status='cancelled';
      }
      next.effectiveDate=next.settlementDate;
      let accountRef,accountPatch;const entries=[];
      if (!organize && !historicalCreate && !historicalUpdate) {
        const household=await tx.get(db.doc(root));
        if (!household.exists) fail('not-found');
        accountRef=db.doc(`${root}/accounts/${next.accountId}`);
        const accountSnapshot=await tx.get(accountRef);
        if (!accountSnapshot.exists) fail('not-found');
        const account=accountSnapshot.data();
        if (account.schemaVersion !== 1 || account.currency !== 'BRL' || account.archivedAt != null) fail('failed-precondition');
        if (account.version !== p.expectedAccountVersion) fail('version-conflict');
        if (next.status === 'realized') {
          let cutoff;try { cutoff=civilDate(today(household.data().timeZone)); } catch { fail('failed-precondition'); }
          if (next.settlementDate > cutoff || next.settlementDate < civilDate(account.openingDate)) fail('failed-precondition');
        }
        // Reverse the original dated cash fact, then append its replacement. Never erase history.
        const cashChanged=(old?.status === 'realized' || next.status === 'realized') &&
          (!old || old.status !== next.status || old.amountCents !== next.amountCents || old.settlementDate !== next.settlementDate);
        if (cashChanged) {
          const sign=next.type === 'income' ? 1 : -1;
          if (old?.status === 'realized') entries.push({suffix:'reversal',type:'transactionReversal',amountCents:-sign*old.amountCents,effectiveDate:old.settlementDate,reversesVersion:old.version});
          if (next.status === 'realized') entries.push({suffix:'effect',type:next.type,amountCents:sign*next.amountCents,effectiveDate:next.settlementDate});
          let balanceCents;try { balanceCents=sumCents([account.balanceCents,...entries.map(e=>e.amountCents)]); } catch { fail('failed-precondition'); }
          accountPatch={...cashReferencePatch(account),balanceCents,version:account.version+1,updatedAt:at,updatedBy:uid};
        }
      }
      const result={transactionId,version:next.version,...(!organize && !historicalCreate && !historicalUpdate ? {accountVersion:accountPatch?.version ?? p.expectedAccountVersion} : {})};
      if (old) tx.update(transactionRef,next); else tx.create(transactionRef,next);
      if (accountPatch) tx.update(accountRef,accountPatch);
      for (const {suffix,...entry} of entries) tx.create(db.doc(`${root}/ledgerEntries/${commandId}_${suffix}`),{
        schemaVersion:1,...entry,transactionId,transactionVersion:next.version,accountId:next.accountId,currency:'BRL',createdBy:uid,createdAt:at,
      });
      tx.create(db.doc(`${root}/transactions/${transactionId}/revisions/${next.version}`),{...next,action,reason:p.reason ?? null,commandId});
      tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`transaction.${action}`,actorId:uid,transactionId,createdAt:at,...(historicalUpdate?{reason:p.reason}:{})});
      tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});
      return result;
    });
  };
}
