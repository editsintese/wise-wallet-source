import {createHash} from 'node:crypto';
import {CommandError} from './transfer.mjs';
import {validatePatch} from './card-recurrences.mjs';

const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const id=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))fail('invalid-argument');return value;};
const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)))fail('invalid-argument');};
const version=value=>{if(!Number.isSafeInteger(value)||value<0||value>=Number.MAX_SAFE_INTEGER)fail('invalid-argument');return value;};

const defaults={active:true,frequency:'monthly',monthsOfYear:[],settledMonths:[],occurrenceTransactions:{},monthlyAmounts:{},endDate:'',cardId:'',archivedAt:null};

function merged(previous,patch){
 const next={...defaults,...(previous||{}),...patch};
 if(next.startDate&&next.endDate&&next.endDate<next.startDate)fail('invalid-argument');
 return next;
}

/**
 * Transactional create/update for recurring rules that do not use a credit
 * card. Card rules must go through manageCardRecurrence because they affect
 * invoice history and need a historical split.
 */
export function createRecurrenceRuleHandler({db,serverTimestamp}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  exact(input,['householdId','idempotencyKey','action','payload']);
  const householdId=id(input.householdId),key=id(input.idempotencyKey),action=input.action,p=input.payload;
  if(action==='create')exact(p,['values']);else if(action==='update')exact(p,['recurrenceId','expectedRevision','patch']);else fail('invalid-argument');
  const patch=validatePatch(action==='create'?p.values:p.patch);
  if(action==='create'&&(!patch.description||!patch.amount||!patch.kind||!patch.startDate||patch.cardId))fail('invalid-argument');
  if(action==='update')version(p.expectedRevision);
  const root=`households/${householdId}`,commandId=hash([uid,key]),recurrenceId=action==='create'?commandId:id(p.recurrenceId);
  const fingerprint=hash(['recurrence-rule',householdId,action,recurrenceId,action==='update'?p.expectedRevision:null,patch]);
  return db.runTransaction(async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));
   if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);
   if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const ref=db.doc(`${root}/recurrences/${recurrenceId}`),snapshot=await tx.get(ref);
   if(action==='create'&&snapshot.exists)fail('already-exists');
   if(action==='update'&&!snapshot.exists)fail('not-found');
   const previous=snapshot.exists?snapshot.data():null;
   if(previous&&(Number(previous.ruleRevision||0)!==p.expectedRevision))fail('version-conflict');
   if(previous?.cardId)fail('failed-precondition');
   if(previous?.closedForFuture===true)fail('failed-precondition');
   if(patch.cardId)fail('failed-precondition');
   const next=merged(previous,patch);
   if(!next.description||!next.amount||!next.kind||!next.startDate)fail('invalid-argument');
   const at=serverTimestamp(),revision=action==='create'?1:p.expectedRevision+1;
   if(action==='create')tx.create(ref,{...next,ruleRevision:revision,createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid});
   else tx.update(ref,{...patch,ruleRevision:revision,updatedAt:at,updatedBy:uid});
   tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`recurrence.rule.${action}`,actorId:uid,recurrenceId,createdAt:at,...(previous?{previous}: {})});
   tx.create(receiptRef,{schemaVersion:1,fingerprint,result:{recurrenceId,revision},createdAt:at});
   return {recurrenceId,revision};
  });
 };
}
