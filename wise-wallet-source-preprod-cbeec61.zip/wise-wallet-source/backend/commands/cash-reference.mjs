import {CommandError} from './transfer.mjs';
/** Preserve the bank observation. After a new cash fact, use the calculated balance.
 * A divergent verified observation requires explicit reconciliation, never a guessed baseline.
 */
export function cashReferencePatch(account){
 if(!account.bankCheckedAt||!Number.isSafeInteger(account.bankBalanceCents)||account.bankBalanceStale===true)return {};
 if(account.schemaVersion!==1||account.bankBalanceCents!==account.balanceCents)throw new CommandError('bank-reference-conflict');
 return {bankBalanceStale:true};
}
