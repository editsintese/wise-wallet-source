import {createHash} from 'node:crypto';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const hash=s=>createHash('sha256').update(s).digest('hex');
const uidValid=uid=>typeof uid==='string'&&uid.length>0&&uid.length<=128&&!/[/\x00-\x1f]/.test(uid)&&!['.','..'].includes(uid);

/** Server-only member administration. No direct client writes or data deletion. */
export function createMembershipHandler({db,serverTimestamp}) {
  return async (uid,input)=>{
    if(!uidValid(uid))fail('unauthenticated');
    if(!input||typeof input!=='object'||Array.isArray(input))fail('invalid-argument');
    const keys=['householdId','targetUid','expectedVersion','idempotencyKey','action',...(input.action==='setRole'?['role']:[])];
    if(Object.keys(input).length!==keys.length||keys.some(k=>!Object.hasOwn(input,k)))fail('invalid-argument');
    if(!['setRole','remove'].includes(input.action)||!uidValid(input.targetUid)||!Number.isSafeInteger(input.expectedVersion)||input.expectedVersion<1||input.expectedVersion>=Number.MAX_SAFE_INTEGER)fail('invalid-argument');
    for(const field of ['householdId','idempotencyKey'])if(typeof input[field]!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(input[field]))fail('invalid-argument');
    if(input.action==='setRole'&&!['admin','member','viewer'].includes(input.role))fail('invalid-argument');
    if(uid===input.targetUid)fail('failed-precondition');
    const root=`households/${input.householdId}`,ref=p=>db.doc(p);
    const commandId=hash(JSON.stringify([uid,input.idempotencyKey]));
    const fingerprint=hash(JSON.stringify(['membership',input.householdId,input.targetUid,input.expectedVersion,input.action,input.role??null]));
    return db.runTransaction(async tx=>{
      const actor=await tx.get(ref(`${root}/members/${uid}`));
      if(!actor.exists||actor.data().status!=='active'||!['owner','admin'].includes(actor.data().role))fail('permission-denied');
      const receiptRef=ref(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);
      if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
      const household=await tx.get(ref(root));
      const targetRef=ref(`${root}/members/${input.targetUid}`),target=await tx.get(targetRef);
      if(!household.exists||!target.exists)fail('not-found');
      const member=target.data(),isOwner=actor.data().role==='owner'&&household.data().ownerId===uid;
      if(actor.data().role==='owner'&&!isOwner)fail('permission-denied');
      if(member.role==='owner'||household.data().ownerId===input.targetUid)fail('failed-precondition');
      if(member.status!=='active')fail('failed-precondition');
      if(member.version!==input.expectedVersion)fail('version-conflict');
      if(!isOwner&&(member.role==='admin'||input.role==='admin'))fail('permission-denied');
      const indexRef=ref(`users/${input.targetUid}/households/${input.householdId}`),index=await tx.get(indexRef);
      if(!index.exists)fail('failed-precondition');
      const at=serverTimestamp(),result={targetUid:input.targetUid,version:member.version+1,status:input.action==='remove'?'removed':'active',role:input.action==='setRole'?input.role:member.role};
      tx.update(targetRef,{...result,updatedAt:at,updatedBy:uid,...(input.action==='remove'?{removedAt:at}:{})});
      tx.update(indexRef,{status:result.status});
      tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});
      tx.create(ref(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:input.action==='remove'?'member.removed':'member.role-changed',actorId:uid,targetUid:input.targetUid,previousRole:member.role,role:result.role,createdAt:at});
      return result;
    });
  };
}
