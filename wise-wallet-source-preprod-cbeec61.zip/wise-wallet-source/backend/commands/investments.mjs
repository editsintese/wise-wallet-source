import {cashReferencePatch} from './cash-reference.mjs';
import {createInvestmentAmendmentHandler} from './investment-amendments.mjs';
import {createHash} from 'node:crypto';
import {civilDate, sumCents} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const id=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))fail('invalid-argument');return value;};
const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))fail('invalid-argument');};
const cents=(value,positive=false)=>{if(!Number.isSafeInteger(value)||value<(positive?1:0))fail('invalid-argument');return value;};
const revision=value=>{if(!Number.isSafeInteger(value)||value<0||value>=Number.MAX_SAFE_INTEGER)fail('invalid-argument');return value;};
const text=value=>{if(typeof value!=='string'||!value.trim()||value.length>160)fail('invalid-argument');return value.trim();};
const date=value=>{try{return civilDate(value);}catch{fail('invalid-argument');}};
// A legacy position is accepted only when both amounts have an exact cent representation.
function legacyCents(value){const result=Math.round(value*100);if(typeof value!=='number'||!Number.isSafeInteger(result)||result<0||Math.abs(value-result/100)>1e-7)fail('failed-precondition');return result;}
export function createInvestmentHandler({db,serverTimestamp,today=timeZone=>new Intl.DateTimeFormat('en-CA',{timeZone}).format(new Date())}){
 const amend=createInvestmentAmendmentHandler({db,serverTimestamp});
 return async(uid,input)=>{
  if (input && ['correct','reverse'].includes(input.action)) return amend(uid,input);
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  exact(input,['householdId','idempotencyKey','action','payload']);
  const householdId=id(input.householdId),key=id(input.idempotencyKey),action=input.action,p=input.payload;
  if(!['create','valuation','contribution','withdrawal','archive'].includes(action))fail('invalid-argument');
  const financial=['create','contribution','withdrawal'].includes(action);
  exact(p,[...(action==='create'?[]:['investmentId','expectedVersion']),...(action==='archive'?[]:['name','institution','type','referenceDate']),...(action==='create'||action==='valuation'?['currentCents']:[]),...(financial?['amountCents','accountId','expectedAccountVersion']:[])]);
  const values=action==='archive'?{}:{name:text(p.name),institution:text(p.institution),type:text(p.type),referenceDate:date(p.referenceDate)};
  if(action!=='create'){id(p.investmentId);revision(p.expectedVersion);}
  if(action==='create'||action==='valuation')cents(p.currentCents);
  if(financial){cents(p.amountCents,true);id(p.accountId);if(p.expectedAccountVersion!==null&&revision(p.expectedAccountVersion)<1)fail('invalid-argument');}
  const root=`households/${householdId}`,commandId=hash([uid,key]),investmentId=action==='create'?commandId:p.investmentId,fingerprint=hash(['investment',action,p,householdId]);
  return db.runTransaction(async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));
   if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);
   if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const ref=db.doc(`${root}/investments/${investmentId}`),snapshot=await tx.get(ref),old=snapshot.exists?snapshot.data():null;
   if(action==='create'?!!old:!old)fail(action==='create'?'already-exists':'not-found');
   if(old&&(old.archivedAt!=null||old.archived===true))fail('failed-precondition');
   const oldVersion=old?.version??0;if(old)revision(oldVersion);
   if(old&&oldVersion!==p.expectedVersion)fail('version-conflict');
   const invested=old?legacyCents(old.investedValue):0,current=old?legacyCents(old.currentValue):0;
   if(old?.schemaVersion!=null&&old.schemaVersion!==1)fail('failed-precondition');
   if(old?.schemaVersion===1&&(old.investedCents!==invested||old.currentCents!==current))fail('failed-precondition');
   const household=await tx.get(db.doc(root));if(!household.exists)fail('not-found');
   if(action!=='archive'){
    if(values.referenceDate>date(today(household.data().timeZone)))fail('failed-precondition');
    if(old&&(!old.referenceDate||values.referenceDate<date(old.referenceDate)))fail('failed-precondition');
   }
   if(action==='archive'&&current!==0)fail('failed-precondition');
   if(action==='withdrawal'&&p.amountCents>current)fail('failed-precondition');
   let nextInvested=invested,nextCurrent=current;
   try{
    if(action==='create'){nextInvested=p.amountCents;nextCurrent=p.currentCents;}
    if(action==='valuation')nextCurrent=p.currentCents;
    if(action==='contribution'){nextInvested=sumCents([invested,p.amountCents]);nextCurrent=sumCents([current,p.amountCents]);}
    if(action==='withdrawal'){nextInvested=Math.max(0,invested-p.amountCents);nextCurrent=current-p.amountCents;}
   }catch{fail('failed-precondition');}
   const historyRef=db.doc(`${root}/investments/${investmentId}/revisions/${oldVersion+1}`);
   if((await tx.get(historyRef)).exists)fail('failed-precondition');
   let accountRef,account,canonical=false,balanceCents,transactionRef;
   if(financial){
    accountRef=db.doc(`${root}/accounts/${p.accountId}`);const accountSnapshot=await tx.get(accountRef);if(!accountSnapshot.exists)fail('not-found');account=accountSnapshot.data();
    if(account.archivedAt!=null||account.archived===true||account.deletedAt!=null)fail('failed-precondition');
    canonical=account.schemaVersion===1;
    if(canonical){
     if(account.currency!=='BRL'||!Number.isSafeInteger(account.version)||account.version<1||account.version>=Number.MAX_SAFE_INTEGER||!Number.isSafeInteger(account.balanceCents))fail('failed-precondition');
     if(account.version!==p.expectedAccountVersion)fail('version-conflict');
     if(values.referenceDate<date(account.openingDate))fail('failed-precondition');
     try{balanceCents=sumCents([account.balanceCents,action==='withdrawal'?p.amountCents:-p.amountCents]);}catch{fail('failed-precondition');}
    }else if(account.schemaVersion!=null||account.version!=null||p.expectedAccountVersion!==null||account.balanceCents!=null||account.openingBalanceCents!=null)fail('failed-precondition');
    transactionRef=db.doc(`${root}/transactions/${commandId}`);if((await tx.get(transactionRef)).exists)fail('already-exists');
   }
   // All reads above; position, cash, history and receipt commit together.
   const at=serverTimestamp(),version=oldVersion+1,result={investmentId,version,...(financial?{transactionId:commandId,accountVersion:canonical?account.version+1:null}:{})};
   const next={...(old||{}),...values,schemaVersion:1,version,investedCents:nextInvested,currentCents:nextCurrent,investedValue:nextInvested/100,currentValue:nextCurrent/100,updatedAt:at,updatedBy:uid,...(!old?{createdAt:at,createdBy:uid}:{}),...(action==='archive'?{archivedAt:at}:{})};
   if(old)tx.update(ref,next);else tx.create(ref,next);
   tx.create(historyRef,{action,previous:old,next,commandId,actorId:uid,createdAt:at});
   if(financial){
    const kind=action==='withdrawal'?'income':'expense',description=`${action==='withdrawal'?'Resgate':'Aporte'} · ${values.name}`,day=values.referenceDate;
    const common={investmentId,investmentOperation:action,investmentVersion:version,description,category:'Investimento',subcategory:'',owner:'Família',accountId:p.accountId,status:'realized',createdAt:at,createdBy:uid};
    const movement=canonical?{...common,schemaVersion:1,version:1,type:kind,currency:'BRL',amountCents:p.amountCents,purchaseDate:day,competenceDate:day,dueDate:day,settlementDate:day,effectiveDate:day,installmentNumber:null,installmentCount:null,installmentGroupId:null,archivedAt:null,deletedAt:null,settledAt:at}:{...common,kind,amount:p.amountCents/100,transactionDate:day,paidAt:day,clientGeneration:'post-cutover'};
    tx.create(transactionRef,movement);
    if(canonical){
     tx.update(accountRef,{...cashReferencePatch(account),balanceCents,version:account.version+1,updatedAt:at,updatedBy:uid});
     tx.create(db.doc(`${root}/ledgerEntries/${commandId}_effect`),{schemaVersion:1,type:kind,amountCents:kind==='income'?p.amountCents:-p.amountCents,accountId:p.accountId,transactionId:commandId,transactionVersion:1,investmentId,effectiveDate:day,currency:'BRL',createdAt:at,createdBy:uid});
     tx.create(db.doc(`${root}/transactions/${commandId}/revisions/1`),{...movement,action:'investment',commandId});
    }
   }
   tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`investment.${action}`,actorId:uid,investmentId,createdAt:at});
   tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
  });
 };
}
