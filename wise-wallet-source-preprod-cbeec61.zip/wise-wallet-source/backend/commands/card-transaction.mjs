const retryableClosedTransaction=error=>Number(error?.code)===3&&/transaction is invalid or closed\./i.test(String(error?.message||''));
const pause=milliseconds=>new Promise(resolve=>setTimeout(resolve,milliseconds));

/** Retry only Firestore's transient closed-transaction response; command receipts keep retries idempotent. */
export async function runCardTransaction(db,work){
 for(let attempt=0;;attempt++){
  try{return await db.runTransaction(work);}
  catch(error){
   if(attempt>=2||!retryableClosedTransaction(error))throw error;
   await pause(12*(attempt+1));
  }
 }
}
