import {createHash} from 'node:crypto';
import {assertCents,civilDate} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)))fail('invalid-argument');};
const id=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))fail('invalid-argument');return value;};
const version=value=>{if(!Number.isSafeInteger(value)||value<1||value>=Number.MAX_SAFE_INTEGER)fail('invalid-argument');return value;};
const text=(value,max,required=true)=>{if(typeof value!=='string'||value.length>max||(required&&!value.trim()))fail('invalid-argument');return value.trim();};
const date=value=>{try{return civilDate(value);}catch{fail('invalid-argument');}};
const cents=value=>{try{assertCents(value);}catch{fail('invalid-argument');}return value;};
const day=value=>{if(!Number.isSafeInteger(value)||value<1||value>31)fail('invalid-argument');return value;};
const months=value=>{if(!Array.isArray(value)||value.some(item=>!Number.isSafeInteger(item)||item<1||item>12))fail('invalid-argument');return [...new Set(value)];};
function fields(p){return {description:text(p.description,240),category:text(p.category,80,false),subcategory:text(p.subcategory,80,false),amountCents:cents(p.amountCents),kind:['expense','income'].includes(p.kind)?p.kind:null,owner:text(p.owner,80),frequency:['monthly','yearly','weekly'].includes(p.frequency)?p.frequency:null,dueDay:day(p.dueDay),startDate:date(p.startDate),endDate:p.endDate?date(p.endDate):'',accountId:p.accountId===''?'':id(p.accountId),cardId:p.cardId===''?'':id(p.cardId),monthsOfYear:months(p.monthsOfYear),observations:text(p.observations,1000,false)};}
export function createRecurrenceHandler({db,serverTimestamp}){return async(uid,input)=>{
 if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
 exact(input,['householdId','idempotencyKey','action','payload']);const householdId=id(input.householdId),idempotencyKey=id(input.idempotencyKey),p=input.payload;let payload;
 if(input.action==='create'){exact(p,['description','category','subcategory','amountCents','kind','owner','frequency','dueDay','startDate','endDate','accountId','cardId','monthsOfYear','observations']);payload=fields(p);if(payload.amountCents<=0||!payload.kind||!payload.frequency)fail('invalid-argument');}
 else if(input.action==='update'){exact(p,['recurrenceId','expectedVersion','description','category','subcategory','amountCents','kind','owner','frequency','dueDay','startDate','endDate','accountId','cardId','monthsOfYear','observations']);payload={recurrenceId:id(p.recurrenceId),expectedVersion:version(p.expectedVersion),...fields(p)};if(payload.amountCents<=0||!payload.kind||!payload.frequency)fail('invalid-argument');}
 else if(input.action==='archive'||input.action==='restore'){exact(p,['recurrenceId','expectedVersion']);payload={recurrenceId:id(p.recurrenceId),expectedVersion:version(p.expectedVersion)};}else fail('invalid-argument');
 const root=`households/${householdId}`,commandId=hash([uid,idempotencyKey]),fingerprint=hash(['recurrences',input.action,payload]);return db.runTransaction(async tx=>{
  const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
  const recurrenceId=input.action==='create'?commandId:payload.recurrenceId,ref=db.doc(`${root}/recurrences/${recurrenceId}`),snapshot=await tx.get(ref),old=snapshot.exists?snapshot.data():null;if(input.action==='create'){if(old)fail('already-exists');}else{if(!old)fail('not-found');if(old.schemaVersion!==1||old.deletedAt!=null)fail('failed-precondition');if(old.version!==payload.expectedVersion)fail('version-conflict');if(input.action==='restore'?old.archivedAt==null:old.archivedAt!=null)fail('failed-precondition');}
  const at=serverTimestamp();let next=old?{...old,version:old.version+1,updatedAt:at,updatedBy:uid}:{schemaVersion:1,version:1,currency:'BRL',settledMonths:[],occurrenceTransactions:{},archivedAt:null,deletedAt:null,createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid};if(input.action==='create'||input.action==='update')Object.assign(next,payload);if(input.action==='archive')next.archivedAt=at;if(input.action==='restore')next.archivedAt=null;if(old)tx.update(ref,next);else tx.create(ref,next);const result={recurrenceId,version:next.version};tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`recurrence.${input.action}`,actorId:uid,recurrenceId,createdAt:at});tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
 });
};}
