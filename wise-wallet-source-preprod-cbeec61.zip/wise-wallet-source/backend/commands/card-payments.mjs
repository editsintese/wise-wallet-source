import {runCardTransaction} from './card-transaction.mjs';
import {cashReferencePatch} from './cash-reference.mjs';
import {createHash} from 'node:crypto';
import {assertCents,civilDate,sumCents,weeklyDatesForMonth} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';

const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)))fail('invalid-argument');};
const id=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))fail('invalid-argument');return value;};
const version=value=>{if(!Number.isSafeInteger(value)||value<1||value>=Number.MAX_SAFE_INTEGER)fail('invalid-argument');return value;};
const month=value=>{if(typeof value!=='string'||!/^[0-9]{4}-(0[1-9]|1[0-2])$/.test(value))fail('invalid-argument');return value;};
const date=value=>{try{return civilDate(value);}catch{fail('invalid-argument');}};
const recurrenceApplies=(item,competence)=>{
 if(item.active===false)return false;
 const start=String(item.startDate||'').slice(0,7),end=String(item.endDate||'').slice(0,7);
 if((start&&!/^\d{4}-\d{2}$/.test(start))||(start&&competence<start)||(end&&competence>end))return false;
 const frequency=String(item.frequency||'monthly').toLowerCase();
 if(['yearly','annual','anual'].includes(frequency)){const selected=(item.monthsOfYear||[]).map(Number).filter(value=>value>=1&&value<=12);const number=Number(competence.slice(5,7));return selected.length?selected.includes(number):(!start||number===Number(start.slice(5,7)));}
 return true;
};

export function invoiceAmountBreakdown({rows,recurrences,card,cardId,competence}){
 const amounts=[],occurrences=[];let transactionTotal=false,recurrenceTotal=false;
 for(const row of rows){const rowMonth=String(row.competenceDate||row.transactionDate||'').slice(0,7),kind=row.type||row.kind;if(rowMonth!==competence||!['expense','income'].includes(kind)||row.status==='cancelled'||row.archived===true||row.archivedAt!=null||row.deletedAt!=null)continue;let cents;if(Number.isSafeInteger(row.amountCents))cents=row.amountCents;else{cents=Math.round(Number(row.amount)*100);if(!Number.isFinite(row.amount)||Math.abs(Number(row.amount)-cents/100)>1e-7)fail('failed-precondition');}try{assertCents(cents);}catch{fail('failed-precondition');}if(cents>0){amounts.push(kind==='income'?-cents:cents);transactionTotal=true;}}
 const coveredOccurrences=new Set(rows.filter(row=>row.recurrenceId&&row.occurrenceMonth&&row.status!=='cancelled'&&row.archived!==true&&row.archivedAt==null&&row.deletedAt==null).map(row=>`${row.recurrenceId}|${row.occurrenceMonth}`));
 for(const recurrence of recurrences){if(recurrence.cardId!==cardId||!recurrenceApplies(recurrence,competence))continue;const kind=recurrence.kind||recurrence.type;if(!['expense','income'].includes(kind))continue;const value=recurrence.monthlyAmounts?.[competence] ?? recurrence.amount;const cents=Math.round(Number(value)*100);if(!Number.isFinite(value)||Math.abs(Number(value)-cents/100)>1e-7)fail('failed-precondition');try{assertCents(cents);}catch{fail('failed-precondition');}const weekly=String(recurrence.frequency||'monthly').toLowerCase()==='weekly';let keys=[competence];if(weekly){if(coveredOccurrences.has(`${recurrence.id}|${competence}`)||recurrence.settledMonths?.includes(competence)||recurrence.occurrenceTransactions?.[competence])fail('failed-precondition');try{keys=weeklyDatesForMonth(recurrence.startDate,competence,recurrence.endDate||'');}catch{fail('failed-precondition');}}for(const occurrence of keys){if(cents<=0||coveredOccurrences.has(`${recurrence.id}|${occurrence}`))continue;if(recurrence.settledMonths?.includes(occurrence)||recurrence.occurrenceTransactions?.[occurrence])continue;amounts.push(kind==='income'?-cents:cents);occurrences.push({recurrenceId:recurrence.id,occurrenceKey:occurrence,amountCents:cents,kind});recurrenceTotal=true;}}
 if(!amounts.length){if(!card)fail('failed-precondition');const checked=String(card.invoiceCheckedAt||'').slice(0,7),bankInvoice=Number(card.currentInvoiceFromBank);if(checked!==competence||!Number.isFinite(bankInvoice)||bankInvoice<=0)fail('failed-precondition');return {amountCents:Math.round(bankInvoice*100),occurrences:[],source:'bank'};}
 try{const total=sumCents(amounts);if(total<=0)fail('failed-precondition');return {amountCents:total,occurrences,source:transactionTotal&&recurrenceTotal?'transactions+recurrences':recurrenceTotal?'recurrences':'transactions'};}catch(error){if(error instanceof CommandError)throw error;fail('failed-precondition');}
}
export function invoiceAmountCents(args){return invoiceAmountBreakdown(args).amountCents;}

export function createCardPaymentHandler({db,serverTimestamp,today=timeZone=>new Intl.DateTimeFormat('en-CA',{timeZone}).format(new Date()),loadInvoiceTransactions=async(tx,root,cardId)=>{
 const snapshot=await tx.get(db.collection(`${root}/transactions`).where('cardId','==',cardId));return snapshot.docs.map(document=>document.data());
},loadInvoiceRecurrences=async(tx,root,cardId)=>{
 const snapshot=await tx.get(db.collection(`${root}/recurrences`).where('cardId','==',cardId));return snapshot.docs.map(document=>({id:document.id,...document.data()}));
},loadCardPayments=async(tx,root,cardId)=>{
 const snapshot=await tx.get(db.collection(`${root}/cardPayments`).where('cardId','==',cardId));return snapshot.docs.map(document=>document.data());
}}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  exact(input,['householdId','idempotencyKey','payload']);const householdId=id(input.householdId),idempotencyKey=id(input.idempotencyKey),p=input.payload;
  exact(p,['cardId','accountId','competence','paymentDate','expectedAccountVersion']);const payload={cardId:id(p.cardId),accountId:id(p.accountId),competence:month(p.competence),paymentDate:date(p.paymentDate),expectedAccountVersion:p.expectedAccountVersion===null?null:version(p.expectedAccountVersion)};
  const root=`households/${householdId}`,commandId=hash([uid,idempotencyKey]),fingerprint=hash(['cardPayment',householdId,payload]),paymentId=`${payload.cardId}_${payload.competence}`;
  return runCardTransaction(db,async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const household=await tx.get(db.doc(root)),accountRef=db.doc(`${root}/accounts/${payload.accountId}`),accountSnapshot=await tx.get(accountRef),cardSnapshot=await tx.get(db.doc(`${root}/cards/${payload.cardId}`)),paymentRef=db.doc(`${root}/cardPayments/${paymentId}`),paymentSnapshot=await tx.get(paymentRef);
   if(!household.exists||!accountSnapshot.exists)fail('not-found');const previousPayment=paymentSnapshot.exists?paymentSnapshot.data():null;if(previousPayment&&previousPayment.reversedAt==null&&previousPayment.status!=='reversed')fail('already-exists');
   if(previousPayment && (previousPayment.cardId!==payload.cardId || previousPayment.competence!==payload.competence || !previousPayment.accountId || !previousPayment.paymentDate))fail('failed-precondition');
   const account=accountSnapshot.data();const legacy=account.schemaVersion!==1;if(account.archivedAt!=null||account.archived===true||(!legacy&&account.currency!=='BRL'))fail('failed-precondition');if(legacy ? payload.expectedAccountVersion!==null : account.version!==payload.expectedAccountVersion)fail('version-conflict');
   let cutoff;try{cutoff=civilDate(today(household.data().timeZone));}catch{fail('failed-precondition');}if(payload.paymentDate>cutoff)fail('failed-precondition');
   const guardRef=db.doc(`${root}/cardOperationLocks/${payload.cardId}`);await tx.get(guardRef);
   const rows=await loadInvoiceTransactions(tx,root,payload.cardId),recurrences=await loadInvoiceRecurrences(tx,root,payload.cardId),payments=await loadCardPayments(tx,root,payload.cardId);
   if(payments.some(payment=>payment.competence===payload.competence && payment.reversedAt==null && payment.status!=='reversed' && payment.status!=='cancelled'))fail('already-exists');
   const breakdown=invoiceAmountBreakdown({rows,recurrences,card:cardSnapshot.exists?cardSnapshot.data():null,cardId:payload.cardId,competence:payload.competence}),invoiceCents=breakdown.amountCents;
   const balanceImpact=legacy?true:payload.paymentDate>=civilDate(account.openingDate);let amountCents,balanceCents;try{amountCents=invoiceCents;if(balanceImpact&&!legacy)balanceCents=sumCents([account.balanceCents,-amountCents]);}catch(error){if(error instanceof CommandError)throw error;fail('failed-precondition');}
   const at=serverTimestamp(),accountVersion=legacy?null:(balanceImpact?account.version+1:account.version),result={paymentId,amountCents,accountVersion};
   tx.set(guardRef,{updatedAt:at});
   if(previousPayment)tx.create(db.doc(`${root}/ledgerEntries/${commandId}_previous`),{schemaVersion:1,type:'cardPaymentHistory',accountId:previousPayment.accountId,paymentId,previousPayment,createdAt:at,createdBy:uid});
   if(balanceImpact&&!legacy){tx.update(accountRef,{...cashReferencePatch(account),balanceCents,version:accountVersion,updatedAt:at,updatedBy:uid});tx.create(db.doc(`${root}/ledgerEntries/${commandId}`),{schemaVersion:1,type:'cardPayment',amountCents:-amountCents,effectiveDate:payload.paymentDate,accountId:payload.accountId,cardId:payload.cardId,competence:payload.competence,currency:'BRL',createdAt:at,createdBy:uid});}
   const paymentData={schemaVersion:1,version:previousPayment?Number(previousPayment.version||1)+1:1,cardId:payload.cardId,accountId:payload.accountId,competence:payload.competence,paymentDate:payload.paymentDate,amountCents,balanceImpact,currency:'BRL',reversedAt:null,reversedBy:null,status:'paid',invoicedOccurrences:breakdown.occurrences,invoiceSource:breakdown.source,updatedAt:at,updatedBy:uid};if(previousPayment)tx.update(paymentRef,paymentData);else tx.create(paymentRef,{...paymentData,createdAt:at,createdBy:uid});
   tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:'cardPayment.create',actorId:uid,paymentId,createdAt:at});tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
  });
 };
}

export function createCardPaymentReversalHandler({db,serverTimestamp}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  exact(input,['householdId','idempotencyKey','payload']); const householdId=id(input.householdId),idempotencyKey=id(input.idempotencyKey),p=input.payload;
  exact(p,['paymentId','expectedAccountVersion']); const paymentId=id(p.paymentId),expectedAccountVersion=p.expectedAccountVersion===null?null:version(p.expectedAccountVersion);
  const root=`households/${householdId}`,commandId=hash([uid,idempotencyKey]),fingerprint=hash(['cardPaymentReversal',householdId,p]);
  return runCardTransaction(db,async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`)); if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef); if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const paymentRef=db.doc(`${root}/cardPayments/${paymentId}`),paymentSnapshot=await tx.get(paymentRef); if(!paymentSnapshot.exists)fail('not-found'); const payment=paymentSnapshot.data(); if(payment.reversedAt!=null||payment.status==='reversed'||payment.status==='scheduled'||payment.status==='cancelled')fail('failed-precondition');
   const accountRef=db.doc(`${root}/accounts/${payment.accountId}`),accountSnapshot=await tx.get(accountRef); if(!accountSnapshot.exists)fail('not-found'); const account=accountSnapshot.data(),legacy=account.schemaVersion!==1; if(account.archivedAt!=null||account.archived===true||(!legacy&&account.currency!=='BRL')||(legacy?expectedAccountVersion!==null:account.version!==expectedAccountVersion))fail('version-conflict');
   if(!legacy && payment.schemaVersion!==1)fail('failed-precondition');
   const guardRef=db.doc(`${root}/cardOperationLocks/${payment.cardId}`);await tx.get(guardRef);
   const amountCents=payment.amountCents!=null?Number(payment.amountCents):Math.round(Number(payment.amount)*100); if(payment.amountCents==null && (!Number.isFinite(payment.amount)||Math.abs(payment.amount-amountCents/100)>1e-7))fail('failed-precondition'); try{assertCents(amountCents);}catch{fail('failed-precondition');} if(amountCents<=0)fail('failed-precondition');
   const balanceImpact=payment.balanceImpact!==false;let balanceCents;if(balanceImpact&&!legacy){try{balanceCents=sumCents([account.balanceCents,amountCents]);}catch{fail('failed-precondition');}}
   const at=serverTimestamp(),accountVersion=legacy?null:(balanceImpact?account.version+1:account.version),result={paymentId,accountVersion};
   tx.set(guardRef,{updatedAt:at});
   if(balanceImpact&&!legacy){tx.update(accountRef,{...cashReferencePatch(account),balanceCents,version:accountVersion,updatedAt:at,updatedBy:uid});tx.create(db.doc(`${root}/ledgerEntries/${commandId}`),{schemaVersion:1,type:'cardPaymentReversal',amountCents,accountId:payment.accountId,cardId:payment.cardId,competence:payment.competence,currency:'BRL',reversesPaymentId:paymentId,paymentVersion:Number(payment.version||1),createdAt:at,createdBy:uid});} tx.update(paymentRef,{reversedAt:at,reversedBy:uid,status:'reversed',version:Number(payment.version||1)+1,updatedAt:at});
   tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:'cardPayment.reverse',actorId:uid,paymentId,createdAt:at}); tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at}); return result;
  });
 };
}
