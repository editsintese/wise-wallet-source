import {runCardTransaction} from './card-transaction.mjs';
import {createHash} from 'node:crypto';
import {civilDate} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';

const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const validId=value=>typeof value==='string' && /^[A-Za-z0-9_-]{1,128}$/.test(value);

// Payment and cancellation serialize on the card operation lock.
export function createCancelCardInstallmentsHandler({db,serverTimestamp}) {
 return async (uid,input)=>{
  if(!validId(uid))fail('unauthenticated');
  if(!input || Object.keys(input).sort().join(',')!=='householdId,idempotencyKey,payload' || !validId(input.householdId) || !validId(input.idempotencyKey) || !input.payload || Object.keys(input.payload).sort().join(',')!=='cardId,groupId' || !validId(input.payload.cardId) || !validId(input.payload.groupId))fail('invalid-argument');
  const {householdId,idempotencyKey,payload:{cardId,groupId}}=input,root=`households/${householdId}`,commandId=hash([uid,idempotencyKey]),fingerprint=hash(['cancel-card-installments',householdId,cardId,groupId]);
  return runCardTransaction(db,async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));
   if(!member.exists || member.data().status!=='active' || !['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);
   if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const guardRef=db.doc(`${root}/cardOperationLocks/${cardId}`),guard=await tx.get(guardRef);
   const markerRef=db.doc(`${root}/cancelledInstallmentGroups/${groupId}`),marker=await tx.get(markerRef);
   if(marker.exists)fail('failed-precondition');
   const rows=await tx.get(db.collection(`${root}/transactions`).where('installmentGroupId','==',groupId));
   const payments=await tx.get(db.collection(`${root}/cardPayments`).where('cardId','==',cardId));
   const items=rows.docs.map(doc=>({ref:doc.ref,...doc.data()}));
   if(!items.length)fail('not-found');
   const count=items[0].installmentCount,seen=new Set(),months=new Set();
   if(!Number.isSafeInteger(count)||count<2||count>120||items.length!==count)fail('failed-precondition');
   for(const row of items){
    const date=String(row.competenceDate||row.transactionDate||''),n=row.installmentNumber;
    try { civilDate(date); } catch { fail('failed-precondition'); }
    if(row.schemaVersion===1||row.cardId!==cardId||row.installmentCount!==count||!Number.isSafeInteger(n)||n<1||n>count||seen.has(n)||!/^\d{4}-(0[1-9]|1[0-2])-\d{2}$/.test(date)||row.status==='cancelled'||row.archived===true||row.archivedAt!=null||row.deletedAt!=null)fail('failed-precondition');
    seen.add(n);months.add(date.slice(0,7));
   }
   for(const snapshot of payments.docs){const p=snapshot.data();if(!months.has(p.competence)||p.reversedAt!=null||p.status==='reversed'||p.status==='cancelled')continue;const amount=p.amountCents!=null?Number(p.amountCents):Number(p.amount)*100;if(!Number.isFinite(amount)||amount>0)fail('failed-precondition');}
   const at=serverTimestamp(),result={groupId,count};
   tx.set(guardRef,{updatedAt:at});
   tx.create(markerRef,{cardId,createdAt:at,createdBy:uid});
   for(const row of items)tx.update(row.ref,{status:'cancelled',cancelledAt:at,cancelledBy:uid,updatedAt:at,updatedBy:uid});
   tx.create(db.doc(`${root}/auditEvents/${commandId}`),{type:'cardInstallments.cancel',actorId:uid,cardId,groupId,count,createdAt:at});
   tx.create(receiptRef,{fingerprint,result,createdAt:at});return result;
  });
 };
}
