import {cashReferencePatch} from './cash-reference.mjs';
import {createHash} from 'node:crypto';
import {civilDate,sumCents} from '../../packages/finance-domain/index.mjs';
import {bulkSnapshot} from '../../packages/finance-domain/bulk-transactions.mjs';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const ordered=x=>Array.isArray(x)?x.map(ordered):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,ordered(x[k])])):x;
const hash=x=>createHash('sha256').update(JSON.stringify(ordered(x))).digest('hex');
const id=x=>{if(typeof x!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(x))fail('invalid-argument');return x;};
const exact=(x,keys)=>{if(!x||typeof x!=='object'||Array.isArray(x)||Object.keys(x).length!==keys.length||keys.some(k=>!Object.hasOwn(x,k)))fail('invalid-argument');};
const date=x=>{try{return civilDate(x);}catch{fail('invalid-argument');}};
const text=(x,max,empty=false)=>{if(typeof x!=='string'||x.length>max||(!empty&&!x.trim()))fail('invalid-argument');return x.trim();};
export function createAmendManualHandler({db,serverTimestamp,today=timeZone=>new Intl.DateTimeFormat('en-CA',{timeZone}).format(new Date())}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  exact(input,['householdId','idempotencyKey','transactionId','snapshot','accounts','reason','values']);
  const householdId=id(input.householdId),transactionId=id(input.transactionId),key=id(input.idempotencyKey),reason=text(input.reason,240),v=input.values;
  exact(v,['description','category','subcategory','owner','amountCents','purchaseDate','date','settlementDate','status','accountId']);
  if(!Number.isSafeInteger(v.amountCents)||v.amountCents<=0||!['planned','realized','cancelled'].includes(v.status)||(v.status==='cancelled'?v.settlementDate!==null:(v.status==='realized')!==(v.settlementDate!==null)))fail('invalid-argument');
  const values={description:text(v.description,240),category:text(v.category,80),subcategory:text(v.subcategory,80,true),owner:text(v.owner,80),amountCents:v.amountCents,purchaseDate:date(v.purchaseDate),date:date(v.date),settlementDate:v.settlementDate===null?null:date(v.settlementDate),status:v.status,accountId:v.accountId===''?'':id(v.accountId)};
  if(!Array.isArray(input.accounts)||input.accounts.length>2||!input.snapshot||typeof input.snapshot!=='object')fail('invalid-argument');
  const versions=new Map();for(const a of input.accounts){exact(a,['accountId','expectedVersion']);id(a.accountId);if(versions.has(a.accountId)||a.expectedVersion!==null&&(!Number.isSafeInteger(a.expectedVersion)||a.expectedVersion<1||a.expectedVersion>=Number.MAX_SAFE_INTEGER))fail('invalid-argument');versions.set(a.accountId,a.expectedVersion);}
  const root=`households/${householdId}`,commandId=hash([uid,key]),fingerprint=hash(['amend-manual',input]),resultRef=db.doc(`${root}/commandReceipts/${commandId}`);
  return db.runTransaction(async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receipt=await tx.get(resultRef);if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const ref=db.doc(`${root}/transactions/${transactionId}`),snapshot=await tx.get(ref);if(!snapshot.exists)fail('not-found');const old=snapshot.data();
   if(values.status==='cancelled'&&old.installmentGroupId&&old.installmentCount>1)fail('failed-precondition');
   if(old.balanceImpact===false&&old.accountId)fail('failed-precondition');
   if(old.cardId||old.investmentId||old.transferId||old.deletedAt!=null||old.archivedAt!=null||old.archived===true||!['planned','realized'].includes(old.status))fail('failed-precondition');
   let image;try{image=bulkSnapshot(old);}catch{fail('failed-precondition');}
   if(hash(image)!==hash(input.snapshot))fail('version-conflict');
   const canonical=old.schemaVersion===1,kind=canonical?old.type:old.kind;if(!['income','expense'].includes(kind)||canonical&&old.currency!=='BRL'||!canonical&&(old.schemaVersion!=null||old.amountCents!=null||old.type!=null||old.version!=null))fail('failed-precondition');
   if(old.historicalOnly&&(values.accountId!==''||values.status!=='realized'||kind!=='income'))fail('failed-precondition');
   if(old.status==='realized'&&values.status==='planned')fail('failed-precondition');
   if(values.status==='cancelled'&&(values.accountId!==(old.accountId||'')||values.amountCents!==image.amountCents||values.date!==image.date))fail('invalid-argument');
   if(old.recurrenceId&&(old.accountId!==values.accountId||old.status!==values.status))fail('failed-precondition');
   const revision=canonical?old.version+1:(old.manualRevision||0)+1;if(!Number.isSafeInteger(revision)||revision<1||revision>=Number.MAX_SAFE_INTEGER)fail('failed-precondition');
   const historyRef=db.doc(`${ref.path}/revisions/${canonical?revision:'manual-'+revision}`);if((await tx.get(historyRef)).exists)fail('failed-precondition');
   const household=await tx.get(db.doc(root));if(!household.exists)fail('not-found');let cutoff;try{cutoff=civilDate(today(household.data().timeZone));}catch{fail('failed-precondition');}if(values.settlementDate&&values.settlementDate>cutoff)fail('failed-precondition');
   const ids=[...new Set([old.accountId,values.accountId].filter(Boolean))].sort(),states=new Map();if(versions.size!==ids.length||ids.some(a=>!versions.has(a)))fail('invalid-argument');
   for(const accountId of ids){id(accountId);const accountRef=db.doc(`${root}/accounts/${accountId}`),snap=await tx.get(accountRef);if(!snap.exists)fail('not-found');const data=snap.data();if(data.archivedAt!=null||data.archived===true||data.deletedAt!=null)fail('failed-precondition');const schema=data.schemaVersion===1?'canonical':'legacy';
    if(schema==='canonical'){if(data.currency!=='BRL'||!Number.isSafeInteger(data.balanceCents)||!Number.isSafeInteger(data.version)||data.version<1||data.version>=Number.MAX_SAFE_INTEGER)fail('failed-precondition');if(data.version!==versions.get(accountId))fail('version-conflict');if(values.accountId===accountId&&values.settlementDate&&values.settlementDate<date(data.openingDate))fail('failed-precondition');}
    else if(data.schemaVersion!=null||data.version!=null||data.balanceCents!=null||data.openingBalanceCents!=null||versions.get(accountId)!==null)fail('failed-precondition');
    states.set(accountId,{ref:accountRef,data,schema,delta:0});
   }
   if(old.accountId){const expected=old.manualManaged?old.cashAccountSchema:(canonical?'canonical':'legacy');if(states.get(old.accountId).schema!==expected)fail('failed-precondition');}
   const oldDate=old.status==='realized'?date(canonical?old.settlementDate:old.paidAt||old.transactionDate):null;
   const changed=old.status!==values.status||old.accountId!==values.accountId||image.amountCents!==values.amountCents||oldDate!==values.settlementDate;
   const entries=[],sign=kind==='income'?1:-1;
   if(changed){
    if(old.historicalOnly&&(values.accountId!==''||values.status!=='realized'||kind!=='income'))fail('failed-precondition');
   if(old.status==='realized'&&old.accountId&&old.balanceImpact!==false){states.get(old.accountId).delta-=sign*image.amountCents;entries.push({suffix:'reverse',accountId:old.accountId,type:'transactionReversal',amountCents:-sign*image.amountCents,effectiveDate:oldDate});}
    if(values.status==='realized'&&values.accountId){states.get(values.accountId).delta+=sign*values.amountCents;entries.push({suffix:'effect',accountId:values.accountId,type:kind,amountCents:sign*values.amountCents,effectiveDate:values.settlementDate});}
   }
   for(const state of states.values())if(state.schema==='canonical'&&state.delta!==0){try{state.nextBalance=sumCents([state.data.balanceCents,state.delta]);}catch{fail('failed-precondition');}}
   const at=serverTimestamp(),patch={description:values.description,category:values.category,subcategory:values.subcategory,owner:values.owner,accountId:values.accountId,status:values.status,purchaseDate:values.purchaseDate,manualManaged:true,cashAccountSchema:values.accountId?states.get(values.accountId).schema:null,balanceImpact:Boolean(values.accountId),updatedAt:at,updatedBy:uid,...(canonical?{version:revision,amountCents:values.amountCents,competenceDate:values.date,dueDate:values.date,settlementDate:values.status==='cancelled'?oldDate:values.settlementDate,effectiveDate:values.status==='cancelled'?oldDate:values.settlementDate}:{manualRevision:revision,amount:values.amountCents/100,transactionDate:values.date,paidAt:values.status==='cancelled'?oldDate:values.settlementDate})};
   tx.update(ref,patch);tx.create(historyRef,{...old,...patch,previous:old,reason,commandId,action:'manual.amend'});
   for(const state of states.values())if(state.nextBalance!==undefined)tx.update(state.ref,{...cashReferencePatch(state.data),balanceCents:state.nextBalance,version:state.data.version+1,updatedAt:at,updatedBy:uid});
   for(const {suffix,...entry} of entries)tx.create(db.doc(`${root}/ledgerEntries/${commandId}_${suffix}`),{schemaVersion:1,...entry,transactionId,transactionVersion:revision,currency:'BRL',createdAt:at,createdBy:uid});
   const result={transactionId,version:revision,status:values.status};tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:'manual.amend',actorId:uid,transactionId,reason,createdAt:at});tx.create(resultRef,{fingerprint,result,createdAt:at});return result;
  });
 };
}
