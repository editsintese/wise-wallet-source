import {runCardTransaction} from './card-transaction.mjs';
import {cashReferencePatch} from './cash-reference.mjs';
import {createHash} from 'node:crypto';
import {assertCents,civilDate,sumCents} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';
import {invoiceAmountCents} from './card-payments.mjs';
const fail=code=>{throw new CommandError(code);};const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const exact=(x,keys)=>{if(!x||typeof x!=='object'||Array.isArray(x)||Object.keys(x).length!==keys.length||keys.some(k=>!Object.hasOwn(x,k)))fail('invalid-argument');};
const id=x=>{if(typeof x!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(x))fail('invalid-argument');return x;};
const ver=x=>{if(x!==null&&(!Number.isSafeInteger(x)||x<1||x>=Number.MAX_SAFE_INTEGER))fail('invalid-argument');return x;};
const date=x=>{try{return civilDate(x);}catch{fail('invalid-argument');}};
const month=x=>{if(typeof x!=='string'||!/^\d{4}-(0[1-9]|1[0-2])$/.test(x))fail('invalid-argument');return x;};
function paymentCents(payment){const value=payment.amountCents!=null?Number(payment.amountCents):Math.round(Number(payment.amount)*100);try{assertCents(value);}catch{fail('failed-precondition');}if(value<=0||(!Number.isSafeInteger(payment.amountCents)&&(!Number.isFinite(payment.amount)||Math.abs(payment.amount-value/100)>1e-7)))fail('failed-precondition');return value;}
export function createPartialCardPaymentHandler({db,serverTimestamp,today=timeZone=>new Intl.DateTimeFormat('en-CA',{timeZone}).format(new Date())}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');exact(input,['householdId','idempotencyKey','action','payload']);const householdId=id(input.householdId),key=id(input.idempotencyKey),action=input.action,p=input.payload;
  if(action==='create')exact(p,['cardId','accountId','competence','amountCents','paymentDate','mode','expectedAccountVersion']);else if(action==='settle')exact(p,['paymentId','paymentDate','expectedAccountVersion']);else if(action==='cancel')exact(p,['paymentId']);else fail('invalid-argument');
  let cardId,accountId,competence,amountCents,paymentDate,expectedAccountVersion,paymentId;
  if(action==='create'){cardId=id(p.cardId);accountId=id(p.accountId);competence=month(p.competence);amountCents=p.amountCents;try{assertCents(amountCents);}catch{fail('invalid-argument');}if(amountCents<=0||!['paid','scheduled'].includes(p.mode))fail('invalid-argument');paymentDate=date(p.paymentDate);expectedAccountVersion=ver(p.expectedAccountVersion);}else{paymentId=id(p.paymentId);if(action==='settle'){paymentDate=date(p.paymentDate);expectedAccountVersion=ver(p.expectedAccountVersion);}}
  const root=`households/${householdId}`,commandId=hash([uid,key]),fingerprint=hash(['partial-card-payment',householdId,action,p]);
  return runCardTransaction(db,async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   let paymentRef,old;if(action==='create'){paymentId=commandId;paymentRef=db.doc(`${root}/cardPayments/${paymentId}`);if((await tx.get(paymentRef)).exists)fail('already-exists');}else{paymentRef=db.doc(`${root}/cardPayments/${paymentId}`);const snapshot=await tx.get(paymentRef);if(!snapshot.exists)fail('not-found');old=snapshot.data();if(old.status!=='scheduled'||old.reversedAt!=null)fail('failed-precondition');cardId=id(old.cardId);accountId=id(old.accountId);competence=month(old.competence);amountCents=paymentCents(old);}
   const guardRef=db.doc(`${root}/cardOperationLocks/${cardId}`);await tx.get(guardRef);
   const household=await tx.get(db.doc(root));if(!household.exists)fail('not-found');let cutoff;try{cutoff=civilDate(today(household.data().timeZone));}catch{fail('failed-precondition');}
   if(action==='cancel'){const at=serverTimestamp(),result={paymentId,status:'cancelled'};tx.set(guardRef,{updatedAt:at});tx.update(paymentRef,{status:'cancelled',cancelledAt:at,cancelledBy:uid,updatedAt:at,updatedBy:uid});tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:'cardPayment.scheduleCancelled',actorId:uid,paymentId,createdAt:at});tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;}
   const accountRef=db.doc(`${root}/accounts/${accountId}`),accountSnapshot=await tx.get(accountRef),cardSnapshot=await tx.get(db.doc(`${root}/cards/${cardId}`));if(!accountSnapshot.exists)fail('not-found');const account=accountSnapshot.data(),legacy=account.schemaVersion!==1;if(account.archived===true||account.archivedAt!=null||(!legacy&&account.currency!=='BRL'))fail('failed-precondition');if(legacy?expectedAccountVersion!==null:account.version!==expectedAccountVersion)fail('version-conflict');
   const mode=action==='settle'?'paid':p.mode;if(mode==='paid'&&paymentDate>cutoff)fail('failed-precondition');if(mode==='scheduled'&&paymentDate<cutoff)fail('failed-precondition');
   const rowsSnapshot=await tx.get(db.collection(`${root}/transactions`).where('cardId','==',cardId)),recurrencesSnapshot=await tx.get(db.collection(`${root}/recurrences`).where('cardId','==',cardId)),paymentsSnapshot=await tx.get(db.collection(`${root}/cardPayments`).where('cardId','==',cardId));
   const rows=rowsSnapshot.docs.map(d=>d.data()),recurrences=recurrencesSnapshot.docs.map(d=>({id:d.id,...d.data()})),invoiceCents=invoiceAmountCents({rows,recurrences,card:cardSnapshot.exists?cardSnapshot.data():null,cardId,competence});const reserved=[];
   for(const entry of paymentsSnapshot.docs){const payment=entry.data();if(payment.reversedAt!=null||payment.status==='reversed'||payment.status==='cancelled')continue;if(typeof payment.competence!=='string'||!/^\d{4}-(0[1-9]|1[0-2])$/.test(payment.competence))fail('failed-precondition');if(payment.competence!==competence)continue;if(payment.status!=null&&!['paid','scheduled'].includes(payment.status))fail('failed-precondition');reserved.push(paymentCents(payment));}
   let allocated;try{allocated=sumCents(reserved);if(allocated>invoiceCents||(action==='create'&&sumCents([allocated,amountCents])>invoiceCents))fail('failed-precondition');}catch(error){if(error instanceof CommandError)throw error;fail('failed-precondition');}
   const balanceImpact=mode==='paid'&&(legacy||paymentDate>=date(account.openingDate));let balanceCents;if(balanceImpact&&!legacy){try{balanceCents=sumCents([account.balanceCents,-amountCents]);}catch{fail('failed-precondition');}}
   const at=serverTimestamp(),accountVersion=legacy?null:(balanceImpact?account.version+1:account.version),result={paymentId,status:mode,amountCents,accountVersion};tx.set(guardRef,{updatedAt:at});
   if(balanceImpact&&!legacy){tx.update(accountRef,{...cashReferencePatch(account),balanceCents,version:accountVersion,updatedAt:at,updatedBy:uid});tx.create(db.doc(`${root}/ledgerEntries/${commandId}`),{schemaVersion:1,type:'cardPayment',amountCents:-amountCents,effectiveDate:paymentDate,accountId,cardId,competence,currency:'BRL',paymentId,createdAt:at,createdBy:uid});}
   if(action==='create')tx.create(paymentRef,{schemaVersion:1,version:1,cardId,accountId,competence,amountCents,paymentDate,scheduledFor:mode==='scheduled'?paymentDate:null,balanceImpact,currency:'BRL',status:mode,reversedAt:null,createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid});
   else tx.update(paymentRef,{status:'paid',paymentDate,balanceImpact,version:Number(old.version||1)+1,settledAt:at,updatedAt:at,updatedBy:uid});
   tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:action==='settle'?'cardPayment.scheduleSettled':mode==='scheduled'?'cardPayment.scheduled':'cardPayment.partialPaid',actorId:uid,paymentId,createdAt:at});tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
  });
 };
}
