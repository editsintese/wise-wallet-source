import {createHash} from 'node:crypto';
import {civilDate,sumCents} from '../../packages/finance-domain/index.mjs';
import {bulkSnapshot,manualInstallmentReview} from '../../packages/finance-domain/bulk-transactions.mjs';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const stable=value=>Array.isArray(value)?value.map(stable):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,stable(value[key])])):value;
const hash=value=>createHash('sha256').update(JSON.stringify(stable(value))).digest('hex');
const id=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(value);
/** Cancel a complete, still-unpaid manual installment group. Never infer or reverse payment. */
export function createCancelManualInstallmentsHandler({db,serverTimestamp}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  if(!input||Object.keys(input).sort().join(',')!=='groupId,householdId,idempotencyKey,reason,reviewHash,snapshot,transactionId'||![input.householdId,input.idempotencyKey,input.groupId,input.transactionId].every(id)||typeof input.reviewHash!=='string'||! /^[a-f0-9]{64}$/.test(input.reviewHash)||typeof input.reason!=='string'||!input.reason.trim()||input.reason.length>240||!input.snapshot||typeof input.snapshot!=='object'||Array.isArray(input.snapshot))fail('invalid-argument');
  const {householdId,groupId,transactionId}=input,root=`households/${householdId}`,commandId=hash([uid,input.idempotencyKey]),fingerprint=hash(['cancel-manual-installments',input]);
  return db.runTransaction(async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const markerRef=db.doc(`${root}/cancelledManualInstallmentGroups/${groupId}`),marker=await tx.get(markerRef);if(marker.exists)fail('failed-precondition');
   const rows=await tx.get(db.collection(`${root}/transactions`).where('installmentGroupId','==',groupId));if(rows.empty)fail('not-found');
   let reviewed;try{reviewed=manualInstallmentReview(rows.docs.map(row=>({id:row.id,...row.data()})));}catch{fail('failed-precondition');}if(createHash('sha256').update(JSON.stringify(reviewed)).digest('hex')!==input.reviewHash)fail('version-conflict');
   const selected=rows.docs.find(row=>row.id===transactionId);if(!selected)fail('failed-precondition');
   let image;try{image=bulkSnapshot(selected.data());}catch{fail('failed-precondition');}if(hash(image)!==hash(input.snapshot))fail('version-conflict');
   const count=selected.data().installmentCount,seen=new Set(),items=[];if(!Number.isSafeInteger(count)||count<2||count>120||rows.size!==count)fail('failed-precondition');
   let total=0;
   for(const row of rows.docs){
    const data=row.data();let snapshot;try{snapshot=bulkSnapshot(data);civilDate(snapshot.date);total=sumCents([total,snapshot.amountCents]);}catch{fail('failed-precondition');}
    const n=data.installmentNumber,canonical=data.schemaVersion===1;
    if(data.schemaVersion!=null&&!canonical||!canonical&&(data.amountCents!=null||data.type!=null||data.version!=null||data.currency!=null)||canonical&&(data.currency!=='BRL'||!Number.isSafeInteger(data.version)||data.version<1||data.version>=Number.MAX_SAFE_INTEGER))fail('failed-precondition');
    if(data.cardId||data.recurrenceId||data.investmentId||data.transferId||data.historicalOnly||data.deletedAt!=null||snapshot.archived||snapshot.status!=='planned'||snapshot.settlementDate||data.settledAt!=null||data.effectiveDate!=null||data.paidAt!=null||data.settlementDate!=null||data.cancelledAt!=null||!['income','expense'].includes(snapshot.kind)||snapshot.kind!==image.kind||snapshot.accountId!==image.accountId||data.installmentCount!==count||!Number.isSafeInteger(n)||n<1||n>count||seen.has(n))fail('failed-precondition');
    if(data.manualEntryId!==selected.data().manualEntryId)fail('failed-precondition');
    const revision=canonical?data.version+1:(data.manualRevision??0)+1;if(!Number.isSafeInteger(revision)||revision<1||revision>=Number.MAX_SAFE_INTEGER)fail('failed-precondition');
    const historyRef=db.doc(`${row.ref.path}/revisions/${canonical?revision:'manual-'+revision}`);if((await tx.get(historyRef)).exists)fail('failed-precondition');
    seen.add(n);items.push({ref:row.ref,data,canonical,revision,historyRef});
   }
   const at=serverTimestamp(),reason=input.reason.trim(),result={groupId,count,totalCents:total,status:'cancelled'};
   for(const item of items){const patch={status:'cancelled',manualManaged:true,cancelledAt:at,cancelledBy:uid,updatedAt:at,updatedBy:uid,...(item.canonical?{version:item.revision}:{manualRevision:item.revision})};tx.update(item.ref,patch);tx.create(item.historyRef,{...item.data,...patch,previous:item.data,reason,commandId,action:'manual-installments.cancel'});}
   tx.create(markerRef,{groupId,count,commandId,createdAt:at,createdBy:uid});tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:'manual-installments.cancel',actorId:uid,groupId,count,reason,createdAt:at});tx.create(receiptRef,{fingerprint,result,createdAt:at});return result;
  });
 };
}
