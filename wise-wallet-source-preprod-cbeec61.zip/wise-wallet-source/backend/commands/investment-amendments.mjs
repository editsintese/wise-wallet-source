import {cashReferencePatch} from './cash-reference.mjs';
import {createHash} from 'node:crypto';
import {sumCents, civilDate} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const id=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))fail('invalid-argument');return value;};
const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))fail('invalid-argument');};
function number(value,min=0){if(!Number.isSafeInteger(value)||value<min||value>=Number.MAX_SAFE_INTEGER)fail('invalid-argument');return value;}
function money(value){const cents=Math.round(value*100);if(typeof value!=='number'||!Number.isSafeInteger(cents)||cents<0||Math.abs(value-cents/100)>1e-7)fail('failed-precondition');return cents;}
function amounts(snapshot){if(!snapshot)return {invested:0,current:0};return {invested:money(snapshot.investedValue),current:money(snapshot.currentValue)};}
const fields=['name','institution','type','referenceDate','investedValue','currentValue','version'];
/** Amend only the latest operation. Never replay later valuations or infer historical links. */
export function createInvestmentAmendmentHandler({db,serverTimestamp}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  exact(input,['householdId','idempotencyKey','action','payload']);
  const householdId=id(input.householdId),key=id(input.idempotencyKey),{action,payload:p}=input;
  if(!['correct','reverse'].includes(action))fail('invalid-argument');
  exact(p,['investmentId','expectedVersion','expectedAccountVersion','reason',...(action==='correct'?['amountCents','currentCents']:[])]);
  const investmentId=id(p.investmentId);number(p.expectedVersion,1);if(p.expectedAccountVersion!==null)number(p.expectedAccountVersion,1);
  if(typeof p.reason!=='string'||!p.reason.trim()||p.reason.length>160)fail('invalid-argument');
  const root=`households/${householdId}`,commandId=hash([uid,key]),fingerprint=hash(['investment',action,p,householdId]);
  return db.runTransaction(async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);
   if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const ref=db.doc(`${root}/investments/${investmentId}`),snapshot=await tx.get(ref);if(!snapshot.exists)fail('not-found');const old=snapshot.data();
   if(old.schemaVersion!==1||old.archivedAt!=null||old.archived===true)fail('failed-precondition');
   if(old.version!==p.expectedVersion)fail('version-conflict');
   const sourceSnapshot=await tx.get(db.doc(`${root}/investments/${investmentId}/revisions/${p.expectedVersion}`));if(!sourceSnapshot.exists)fail('failed-precondition');const source=sourceSnapshot.data();
   const operation=source.operation||source.action;
   if(!['create','contribution','withdrawal','valuation'].includes(operation)||!['create','contribution','withdrawal','valuation','correct'].includes(source.action)||!source.next||fields.some(k=>source.next[k]!==old[k]))fail('failed-precondition');
   const basis=source.action==='correct'?source.basis:source.previous;
   if(basis===undefined||(operation==='create'?basis!==null:!basis))fail('failed-precondition');
   const before=amounts(basis),present=amounts(old);if(old.investedCents!==present.invested||old.currentCents!==present.current)fail('failed-precondition');
   const financial=operation!=='valuation';
   if(!financial&&p.expectedAccountVersion!==null)fail('invalid-argument');
   if(action==='correct'){
    if(financial)number(p.amountCents,1);else if(p.amountCents!==null)fail('invalid-argument');
    if(operation==='create'||operation==='valuation')number(p.currentCents);else if(p.currentCents!==null)fail('invalid-argument');
   }
   let nextInvested=before.invested,nextCurrent=before.current;
   if(action==='correct'){
    try{
     if(operation==='create'){nextInvested=p.amountCents;nextCurrent=p.currentCents;}
     if(operation==='valuation')nextCurrent=p.currentCents;
     if(operation==='contribution'){nextInvested=sumCents([before.invested,p.amountCents]);nextCurrent=sumCents([before.current,p.amountCents]);}
     if(operation==='withdrawal'){if(p.amountCents>before.current)fail('failed-precondition');nextInvested=Math.max(0,before.invested-p.amountCents);nextCurrent=before.current-p.amountCents;}
    }catch{fail('failed-precondition');}
   }
   const version=old.version+1,historyRef=db.doc(`${root}/investments/${investmentId}/revisions/${version}`);if((await tx.get(historyRef)).exists)fail('failed-precondition');
   let accountRef,account,canonical=false,balanceCents,transactionRef,movement,oldAmount,transactionId;
   if(financial){
    transactionId=id(source.transactionId||source.commandId);transactionRef=db.doc(`${root}/transactions/${transactionId}`);
    const movementSnapshot=await tx.get(transactionRef);if(!movementSnapshot.exists)fail('failed-precondition');movement=movementSnapshot.data();
    if(movement.investmentId!==investmentId||movement.investmentVersion!==old.version||movement.investmentOperation!==operation||movement.status!=='realized'||movement.archivedAt!=null||movement.deletedAt!=null||movement.archived===true)fail('failed-precondition');
    accountRef=db.doc(`${root}/accounts/${id(movement.accountId)}`);const accountSnapshot=await tx.get(accountRef);if(!accountSnapshot.exists)fail('not-found');account=accountSnapshot.data();canonical=account.schemaVersion===1;
    if(account.archivedAt!=null||account.archived===true||account.deletedAt!=null)fail('failed-precondition');
    const expectedKind=operation==='withdrawal'?'income':'expense';
    if(canonical){
     if(movement.schemaVersion!==1||movement.type!==expectedKind||movement.currency!=='BRL'||account.currency!=='BRL'||!Number.isSafeInteger(account.balanceCents))fail('failed-precondition');
     number(account.version,1);number(movement.version,1);if(account.version!==p.expectedAccountVersion)fail('version-conflict');oldAmount=number(movement.amountCents,1);
    }else{
     if(account.schemaVersion!=null||account.version!=null||account.balanceCents!=null||account.openingBalanceCents!=null||p.expectedAccountVersion!==null||movement.schemaVersion!=null||movement.amountCents!=null||movement.kind!==expectedKind)fail('failed-precondition');oldAmount=money(movement.amount);if(oldAmount<=0)fail('failed-precondition');
    }
    const originalDate=canonical?movement.settlementDate:movement.paidAt;
    if(originalDate!==old.referenceDate)fail('failed-precondition');
    try{civilDate(originalDate);}catch{fail('failed-precondition');}
    // Validate that the latest recorded movement actually explains the position delta.
    const expectedInvested=operation==='create'?oldAmount:operation==='contribution'?sumCents([before.invested,oldAmount]):Math.max(0,before.invested-oldAmount);
    const expectedCurrent=operation==='create'?present.current:operation==='contribution'?sumCents([before.current,oldAmount]):before.current-oldAmount;
    if(expectedInvested!==present.invested||expectedCurrent!==present.current)fail('failed-precondition');
    if(canonical){const sign=expectedKind==='income'?1:-1;try{balanceCents=sumCents([account.balanceCents,-sign*oldAmount,...(action==='correct'?[sign*p.amountCents]:[])]);}catch{fail('failed-precondition');}}
   }
   // No reads below. A rejected callback commits none of the queued writes.
   const at=serverTimestamp(),restore=action==='reverse'&&basis?Object.fromEntries(['name','institution','type','referenceDate'].map(k=>[k,basis[k]])):{};
   const next={...old,...restore,version,investedCents:nextInvested,currentCents:nextCurrent,investedValue:nextInvested/100,currentValue:nextCurrent/100,updatedAt:at,updatedBy:uid,...(action==='reverse'&&operation==='create'?{archivedAt:at}:{})};
   tx.update(ref,next);
   tx.create(historyRef,{action,operation,basis,previous:old,next,sourceVersion:old.version,commandId,...(financial?{transactionId}:{}),reason:p.reason.trim(),actorId:uid,createdAt:at});
   if(financial){
    const nextMovement={...movement,investmentVersion:version,updatedAt:at,updatedBy:uid,...(canonical?{version:movement.version+1}:{investmentMovementRevision:(movement.investmentMovementRevision||1)+1}),...(action==='reverse'?{status:'cancelled',cancelledAt:at,cancellationReason:p.reason.trim()}:canonical?{amountCents:p.amountCents}:{amount:p.amountCents/100})};
    const transactionVersion=canonical?nextMovement.version:nextMovement.investmentMovementRevision;
    const sign=operation==='withdrawal'?1:-1,day=canonical?movement.settlementDate:movement.paidAt;
    tx.update(transactionRef,nextMovement);
    tx.create(db.doc(`${root}/transactions/${transactionId}/revisions/${transactionVersion}`),{...nextMovement,action:`investment.${action}`,previous:movement,reason:p.reason.trim(),commandId});
    if(canonical)tx.update(accountRef,{...cashReferencePatch(account),balanceCents,version:account.version+1,updatedAt:at,updatedBy:uid});
    tx.create(db.doc(`${root}/ledgerEntries/${commandId}_reversal`),{schemaVersion:1,type:'transactionReversal',amountCents:-sign*oldAmount,transactionId,investmentId,transactionVersion,reversesVersion:canonical?movement.version:movement.investmentMovementRevision||1,accountId:movement.accountId,currency:'BRL',effectiveDate:day,createdAt:at,createdBy:uid});
    if(canonical&&action==='correct')tx.create(db.doc(`${root}/ledgerEntries/${commandId}_effect`),{schemaVersion:1,type:movement.type,amountCents:sign*p.amountCents,accountId:movement.accountId,transactionId,transactionVersion,investmentId,effectiveDate:day,currency:'BRL',createdAt:at,createdBy:uid});
   }
   const result={investmentId,version,...(financial?{transactionId,accountVersion:canonical?account.version+1:null}:{}),action};
   tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`investment.${action}`,actorId:uid,investmentId,sourceVersion:old.version,reason:p.reason.trim(),createdAt:at});
   tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
  });
 };
}
