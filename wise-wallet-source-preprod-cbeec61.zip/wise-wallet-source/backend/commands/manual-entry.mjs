import {cashReferencePatch} from './cash-reference.mjs';
import {createHash} from 'node:crypto';
import {civilDate, addMonths, splitInstallments, sumCents} from '../../packages/finance-domain/index.mjs';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const id=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))fail('invalid-argument');return value;};
const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))fail('invalid-argument');};
function text(value,max,empty=false){if(typeof value!=='string'||value.length>max||(!empty&&!value.trim()))fail('invalid-argument');return value.trim();}
function date(value){try{return civilDate(value);}catch{fail('invalid-argument');}}
function validate(input){
 exact(input,['householdId','idempotencyKey','payload']);const householdId=id(input.householdId),idempotencyKey=id(input.idempotencyKey),p=input.payload;
 exact(p,['description','category','subcategory','owner','amountCents','kind','status','accountId','expectedAccountVersion','purchaseDate','firstDate','count','historicalOnly',...(p&&Object.hasOwn(p,'recurrence')?['recurrence']:[])]);
 if(!Number.isSafeInteger(p.amountCents)||p.amountCents<=0||!Number.isInteger(p.count)||p.count<1||p.count>120||p.amountCents<p.count||!['income','expense'].includes(p.kind)||!['realized','planned'].includes(p.status)||typeof p.historicalOnly!=='boolean')fail('invalid-argument');
 let recurrence;
 if(Object.hasOwn(p,'recurrence')){exact(p.recurrence,['frequency','endDate']);if(!['monthly','weekly','yearly'].includes(p.recurrence.frequency)||p.count!==1||p.historicalOnly||!p.accountId)fail('invalid-argument');const endDate=p.recurrence.endDate===''?'':date(p.recurrence.endDate);if(endDate&&endDate<date(p.firstDate))fail('invalid-argument');recurrence={frequency:p.recurrence.frequency,endDate};}
 const accountId=p.accountId===''?'':id(p.accountId);
 if(p.expectedAccountVersion!==null&&(!Number.isSafeInteger(p.expectedAccountVersion)||p.expectedAccountVersion<1||p.expectedAccountVersion>=Number.MAX_SAFE_INTEGER))fail('invalid-argument');
 if(!accountId&&p.expectedAccountVersion!==null)fail('invalid-argument');
 if(p.historicalOnly&&(p.kind!=='income'||p.status!=='realized'||p.count!==1||accountId!==''))fail('invalid-argument');
 return {householdId,idempotencyKey,payload:{description:text(p.description,240),category:text(p.category,80),subcategory:text(p.subcategory,80,true),owner:text(p.owner,80),amountCents:p.amountCents,kind:p.kind,status:p.status,accountId,expectedAccountVersion:p.expectedAccountVersion,purchaseDate:date(p.purchaseDate),firstDate:date(p.firstDate),count:p.count,historicalOnly:p.historicalOnly,...(recurrence?{recurrence}:{})}};
}
/** Creation of one manual operation, with all its installments, in a single transaction.
 * Card purchases, standalone rule registration and edits retain their separate contracts.
 */
export function createManualEntryHandler({db,serverTimestamp,today=timeZone=>new Intl.DateTimeFormat('en-CA',{timeZone}).format(new Date())}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  const command=validate(input),{householdId,payload:p}=command,root=`households/${householdId}`,commandId=hash([uid,command.idempotencyKey]),fingerprint=hash(['manual-entry',command]);
  let dates,amounts;try{dates=Array.from({length:p.count},(_,i)=>addMonths(p.firstDate,i));amounts=splitInstallments(p.amountCents,p.count);}catch{fail('invalid-argument');}
  return db.runTransaction(async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);
   if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const household=await tx.get(db.doc(root));if(!household.exists)fail('not-found');
   let cutoff;try{cutoff=civilDate(today(household.data().timeZone));}catch{fail('failed-precondition');}
   if(p.status==='realized'&&p.firstDate>cutoff)fail('failed-precondition');
   let accountRef,account,canonical=false,balanceCents;
   if(p.accountId){
    accountRef=db.doc(`${root}/accounts/${p.accountId}`);const snapshot=await tx.get(accountRef);if(!snapshot.exists)fail('not-found');account=snapshot.data();
    if(account.archivedAt!=null||account.archived===true||account.deletedAt!=null)fail('failed-precondition');
    canonical=account.schemaVersion===1;
    if(canonical){
     if(account.currency!=='BRL'||!Number.isSafeInteger(account.version)||account.version<1||account.version>=Number.MAX_SAFE_INTEGER||!Number.isSafeInteger(account.balanceCents))fail('failed-precondition');
     if(account.version!==p.expectedAccountVersion)fail('version-conflict');
     let opening;try{opening=civilDate(account.openingDate);}catch{fail('failed-precondition');}
     if(p.status==='realized'&&p.firstDate<opening)fail('failed-precondition');
     if(p.status==='realized')try{balanceCents=sumCents([account.balanceCents,(p.kind==='income'?1:-1)*amounts[0]]);}catch{fail('failed-precondition');}
    }else{
     if(account.schemaVersion!=null||account.version!=null||account.balanceCents!=null||account.openingBalanceCents!=null||p.expectedAccountVersion!==null)fail('failed-precondition');
     if(account.openingBalance!=null&&(typeof account.openingBalance!=='number'||!Number.isFinite(account.openingBalance)))fail('failed-precondition');
    }
   }
   const refs=dates.map((_,i)=>db.doc(`${root}/transactions/${p.count===1?commandId:commandId+'_'+(i+1)}`));
   for(const ref of refs)if((await tx.get(ref)).exists)fail('already-exists');
   const recurrenceRef=p.recurrence?db.doc(`${root}/recurrences/${commandId}_rule`):null;
   if(recurrenceRef&&(await tx.get(recurrenceRef)).exists)fail('already-exists');
   const occurrenceKey=p.recurrence?.frequency==='weekly'?p.firstDate:p.firstDate.slice(0,7);
   const at=serverTimestamp(),groupId=p.count>1?commandId:null;
   const accountVersion=canonical?(balanceCents!==undefined?account.version+1:account.version):null;
   const result={transactionIds:refs.map(ref=>ref.id||ref.path.split('/').at(-1)),installmentGroupId:groupId,accountVersion,...(recurrenceRef?{recurrenceId:recurrenceRef.id}: {})};
   // Every read is complete. Any create/update failure rolls back the entire operation.
   for(let i=0;i<p.count;i++){
    const status=i===0?p.status:'planned',realized=status==='realized',day=dates[i];
    const common={description:p.description,category:p.category,subcategory:p.subcategory,owner:p.owner,accountId:p.accountId,manualEntryId:commandId,status,purchaseDate:p.purchaseDate,installmentNumber:groupId?i+1:null,installmentCount:groupId?p.count:null,installmentGroupId:groupId,createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid,...(recurrenceRef?{recurrenceId:recurrenceRef.id,occurrenceMonth:occurrenceKey,scheduledDate:p.firstDate,recurrencePending:status==='planned'}:{})};
    // Canonical historical income has no account and uses the established historical contract.
    const historical=p.historicalOnly;
    const row=canonical||historical?{...common,schemaVersion:1,version:1,type:p.kind,currency:'BRL',amountCents:amounts[i],competenceDate:day,dueDate:day,settlementDate:realized?day:null,effectiveDate:realized?day:null,settledAt:realized?at:null,archivedAt:null,deletedAt:null,...(historical?{historicalOnly:true,balanceImpact:false}:{})}:{...common,kind:p.kind,amount:amounts[i]/100,transactionDate:day,paidAt:realized?day:null,clientGeneration:'post-cutover',...(!p.accountId?{balanceImpact:false}:{})};
    tx.create(refs[i],row);
    tx.create(db.doc(`${refs[i].path}/revisions/1`),{...row,action:'manual-entry.create',commandId});
    if(canonical&&realized)tx.create(db.doc(`${root}/ledgerEntries/${commandId}_${i+1}_effect`),{schemaVersion:1,type:p.kind,amountCents:(p.kind==='income'?1:-1)*amounts[i],accountId:p.accountId,transactionId:result.transactionIds[i],transactionVersion:1,currency:'BRL',effectiveDate:day,createdAt:at,createdBy:uid});
   }
   if(recurrenceRef)tx.create(recurrenceRef,{description:p.description,category:p.category,subcategory:p.subcategory,owner:p.owner,amount:p.amountCents/100,kind:p.kind,accountId:p.accountId,cardId:'',frequency:p.recurrence.frequency,startDate:p.firstDate,endDate:p.recurrence.endDate,dueDay:Number(p.firstDate.slice(8,10)),active:true,monthsOfYear:[],monthlyAmounts:{},ruleRevision:1,settledMonths:p.status==='realized'?[occurrenceKey]:[],occurrenceTransactions:p.status==='realized'?{[occurrenceKey]:result.transactionIds[0]}:{},pendingOccurrenceTransactions:p.status==='planned'?{[occurrenceKey]:result.transactionIds[0]}:{},createdAt:at,createdBy:uid,updatedAt:at,updatedBy:uid});
   if(balanceCents!==undefined)tx.update(accountRef,{...cashReferencePatch(account),balanceCents,version:accountVersion,updatedAt:at,updatedBy:uid});
   tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:'manual-entry.create',actorId:uid,transactionIds:result.transactionIds,installmentGroupId:groupId,createdAt:at});
   tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
  });
 };
}
