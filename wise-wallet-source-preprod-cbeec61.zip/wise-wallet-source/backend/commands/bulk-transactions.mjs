import {cashReferencePatch} from './cash-reference.mjs';
import {createHash} from 'node:crypto';
import {civilDate,sumCents} from '../../packages/finance-domain/index.mjs';
import {bulkSnapshot,bulkBlockReason} from '../../packages/finance-domain/bulk-transactions.mjs';
import {CommandError} from './transfer.mjs';
const fail=code=>{throw new CommandError(code);};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const id=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(value))fail('invalid-argument');return value;};
const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))fail('invalid-argument');};
const version=value=>{if(value!==null&&(!Number.isSafeInteger(value)||value<1||value>=Number.MAX_SAFE_INTEGER))fail('invalid-argument');return value;};
const snapshotKeys=['schema','version','bulkRevision','description','category','subcategory','owner','amountCents','kind','status','accountId','date','purchaseDate','settlementDate','archived'];
function validate(input){
 exact(input,['householdId','idempotencyKey','action','items','accounts','settlementDate']);
 const householdId=id(input.householdId),idempotencyKey=id(input.idempotencyKey),action=input.action;
 if(!['pay','archive','restore'].includes(action)||!Array.isArray(input.items)||input.items.length<1||input.items.length>100||!Array.isArray(input.accounts)||input.accounts.length>100)fail('invalid-argument');
 const items=input.items.map(entry=>{exact(entry,['transactionId','snapshot']);id(entry.transactionId);exact(entry.snapshot,snapshotKeys);const snapshot=Object.fromEntries(snapshotKeys.map(k=>[k,entry.snapshot[k]]));if(!['canonical','legacy'].includes(snapshot.schema)||typeof snapshot.archived!=='boolean'||!Number.isSafeInteger(snapshot.amountCents)||snapshot.amountCents<=0||!Number.isSafeInteger(snapshot.bulkRevision)||snapshot.bulkRevision<0||snapshot.bulkRevision>=Number.MAX_SAFE_INTEGER)fail('invalid-argument');version(snapshot.version);for(const k of snapshotKeys.filter(k=>!['version','bulkRevision','amountCents','archived'].includes(k)))if(typeof snapshot[k]!=='string'||snapshot[k].length>300)fail('invalid-argument');return {transactionId:entry.transactionId,snapshot};}).sort((a,b)=>a.transactionId.localeCompare(b.transactionId));
 if(new Set(items.map(i=>i.transactionId)).size!==items.length)fail('invalid-argument');
 const accounts=input.accounts.map(entry=>{exact(entry,['accountId','expectedVersion']);return {accountId:id(entry.accountId),expectedVersion:version(entry.expectedVersion)};}).sort((a,b)=>a.accountId.localeCompare(b.accountId));
 if(new Set(accounts.map(a=>a.accountId)).size!==accounts.length)fail('invalid-argument');
 let settlementDate=null;if(action==='pay'){try{settlementDate=civilDate(input.settlementDate);}catch{fail('invalid-argument');}}else if(input.settlementDate!==null||accounts.length)fail('invalid-argument');
 return {householdId,idempotencyKey,action,items,accounts,settlementDate};
}
/** At most 100 manual rows; all financial changes commit together or none do. */
export function createBulkTransactionHandler({db,serverTimestamp,today=timeZone=>new Intl.DateTimeFormat('en-CA',{timeZone}).format(new Date())}){
 return async(uid,input)=>{
  if(typeof uid!=='string'||!uid||uid.length>128||/[/\x00-\x1f]/.test(uid)||['.','..'].includes(uid))fail('unauthenticated');
  const command=validate(input),{householdId,action,items,accounts,settlementDate}=command,root=`households/${householdId}`,commandId=hash([uid,command.idempotencyKey]),fingerprint=hash(['bulk-transactions',command]);
  return db.runTransaction(async tx=>{
   const member=await tx.get(db.doc(`${root}/members/${uid}`));if(!member.exists||member.data().status!=='active'||!['owner','admin','member'].includes(member.data().role))fail('permission-denied');
   const receiptRef=db.doc(`${root}/commandReceipts/${commandId}`),receipt=await tx.get(receiptRef);if(receipt.exists){if(receipt.data().fingerprint!==fingerprint)fail('idempotency-conflict');return receipt.data().result;}
   const selected=[];
   for(const entry of items){const ref=db.doc(`${root}/transactions/${entry.transactionId}`),snapshot=await tx.get(ref),data=snapshot.exists?snapshot.data():null;let reason=data?bulkBlockReason(action,data):'not-found';if(data&&!reason){try{if(JSON.stringify(bulkSnapshot(data))!==JSON.stringify(entry.snapshot))reason='stale-selection';}catch{reason='invalid-record';}}selected.push({...entry,ref,data,reason});}
   const accountStates=new Map(),deltas=new Map();
   if(action==='pay'){
    const required=[...new Set(selected.filter(row=>!row.reason).map(row=>row.data.accountId))].sort();
    const supplied=new Map(accounts.map(account=>[account.accountId,account.expectedVersion]));
    let cutoff;const household=await tx.get(db.doc(root));if(!household.exists)fail('not-found');try{cutoff=civilDate(today(household.data().timeZone));}catch{fail('failed-precondition');}
    for(const accountId of required){
     id(accountId);const ref=db.doc(`${root}/accounts/${accountId}`),snapshot=await tx.get(ref),data=snapshot.exists?snapshot.data():null;let reason=null;
     if(!data)reason='missing-account';
     else if(data.archivedAt!=null||data.archived===true||data.deletedAt!=null)reason='inactive-account';
     else if(data.schemaVersion===1){if(data.currency!=='BRL'||!Number.isSafeInteger(data.balanceCents)||!Number.isSafeInteger(data.version)||data.version<1||data.version>=Number.MAX_SAFE_INTEGER)reason='invalid-account';else if(!supplied.has(accountId)||supplied.get(accountId)!==data.version)reason='stale-account';else{try{if(settlementDate>cutoff||settlementDate<civilDate(data.openingDate))reason='invalid-date';}catch{reason='invalid-date';}}}
     else if(data.schemaVersion!=null||data.version!=null||data.balanceCents!=null||data.openingBalanceCents!=null)reason='mixed-schema';
     else if(!supplied.has(accountId)||supplied.get(accountId)!==null)reason='stale-account';
     else if(settlementDate>cutoff)reason='invalid-date';
     accountStates.set(accountId,{ref,data,reason});
    }
    // No hidden/extraneous account targets are accepted.
    if(accounts.some(account=>!items.some(row=>row.snapshot.accountId===account.accountId)))fail('invalid-argument');
    for(const row of selected)if(!row.reason){const account=accountStates.get(row.data.accountId);if(account.reason)row.reason=account.reason;else if((row.data.manualManaged?row.data.cashAccountSchema:row.data.schemaVersion===1?'canonical':'legacy')!==(account.data.schemaVersion===1?'canonical':'legacy'))row.reason='mixed-schema';else if(account.data.schemaVersion===1){try{deltas.set(row.data.accountId,sumCents([deltas.get(row.data.accountId)||0,((row.data.type||row.data.kind)==='income'?1:-1)*bulkSnapshot(row.data).amountCents]));}catch{row.reason='overflow';}}}
    for(const [accountId,delta] of deltas){try{accountStates.get(accountId).nextBalance=sumCents([accountStates.get(accountId).data.balanceCents,delta]);}catch{for(const row of selected)if(row.data?.accountId===accountId&&!row.reason)row.reason='overflow';}}
   }
   const rejected=selected.some(row=>row.reason),result={action,applied:!rejected,items:selected.map(row=>({transactionId:row.transactionId,status:rejected?(row.reason?'blocked':'not-applied'):'applied',...(row.reason?{reason:row.reason}:{})}))};
   const at=serverTimestamp();
   // All reads complete. A rejected lot writes a receipt/audit only, never rows or balances.
   if(!rejected){
    for(const row of selected){const canonical=row.data.schemaVersion===1,revision=canonical?row.data.version+1:(row.data.bulkRevision||0)+1;
     const patch={updatedAt:at,updatedBy:uid,...(canonical?{version:revision}:{bulkRevision:revision}),...(action==='pay'?{status:'realized',...(canonical?{settlementDate,effectiveDate:settlementDate,settledAt:at}:{paidAt:settlementDate})}:canonical?{archivedAt:action==='archive'?at:null}:{archived:action==='archive',archivedAt:action==='archive'?at:null})};
     tx.update(row.ref,patch);tx.create(db.doc(`${row.ref.path}/revisions/${canonical?revision:'bulk-'+revision}`),{...row.data,...patch,previous:row.data,action:`bulk.${action}`,commandId});
     if(action==='pay'&&accountStates.get(row.data.accountId)?.data.schemaVersion===1)tx.create(db.doc(`${root}/ledgerEntries/${commandId}_${row.transactionId}`),{schemaVersion:1,type:row.data.type||row.data.kind,amountCents:((row.data.type||row.data.kind)==='income'?1:-1)*bulkSnapshot(row.data).amountCents,transactionId:row.transactionId,transactionVersion:revision,accountId:row.data.accountId,effectiveDate:settlementDate,currency:'BRL',createdAt:at,createdBy:uid});
    }
    for(const state of accountStates.values())if(state.nextBalance!==undefined)tx.update(state.ref,{...cashReferencePatch(state.data),balanceCents:state.nextBalance,version:state.data.version+1,updatedAt:at,updatedBy:uid});
   }
   tx.create(db.doc(`${root}/auditEvents/${commandId}`),{schemaVersion:1,type:`bulk.${action}`,actorId:uid,applied:!rejected,transactionIds:items.map(item=>item.transactionId),createdAt:at});
   tx.create(receiptRef,{schemaVersion:1,fingerprint,result,createdAt:at});return result;
  });
 };
}
