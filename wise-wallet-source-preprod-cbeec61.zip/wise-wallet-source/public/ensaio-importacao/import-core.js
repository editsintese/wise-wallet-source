/* Local-only CSV preview engine. No I/O, storage, network, or automatic import. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.WiseImportCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const REQUIRED = ['data', 'descricao', 'valor', 'tipo'];
  const ALIASES = {
    data: ['data', 'data_compra'], descricao: ['descricao', 'descrição'],
    valor: ['valor', 'valor_brl'], tipo: ['tipo'], categoria: ['categoria', 'categoria_sugerida'],
    situacao: ['situacao', 'situação', 'status'], parcela: ['parcela', 'parcelas'],
    id_compra: ['id_compra', 'compra_id'], valor_compra: ['valor_compra', 'total_compra'],
    reference: ['referencia', 'referência', 'reference', 'id_referencia', 'id_referência'],
    periodo_documento: ['periodo_documento', 'período_documento', 'mes_documento', 'mês_documento', 'mes_referencia', 'mês_referencia', 'ciclo_fatura'],
    total_arquivo: ['total_arquivo', 'total_documento']
  };
  const TYPES = new Set(['receita', 'despesa', 'compra_cartao', 'parcela_cartao', 'transferencia', 'pagamento_fatura']);
  const STATUS = new Set(['realizado', 'compromisso', 'estimativa']);
  const MAX_BYTES = 5 * 1024 * 1024;
  const MAX_ROWS = 10000;
  const CRC32_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; table[n] = c >>> 0; }
    return table;
  })();

  function fail(code, message) { const error = new Error(message); error.code = code; throw error; }
  function crc32(bytes) { let crc = 0xffffffff; for (const byte of bytes) crc = CRC32_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8); return (crc ^ 0xffffffff) >>> 0; }
  function validateXLSXInflate(buffer, entriesInfo, { Unzip, UnzipInflate, UnzipPassThrough }) {
    let total = 0, failure = null, mismatch = false;
    const expected = new Map(entriesInfo.map(entry => [entry.name, entry]));
    const seen = new Set();
    const unzipper = new Unzip(file => {
      if (failure) return;
      const entry = expected.get(file.name);
      if (!entry || seen.has(file.name)) { failure = new Error('ZIP entry list differs from validated directory.'); failure.code = 'XLSX_ZIP'; return; }
      seen.add(file.name);
      let size = 0, crc = 0xffffffff;
      file.ondata = (error, chunk, final) => {
        if (failure) return;
        if (error) { failure = error; return; }
        if (chunk?.length) {
          size += chunk.length; total += chunk.length;
          if (size > 10 * 1024 * 1024 || total > 25 * 1024 * 1024) {
            failure = new Error('XLSX decompressed output exceeded the streaming limit.');
            failure.code = 'XLSX_EXPANDED_SIZE';
            throw failure;
          }
          for (const byte of chunk) crc = CRC32_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
        }
        if (final && (size !== entry.expanded || ((crc ^ 0xffffffff) >>> 0) !== entry.crc)) mismatch = true;
      };
      try { file.start(); } catch (error) { failure = error; }
    });
    unzipper.register(UnzipPassThrough);
    unzipper.register(UnzipInflate);
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    try {
      // Small compressed-input slices keep fflate's synchronous Inflate output buffers bounded.
      const inputChunk = 64;
      for (let offset = 0; offset < bytes.length; offset += inputChunk) {
        const end = Math.min(offset + inputChunk, bytes.length);
        unzipper.push(bytes.subarray(offset, end), end === bytes.length);
        if (failure) break;
      }
    } catch (error) { if (!failure) failure = error; }
    if (failure) fail(failure.code || 'XLSX_INVALID', failure.code === 'XLSX_EXPANDED_SIZE' ? 'Conteúdo descompactado excede o limite local durante a expansão.' : 'Planilha XLSX inválida ou não suportada.');
    if (seen.size !== entriesInfo.length) fail('XLSX_INVALID', 'Pacote XLSX incompleto.');
    if (mismatch) fail('XLSX_INVALID', 'Tamanho ou checksum de entrada XLSX divergente.');
    return true;
  }
  function normalizeHeader(value) { return String(value ?? '').trim().toLocaleLowerCase('pt-BR').replace(/\s+/g, '_'); }
  function chooseDelimiter(text) {
    const first = String(text).replace(/^\uFEFF/, '').split(/\r?\n/, 1)[0];
    let quoted = false, semicolons = 0, commas = 0;
    for (let i = 0; i < first.length; i++) {
      if (first[i] === '"' && first[i + 1] === '"' && quoted) { i++; continue; }
      if (first[i] === '"') quoted = !quoted;
      else if (!quoted && first[i] === ';') semicolons++;
      else if (!quoted && first[i] === ',') commas++;
    }
    if (!semicolons && !commas) fail('CSV_DELIMITER', 'Cabeçalho CSV sem separador reconhecido.');
    return semicolons >= commas ? ';' : ',';
  }
  function parseGrid(text) {
    if (typeof text !== 'string' || text.includes('\0')) fail('CSV_TEXT', 'Arquivo CSV inválido.');
    const delimiter = chooseDelimiter(text), rows = [];
    let row = [], field = '', quoted = false, afterQuote = false;
    let physicalLine = 1, recordStartLine = 1;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (quoted) {
        if (ch === '"' && text[i + 1] === '"') { field += '"'; i++; }
        else if (ch === '"') { quoted = false; afterQuote = true; }
        else { field += ch; if (ch === '\n') physicalLine++; }
      } else if (afterQuote) {
        if (ch === delimiter) { row.push(field); field = ''; afterQuote = false; }
        else if (ch === '\n') { row.push(field); rows.push({ cells: row, line: recordStartLine }); row = []; field = ''; afterQuote = false; physicalLine++; recordStartLine = physicalLine; }
        else if (ch === '\r' && text[i + 1] === '\n') { row.push(field); rows.push({ cells: row, line: recordStartLine }); row = []; field = ''; afterQuote = false; i++; physicalLine++; recordStartLine = physicalLine; }
        else fail('CSV_QUOTE', 'Texto após fechamento de aspas no CSV.');
      } else if (ch === '"') {
        if (field.length) fail('CSV_QUOTE', 'Aspas em posição inválida no CSV.');
        quoted = true;
      } else if (ch === delimiter) { row.push(field); field = ''; }
      else if (ch === '\n') { row.push(field.replace(/\r$/, '')); rows.push({ cells: row, line: recordStartLine }); row = []; field = ''; physicalLine++; recordStartLine = physicalLine; }
      else if (ch === '\r' && text[i + 1] === '\n') { row.push(field); rows.push({ cells: row, line: recordStartLine }); row = []; field = ''; i++; physicalLine++; recordStartLine = physicalLine; }
      else field += ch;
    }
    if (quoted) fail('CSV_QUOTE', 'Campo entre aspas não foi fechado.');
    if (field.length || row.length) { row.push(field.replace(/\r$/, '')); rows.push({ cells: row, line: recordStartLine }); }
    while (rows.length && rows[rows.length - 1].cells.every(cell => !cell.trim())) rows.pop();
    if (rows.length < 2) fail('CSV_EMPTY', 'CSV precisa de cabeçalho e pelo menos uma linha.');
    if (rows.length - 1 > MAX_ROWS) fail('CSV_ROWS', 'Limite local de linhas excedido.');
    const headers = rows.shift().cells;
    return { rows, headers, delimiter };
  }
  function parseDate(raw) {
    const value = String(raw ?? '').trim();
    let y, m, d;
    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) [y, m, d] = value.split('-').map(Number);
    else if (/^\d{2}\/\d{2}\/\d{4}$/.test(value)) { const p = value.split('/').map(Number); [d, m, y] = p; }
    else return null;
    const date = new Date(Date.UTC(y, m - 1, d));
    if (date.getUTCFullYear() !== y || date.getUTCMonth() !== m - 1 || date.getUTCDate() !== d) return null;
    return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }
  function parseCents(raw) {
    const value = String(raw ?? '').trim().replace(/^R\$\s*/i, '');
    if (!/^(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d{1,2})?$/.test(value)) return null;
    const normalized = value.replace(/\./g, '').replace(',', '.');
    const amount = Number(normalized);
    if (!Number.isFinite(amount) || amount <= 0) return null;
    const cents = Math.round(amount * 100);
    return Number.isSafeInteger(cents) && Math.abs(amount * 100 - cents) < 1e-8 ? cents : null;
  }
  function canonicalType(raw) {
    const value = String(raw ?? '').trim().toLocaleLowerCase('pt-BR').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, '_');
    return value === 'transferencia' ? 'transferencia' : value;
  }
  function canonicalStatus(raw, type) {
    const value = String(raw ?? '').trim().toLocaleLowerCase('pt-BR').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    if (value) return value === 'compromisso' ? 'compromisso' : value;
    return type === 'parcela_cartao' ? 'compromisso' : 'realizado';
  }
  function suggestion(description) {
    const s = String(description ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR');
    const rules = [
      [/mercado|hortifruti|supermercado/, 'Mercado', 'Descrição contém termo comum de compras de mercado.'],
      [/aluguel|condominio|energia|agua|internet/, 'Moradia', 'Descrição contém termo comum de moradia ou serviço doméstico.'],
      [/farmacia|clinica|consulta|dentista/, 'Saúde', 'Descrição contém termo comum de saúde.'],
      [/onibus|metro|combustivel|estacionamento|uber/, 'Transporte', 'Descrição contém termo comum de transporte.'],
      [/cinema|teatro|livraria|streaming/, 'Lazer', 'Descrição contém termo comum de lazer.']
    ];
    const match = rules.find(([pattern]) => pattern.test(s));
    return match ? { category: match[1], reason: match[2], confidence: 'Baixa' } : { category: 'Outros', reason: 'Nenhuma regra local simples correspondeu à descrição.', confidence: 'Baixa' };
  }
  function cellText(value, key) {
    if (value == null) return '';
    if (value instanceof Date) return Number.isNaN(value.getTime()) ? '' : value.toISOString().slice(0, 10);
    if (typeof value === 'number' && ['valor', 'valor_compra', 'total_arquivo'].includes(key)) return Number.isFinite(value) ? value.toFixed(2).replace('.', ',') : '';
    if (typeof value === 'object') {
      if (Array.isArray(value.richText)) return value.richText.map(part => part.text || '').join('');
      if (typeof value.text === 'string' && value.hyperlink) return value.text;
      if (value.formula || value.sharedFormula) fail('XLSX_FORMULA', 'Células com fórmula não são aceitas; use valores calculados fixos.');
      return '';
    }
    return String(value).trim();
  }
  function mapRow(cells, fields, line) {
    const get = key => fields[key] === undefined ? '' : cellText(cells[fields[key]], key).trim();
    const issues = [], date = parseDate(get('data')), cents = parseCents(get('valor'));
    const type = canonicalType(get('tipo'));
    if (!date) issues.push('Data inválida ou formato não suportado.');
    if (!cents) issues.push('Valor inválido; informe valor positivo em BRL com até duas casas.');
    if (!TYPES.has(type)) issues.push('Tipo inválido; use receita, despesa, compra_cartao, parcela_cartao, transferencia ou pagamento_fatura.');
    const description = get('descricao');
    if (!description) issues.push('Descrição vazia.');
    let status = canonicalStatus(get('situacao'), type);
    if (!STATUS.has(status)) { issues.push('Situação inválida; use realizado, compromisso ou estimativa.'); status = 'realizado'; }
    const installmentRaw = get('parcela');
    let installment = null;
    if (installmentRaw) {
      const m = installmentRaw.match(/^(\d+)\s*\/\s*(\d+)$/);
      if (!m || Number(m[1]) < 1 || Number(m[2]) < Number(m[1]) || Number(m[2]) > 36) issues.push('Parcela inválida; use número/total entre 1 e 36.');
      else installment = { index: Number(m[1]), count: Number(m[2]) };
    }
    if (type === 'parcela_cartao' && (!installment || !get('id_compra'))) issues.push('Parcela de cartão exige parcela e id_compra.');
    if (installment && type !== 'parcela_cartao') issues.push('Campo parcela só é aceito em parcela_cartao.');
    const declaredPurchaseCents = get('valor_compra') ? parseCents(get('valor_compra')) : null;
    if (get('valor_compra') && !declaredPurchaseCents) issues.push('Total da compra inválido.');
    const documentPeriod = get('periodo_documento');
    if (documentPeriod && !/^\d{4}-(0[1-9]|1[0-2])$/.test(documentPeriod)) issues.push('Período do documento deve usar AAAA-MM.');
    const cat = get('categoria') ? { category: get('categoria'), reason: 'Categoria fornecida no CSV; revisar antes de usar.', confidence: 'Informada' } : suggestion(description);
    return { line, date, description, cents, type, status, category: cat.category, categoryReason: cat.reason, confidence: cat.confidence,
      reference: get('reference') || null,
      purchaseId: get('id_compra') || null, installment, declaredPurchaseCents, documentPeriod: documentPeriod || null, issues, possibleDuplicate: false, review: 'pendente' };
  }
  function key(row) { return [row.date, row.description.trim().toLocaleLowerCase('pt-BR'), row.cents, row.type].join('|'); }
  function reviewRows(rows) {
    const seen = new Map();
    for (const row of rows) { const k = key(row); if (seen.has(k)) { row.possibleDuplicate = true; row.duplicateReviewed = false; seen.get(k).possibleDuplicate = true; seen.get(k).duplicateReviewed = false; } else seen.set(k, row); }
  }
  function validateInstallmentGroups(rows) {
    // IDs are interpreted only within this source. They do not identify an
    // account/card across documents and never allocate a card payment.
    const groups = new Map();
    for (const row of rows) if (row.purchaseId && ['compra_cartao', 'parcela_cartao'].includes(row.type)) {
      const list = groups.get(row.purchaseId) || []; list.push(row); groups.set(row.purchaseId, list);
    }
    for (const group of groups.values()) {
      const bases = group.filter(row => row.type === 'compra_cartao');
      const parts = group.filter(row => row.type === 'parcela_cartao' && row.installment);
      const flag = message => group.forEach(row => { if (!row.issues.includes(message)) row.issues.push(message); });
      // A malformed member can have no parsed installment index, but its
      // purchase ID still links it to the group. Keep every source row and
      // make the whole group ineligible for projections until corrected.
      if (group.some(row => row.issues.length)) flag('Grupo bloqueado: há pelo menos uma linha inválida neste id_compra; revise o grupo completo.');
      if (bases.length > 1) flag('Mais de uma compra-base com o mesmo id_compra; corrija o vínculo na fonte sintética e recarregue.');
      const totals = new Set(group.map(row => row.declaredPurchaseCents).filter(Boolean));
      if (bases.length === 1 && bases[0].cents) totals.add(bases[0].cents);
      if (totals.size > 1) flag('Total declarado da compra diverge entre compra-base e parcelas; corrija a fonte sintética e recarregue.');
      if (!parts.length) continue;
      const expected = parts[0].installment.count;
      const indexes = parts.map(row => row.installment.index);
      const consistentCount = parts.every(row => row.installment.count === expected);
      const uniqueIndexes = new Set(indexes);
      if (!consistentCount) flag('Contagem declarada inconsistente; corrija o grupo na fonte sintética e recarregue.');
      if (uniqueIndexes.size !== indexes.length) flag('Parcela repetida para o mesmo id_compra e número; confirmar duplicata genérica não resolve este vínculo. Corrija a fonte sintética e recarregue.');
      const complete = consistentCount && uniqueIndexes.size === expected && Array.from({ length: expected }, (_, i) => i + 1).every(n => uniqueIndexes.has(n));
      if (!complete) parts.forEach(row => { row.groupReview = 'Grupo parcial; revise as obrigações identificadas. Nenhum total ausente foi estimado.'; });
      const sum = parts.reduce((total, row) => total + (row.cents || 0), 0);
      if (!Number.isSafeInteger(sum)) flag('Soma das parcelas excede o intervalo seguro de centavos inteiros.');
      // Only compare against a total explicitly supplied by the source. Missing
      // installments and missing base purchases are never reconstructed.
      if (totals.size === 1 && uniqueIndexes.size === indexes.length) {
        const total = [...totals][0];
        if (complete && sum !== total) flag('Soma das parcelas diverge do total declarado da compra.');
        else if (!complete && sum > total) flag('Parcelas identificadas excedem o total declarado da compra.');
      }
    }
  }
  function parseTable(headersRaw, sourceRows) {
    if (!headersRaw.length || !sourceRows.length) fail('CSV_EMPTY', 'Arquivo precisa de cabeçalho e pelo menos uma linha.');
    if (sourceRows.length > MAX_ROWS) fail('CSV_ROWS', 'Limite local de linhas excedido.');
    const headers = headersRaw.map(normalizeHeader);
    if (new Set(headers).size !== headers.length) fail('CSV_HEADER_DUPLICATE', 'Cabeçalho contém coluna repetida.');
    const fields = {};
    for (const [canonical, names] of Object.entries(ALIASES)) {
      const index = headers.findIndex(h => names.includes(h));
      if (index >= 0) fields[canonical] = index;
    }
    const missing = REQUIRED.filter(k => fields[k] === undefined);
    if (missing.length) fail('CSV_HEADER_REQUIRED', 'Cabeçalho sem colunas mínimas: data, descricao, valor e tipo.');
    const rows = sourceRows.map(({ cells, line }) => {
      if (cells.every(v => !cellText(v, '').trim())) return null;
      if (cells.length !== headers.length) return { line, issues: ['Linha com número de colunas diferente do cabeçalho.'], date: null, cents: null, type: '', description: '', category: 'Outros', categoryReason: 'Dados incompletos.', confidence: 'Baixa', status: 'realizado', possibleDuplicate: false, review: 'pendente' };
      return mapRow(cells, fields, line);
    }).filter(Boolean);
    reviewRows(rows); validateInstallmentGroups(rows);
    const totals = new Set(sourceRows.map(({ cells }) => fields.total_arquivo === undefined ? '' : cellText(cells[fields.total_arquivo], 'total_arquivo').trim()).filter(Boolean));
    let declaredTotalCents = null, totalIssue = null;
    const rawSum = rows.reduce((s, r) => s + (r.cents || 0), 0);
    if (!Number.isSafeInteger(rawSum)) totalIssue = 'Soma bruta excede o intervalo seguro de centavos inteiros.';
    if (totals.size > 1) totalIssue = 'Valores de total_arquivo divergentes.';
    else if (totals.size === 1) {
      declaredTotalCents = parseCents([...totals][0]);
      if (!declaredTotalCents || rawSum !== declaredTotalCents) totalIssue = 'Total declarado não confere com a soma bruta das linhas.';
    }
    return { rows, declaredTotalCents, totalIssue };
  }
  function parseCSV(text) {
    if (typeof text !== 'string') fail('CSV_TEXT', 'Arquivo CSV inválido.');
    if (text.length > MAX_BYTES || new TextEncoder().encode(text).byteLength > MAX_BYTES) fail('FILE_SIZE', 'Arquivo acima do limite local de 5 MiB.');
    const grid = parseGrid(text);
    return { ...parseTable(grid.headers, grid.rows), delimiter: grid.delimiter };
  }
  function validateXLSXEnvelope(buffer) {
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const min = Math.max(0, bytes.length - 65557);
    let eocd = -1;
    for (let i = bytes.length - 22; i >= min; i--) if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    if (eocd < 0) fail('XLSX_ZIP', 'Pacote XLSX inválido ou ZIP64 não suportado.');
    const disk = view.getUint16(eocd + 4, true), directoryDisk = view.getUint16(eocd + 6, true);
    const diskEntries = view.getUint16(eocd + 8, true), entries = view.getUint16(eocd + 10, true);
    const directorySize = view.getUint32(eocd + 12, true), directoryOffset = view.getUint32(eocd + 16, true);
    const commentLength = view.getUint16(eocd + 20, true);
    if (eocd + 22 + commentLength !== bytes.length || disk !== 0 || directoryDisk !== 0 || diskEntries !== entries || !entries || entries > 256 || directorySize === 0xffffffff || directoryOffset === 0xffffffff || directoryOffset + directorySize !== eocd) fail('XLSX_ZIP', 'Estrutura XLSX fora dos limites locais.');
    let offset = directoryOffset, totalExpanded = 0;
    const localRanges = [];
    const entriesInfo = [];
    const names = new Set();
    for (let i = 0; i < entries; i++) {
      if (offset + 46 > bytes.length || view.getUint32(offset, true) !== 0x02014b50) fail('XLSX_ZIP', 'Diretório XLSX inválido.');
      const flags = view.getUint16(offset + 8, true), method = view.getUint16(offset + 10, true);
      const crc = view.getUint32(offset + 16, true), compressed = view.getUint32(offset + 20, true), expanded = view.getUint32(offset + 24, true);
      const nameLength = view.getUint16(offset + 28, true), extraLength = view.getUint16(offset + 30, true), commentLength = view.getUint16(offset + 32, true);
      const localOffset = view.getUint32(offset + 42, true);
      const end = offset + 46 + nameLength + extraLength + commentLength;
      if (end > bytes.length || flags & (1 | 8) || compressed === 0xffffffff || expanded === 0xffffffff || localOffset === 0xffffffff || method !== 0 && method !== 8) fail('XLSX_ZIP', 'Entrada criptografada, com descritor ou ZIP64 não suportada.');
      totalExpanded += expanded;
      if (expanded > 10 * 1024 * 1024 || totalExpanded > 25 * 1024 * 1024) fail('XLSX_EXPANDED_SIZE', 'Conteúdo descompactado excede o limite local de 25 MiB.');
      const centralName = bytes.subarray(offset + 46, offset + 46 + nameLength);
      const name = new TextDecoder().decode(centralName);
      if (!name || names.has(name)) fail('XLSX_ZIP', 'Nome de entrada XLSX vazio ou duplicado.');
      names.add(name);
      if (localOffset + 30 > directoryOffset || view.getUint32(localOffset, true) !== 0x04034b50) fail('XLSX_ZIP', 'Cabeçalho local XLSX inválido.');
      const localFlags = view.getUint16(localOffset + 6, true), localMethod = view.getUint16(localOffset + 8, true);
      const localCrc = view.getUint32(localOffset + 14, true), localCompressed = view.getUint32(localOffset + 18, true), localExpanded = view.getUint32(localOffset + 22, true);
      const localNameLength = view.getUint16(localOffset + 26, true), localExtraLength = view.getUint16(localOffset + 28, true);
      const dataStart = localOffset + 30 + localNameLength + localExtraLength, dataEnd = dataStart + compressed;
      const localName = bytes.subarray(localOffset + 30, localOffset + 30 + localNameLength);
      if (localFlags !== flags || localMethod !== method || localNameLength !== nameLength || localName.some((byte, index) => byte !== centralName[index]) || localCrc !== crc || localCompressed !== compressed || localExpanded !== expanded || (method === 0 && compressed !== expanded) || dataStart > directoryOffset || dataEnd > directoryOffset) fail('XLSX_ZIP', 'Cabeçalho local e diretório XLSX divergentes ou truncados.');
      localRanges.push([localOffset, dataEnd]);
      entriesInfo.push({ name, expanded, crc });
      if (/^xl\/vbaProject\.bin$/i.test(name)) fail('XLSX_MACRO', 'Planilhas com macro não são aceitas.');
      offset = end;
    }
    if (offset !== directoryOffset + directorySize) fail('XLSX_ZIP', 'Diretório XLSX inconsistente.');
    localRanges.sort((a, b) => a[0] - b[0]);
    if (localRanges[0][0] !== 0) fail('XLSX_ZIP', 'Prefixo ZIP não suportado no pacote XLSX.');
    for (let i = 1; i < localRanges.length; i++) if (localRanges[i][0] !== localRanges[i - 1][1]) fail('XLSX_ZIP', 'Entradas locais XLSX sobrepostas ou com lacunas.');
    if (localRanges.at(-1)[1] !== directoryOffset) fail('XLSX_ZIP', 'Dados XLSX truncados ou fora da posição declarada.');
    return entriesInfo;
  }
  async function parseXLSX(buffer, { readSheet, unzipSync, strFromU8, Unzip, UnzipInflate, UnzipPassThrough } = {}) {
    validateFileMeta({ name: 'synthetic.xlsx', size: buffer?.byteLength });
    if (typeof readSheet !== 'function' || typeof unzipSync !== 'function' || typeof strFromU8 !== 'function' || typeof Unzip !== 'function' || typeof UnzipInflate !== 'function' || typeof UnzipPassThrough !== 'function') fail('XLSX_LIBRARY', 'Parser XLSX local indisponível.');
    const zipEntries = validateXLSXEnvelope(buffer);
    validateXLSXInflate(buffer, zipEntries, { Unzip, UnzipInflate, UnzipPassThrough });
    let zip;
    try { zip = unzipSync(new Uint8Array(buffer)); }
    catch { fail('XLSX_INVALID', 'Planilha XLSX inválida ou não suportada.'); }
    for (const entry of zipEntries) {
      const content = zip[entry.name];
      if (!content || content.byteLength !== entry.expanded || crc32(content) !== entry.crc) fail('XLSX_INVALID', 'Tamanho ou checksum de entrada XLSX divergente.');
    }
    for (const [name, content] of Object.entries(zip)) if (/^xl\/worksheets\/sheet\d+\.xml$/i.test(name) && /<f(?:\s|>)/i.test(strFromU8(content))) fail('XLSX_FORMULA', 'Células com fórmula não são aceitas; use valores calculados fixos.');
    let matrix;
    try { matrix = await readSheet(buffer); }
    catch { fail('XLSX_INVALID', 'Planilha XLSX inválida ou não suportada.'); }
    if (!Array.isArray(matrix) || matrix.length < 2 || !Array.isArray(matrix[0])) fail('XLSX_EMPTY', 'Planilha precisa de cabeçalho e pelo menos uma linha.');
    if (matrix.length - 1 > MAX_ROWS) fail('CSV_ROWS', 'Limite local de linhas excedido.');
    const width = matrix[0].length;
    const rows = matrix.slice(1).map((cells, index) => ({ line: index + 2, cells: Array.from({ length: width }, (_, i) => cells?.[i]) }));
    return { ...parseTable(matrix[0], rows), delimiter: null };
  }
  async function parsePDF(buffer, pdfjs, pdfOptions = {}) {
    validateFileMeta({ name: 'synthetic.pdf', size: buffer?.byteLength });
    if (!pdfjs?.getDocument) fail('PDF_LIBRARY', 'Parser PDF local indisponível.');
    let doc, loadingTask;
    try { loadingTask = pdfjs.getDocument({ ...pdfOptions, data: new Uint8Array(buffer), disableAutoFetch: true, disableStream: true, isEvalSupported: false, enableXfa: false }); doc = await loadingTask.promise; }
    catch { fail('PDF_INVALID', 'PDF inválido ou não suportado pelo parser local.'); }
    if (doc.numPages > 100) { await loadingTask.destroy(); fail('PDF_PAGES', 'PDF acima do limite local de 100 páginas.'); }
    const lines = [];
    try {
      for (let pageNo = 1; pageNo <= doc.numPages; pageNo++) {
        const page = await doc.getPage(pageNo);
        const content = await page.getTextContent({ includeMarkedContent: false });
        const groups = [];
        for (const item of content.items) {
          if (!item.str?.trim()) continue;
          const y = Math.round(item.transform?.[5] || 0);
          let group = groups.find(entry => Math.abs(entry.y - y) <= 2);
          if (!group) { group = { y, items: [] }; groups.push(group); }
          group.items.push({ x: item.transform?.[4] || 0, text: item.str });
        }
        groups.sort((a, b) => b.y - a.y);
        for (const group of groups) lines.push(group.items.sort((a, b) => a.x - b.x).map(item => item.text).join(';'));
        page.cleanup();
      }
    } finally { await loadingTask.destroy(); }
    const text = lines.join('\n');
    if (!text.trim()) fail('PDF_NO_TEXT', 'PDF sem camada de texto; OCR local ainda não está disponível.');
    const parsed = parseCSV(text);
    return { ...parsed, delimiter: 'pdf-text', sourceFormat: 'pdf-text-table' };
  }
  function analyze(rows) {
    const byMonthCategory = new Map(), byStatus = { realizado: 0, compromisso: 0, estimativa: 0 };
    for (const row of rows) {
      if (row.issues.length) continue;
      const expense = row.type === 'despesa' || row.type === 'compra_cartao';
      if (!expense) continue; // Transfers and card payments are cash movements, not expenses.
      const month = row.date && row.date.slice(0, 7);
      if (row.status === 'realizado') {
        const key = `${month}|${row.category}`;
        byMonthCategory.set(key, (byMonthCategory.get(key) || 0) + row.cents);
      }
      byStatus[row.status] += row.cents;
    }
    return { byMonthCategory: [...byMonthCategory].map(([key, cents]) => { const [month, category] = key.split('|'); return { month, category, cents }; }), byStatus };
  }
  function validMonth(value) { return typeof value === 'string' && /^\d{4}-(0[1-9]|1[0-2])$/.test(value); }
  function monthsBetween(startMonth, endMonth) {
    if (!validMonth(startMonth) || !validMonth(endMonth) || startMonth > endMonth) return [];
    const result = [];
    let [year, month] = startMonth.split('-').map(Number);
    while (`${year}-${String(month).padStart(2, '0')}` <= endMonth && result.length < 120) {
      result.push(`${year}-${String(month).padStart(2, '0')}`);
      month++;
      if (month > 12) { month = 1; year++; }
    }
    return result;
  }
  function assessBudgetCoverage(coverage, planningMonth) {
    if (!validMonth(planningMonth)) return { blocked: 'Escolha explicitamente o mês de planejamento.', eligibleMonths: [], excludedMonths: [] };
    if (!coverage?.inventoryConfirmed) return { blocked: 'Declare e confirme o inventário esperado de contas/cartões e períodos.', eligibleMonths: [], excludedMonths: [] };
    const sources = Array.isArray(coverage.sources) ? coverage.sources : [];
    if (!sources.length) return { blocked: 'Declare pelo menos uma conta ou cartão esperado para avaliar cobertura.', eligibleMonths: [], excludedMonths: [] };
    if (sources.some(source => !['conta', 'cartao'].includes(source.kind) || !String(source.label || '').trim() || source.expected === false && !String(source.notExpectedReason || '').trim())) {
      return { blocked: 'Complete a identificação das fontes e justifique toda fonte declarada como não esperada.', eligibleMonths: [], excludedMonths: [] };
    }
    const expectedSources = sources.filter(source => source.expected !== false);
    if (!expectedSources.length) return { blocked: 'O inventário não contém conta/cartão esperado; revise a declaração antes do orçamento.', eligibleMonths: [], excludedMonths: [] };
    const months = [...new Set((coverage.expectedMonths || []).filter(validMonth))].sort();
    if (!months.length) return { blocked: 'Declare os períodos esperados no inventário.', eligibleMonths: [], excludedMonths: [] };
    const eligibleMonths = [], excludedMonths = [];
    for (const month of months) {
      const statuses = expectedSources.map(source => source.coverage?.[month] || { status: 'ausente' });
      const complete = statuses.every(item => item.status === 'completo' && item.confirmed === true && !item.knownGaps && !String(item.reason || '').trim());
      const reasons = statuses.map((item, index) => {
        if (item.status === 'parcial') return `${expectedSources[index].label}: parcial${item.reason ? ` (${item.reason})` : ''}`;
        if (item.status === 'completo' && item.confirmed !== true) return `${expectedSources[index].label}: completo aguardando confirmação manual`;
        if (item.status === 'completo' && (item.knownGaps || String(item.reason || '').trim())) return `${expectedSources[index].label}: lacunas conhecidas`;
        return `${expectedSources[index].label}: ausente`;
      });
      if (month >= planningMonth) excludedMonths.push({ month, status: 'futuro', reasons: ['Mês igual ou posterior ao planejamento.'] });
      else if (complete) eligibleMonths.push(month);
      else excludedMonths.push({ month, status: statuses.some(item => item.status === 'parcial') ? 'parcial' : 'ausente', reasons });
    }
    return { blocked: null, eligibleMonths, excludedMonths, expectedMonths: months, expectedSources: expectedSources.map(source => source.id) };
  }
  function projectOpenInstallments(rows, { planningMonth, today }) {
    if (!validMonth(planningMonth)) return { blocked: 'Escolha explicitamente o mês de planejamento.', planningMonth: null, rows: [], reviewRows: [], totalCents: 0 };
    const blockedPurchaseIds = new Set(rows.filter(row => row.purchaseId && ['compra_cartao', 'parcela_cartao'].includes(row.type) && row.issues.length).map(row => row.purchaseId));
    const selected = rows.filter(row => row.type === 'parcela_cartao' && row.status === 'compromisso' && row.purchaseId && row.date &&
      validMonth(row.date.slice(0, 7)) && row.date.slice(0, 7) === planningMonth && row.date >= today);
    const eligible = [], reviewRows = [], blockedGroups = new Set();
    for (const row of selected) {
      const unresolvedDuplicate = row.possibleDuplicate && !row.duplicateReviewed;
      if (blockedPurchaseIds.has(row.purchaseId)) {
        blockedGroups.add(row.purchaseId);
        reviewRows.push({ ...row, reviewReason: `Grupo ${row.purchaseId} bloqueado por erro em uma ou mais linhas; revise todos os integrantes.` });
      }
      else if (row.issues.length || !row.installment || row.review !== 'revisado' || unresolvedDuplicate || row.groupReview && row.review !== 'revisado') reviewRows.push({ ...row, reviewReason: row.issues.join(' ') || (unresolvedDuplicate ? 'Possível duplicata sem decisão.' : row.groupReview || 'Obrigação ainda não revisada.') });
      else eligible.push(row);
    }
    return { blocked: null, planningMonth, rows: eligible, reviewRows, blockedGroups: [...blockedGroups], totalCents: eligible.reduce((sum, row) => sum + row.cents, 0) };
  }
  function proposeBudgets(rows, { planningMonth, coverage } = {}) {
    if (rows.some(r => r.issues.length || r.review !== 'revisado' || r.possibleDuplicate && !r.duplicateReviewed)) return { blocked: 'Revise todas as linhas, corrija validações e decida cada possível duplicata antes de propor valores.' };
    if (!validMonth(planningMonth)) return { blocked: 'Escolha explicitamente o mês de planejamento.' };
    const coverageAssessment = assessBudgetCoverage(coverage, planningMonth);
    if (coverageAssessment.blocked) return { ...coverageAssessment, blocked: coverageAssessment.blocked };
    const observedMonths = coverageAssessment.eligibleMonths;
    const excludedMonths = coverageAssessment.excludedMonths;
    if (!observedMonths.length) return { ...coverageAssessment, blocked: 'Nenhum mês anterior ao planejamento tem cobertura completa confirmada em todo o inventário esperado.' };
    const history = new Map(), categories = new Set();
    for (const row of rows) {
      if ((row.type === 'despesa' || row.type === 'compra_cartao') && row.status === 'realizado') {
        categories.add(row.category);
        const month = row.date.slice(0, 7);
        if (!observedMonths.includes(month)) continue;
        const key = `${month}|${row.category}`;
        history.set(key, (history.get(key) || 0) + row.cents);
      }
    }
    const sourceMonths = [...new Set(rows.filter(r => (r.type === 'despesa' || r.type === 'compra_cartao') && r.status === 'realizado' && r.date && !r.issues.length).map(r => r.date.slice(0, 7)))].sort();
    return { ...coverageAssessment, blocked: null, planningMonth, observedMonths, excludedMonths, uncoveredMonths: sourceMonths.filter(month => !observedMonths.includes(month)), rows: [...categories].sort().map(category => {
      const observedTotal = observedMonths.reduce((sum, month) => sum + (history.get(`${month}|${category}`) || 0), 0);
      const monthlyAverageCents = Math.round(observedTotal / observedMonths.length);
      return { category, monthlyAverageCents };
    }) };
  }
  function stableJson(value) {
    if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`;
    if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableJson(value[key])}`).join(',')}}`;
    return JSON.stringify(value);
  }
  function reconciliationSignature(left, right, leftRow, rightRow) {
    return stableJson({ left: { id: left.id, identity: left.identity }, right: { id: right.id, identity: right.identity }, leftRow, rightRow });
  }
  function reconcileDocuments(left, right, confirmedLinks = []) {
    const groupByReference = document => {
      const map = new Map();
      for (const row of document.rows || []) {
        const ref = String(row.reference || '').trim();
        if (!ref) continue;
        const values = map.get(ref) || []; values.push(row); map.set(ref, values);
      }
      return map;
    };
    const leftRefs = groupByReference(left), rightRefs = groupByReference(right);
    const links = [], conflicts = [], shared = new Set([...leftRefs.keys()].filter(ref => rightRefs.has(ref)));
    for (const reference of [...shared].sort()) {
      const aRows = leftRefs.get(reference), bRows = rightRefs.get(reference);
      if (aRows.length !== 1 || bRows.length !== 1) {
        conflicts.push({ reference, status: 'conflict', reason: 'Referência repetida em um documento; escolha o vínculo manualmente.', leftRows: aRows, rightRows: bRows });
        continue;
      }
      const a = aRows[0], b = bRows[0], differences = [];
      const identityReady = [left.identity, right.identity].every(identity => identity?.confirmed === true && ['sourceId', 'accountId', 'cardId'].every(key => String(identity[key] || '').trim()));
      if (!identityReady) {
        conflicts.push({ reference, status: 'identity-pending', reason: 'Confirme origem, conta e cartão dos dois documentos antes de gerar candidato.', leftRow: a, rightRow: b });
        continue;
      }
      if (a.issues?.length || b.issues?.length) {
        conflicts.push({ reference, status: 'conflict', reason: 'Conflito para revisão: uma ou mais linhas têm erros de validação.', differences: ['validação'], leftRow: a, rightRow: b });
        continue;
      }
      for (const key of ['sourceId', 'accountId', 'cardId']) if (String(left.identity[key]).trim() !== String(right.identity[key]).trim()) differences.push(`identidade ${key} divergente`);
      if (a.type !== b.type) differences.push('tipo divergente');
      if (a.cents !== b.cents) differences.push('valor divergente');
      if (a.date !== b.date) differences.push('data divergente');
      if (differences.length) {
        conflicts.push({ reference, status: 'conflict', reason: `Conflito para revisão: ${differences.join(', ')}.`, differences, leftRow: a, rightRow: b });
        continue;
      }
      const signature = reconciliationSignature(left, right, a, b);
      const confirmed = confirmedLinks.some(link => link.reference === reference && link.signature === signature && link.confirmed === true);
      links.push({ id: `${left.id}:${a.id}|${right.id}:${b.id}`, reference, status: confirmed ? 'confirmed' : 'candidate', leftRow: a, rightRow: b, signature });
    }
    const unmatched = document => (document.rows || []).filter(row => !row.reference || !shared.has(String(row.reference).trim()));
    return { links, conflicts, unmatchedLeft: unmatched(left), unmatchedRight: unmatched(right) };
  }
  function invalidateReconciliationLinks(links, { documentId, rowId } = {}) {
    return (links || []).filter(link => {
      if (documentId && (link.leftDocumentId === documentId || link.rightDocumentId === documentId)) return false;
      if (rowId && (link.leftRowId === rowId || link.rightRowId === rowId)) return false;
      return true;
    });
  }
  function confirmReconciliationLink(comparison, candidateId, left, right, confirmedLinks = []) {
    const candidate = comparison.links.find(link => link.id === candidateId && link.status === 'candidate');
    if (!candidate) fail('RECONCILIATION_CANDIDATE', 'Só é possível confirmar manualmente um candidato atual sem conflitos.');
    const link = { id: candidate.id, reference: candidate.reference, signature: reconciliationSignature(left, right, candidate.leftRow, candidate.rightRow),
      leftDocumentId: left.id, leftRowId: candidate.leftRow.id, rightDocumentId: right.id, rightRowId: candidate.rightRow.id, confirmed: true };
    return [...confirmedLinks.filter(old => old.id !== link.id), link];
  }
  function buildReconciledHistory(left, right, comparison, decisions = {}) {
    const items = [];
    for (const link of comparison.links || []) {
      items.push({ id: `link:${link.id}`, kind: link.status === 'confirmed' ? 'confirmed-link' : 'candidate', status: link.status,
        reference: link.reference, rows: [{ side: 'left', document: left, row: link.leftRow }, { side: 'right', document: right, row: link.rightRow }],
        choices: link.status === 'confirmed' ? [link.leftRow, link.rightRow].filter(row => !row.issues?.length).map(row => row.id).concat('exclude') : [] });
    }
    for (const conflict of comparison.conflicts || []) {
      const conflictRows = [
        ...(conflict.leftRows || (conflict.leftRow ? [conflict.leftRow] : [])).map(row => ({ side: 'left', document: left, row })),
        ...(conflict.rightRows || (conflict.rightRow ? [conflict.rightRow] : [])).map(row => ({ side: 'right', document: right, row }))
      ];
      const id = `conflict:${left.id}:${right.id}:${conflict.reference}`;
      items.push({ id, kind: 'conflict', status: conflict.status, reference: conflict.reference, reason: conflict.reason, rows: conflictRows,
        choices: conflict.status === 'conflict' ? conflictRows.filter(item => !item.row.issues?.length).map(item => item.row.id).concat('exclude') : [] });
    }
    for (const [document, side] of [[left, 'left'], [right, 'right']]) for (const row of comparison[side === 'left' ? 'unmatchedLeft' : 'unmatchedRight'] || []) {
      // Without a shared stable reference, never treat an unmatched source row as reconciled history.
      items.push({ id: `unmatched:${document.id}:${row.id}`, kind: 'unmatched', status: 'unmatched', rows: [{ side, document, row }], choices: ['exclude'] });
    }
    const selectedRows = [], pendingItems = [], excludedItems = [];
    for (const item of items) {
      const choice = decisions[item.id];
      if (!choice || !item.choices.includes(choice)) { pendingItems.push(item); continue; }
      if (choice === 'exclude') { excludedItems.push(item); continue; }
      const chosen = item.rows.find(entry => entry.row.id === choice);
      if (!chosen || chosen.row.issues?.length) { pendingItems.push(item); continue; }
      selectedRows.push({ ...chosen.row, reconciliationDocumentId: chosen.document.id, reconciliationDocumentLabel: chosen.document.label, reconciliationSide: chosen.side });
    }
    const historicalRows = selectedRows.filter(row => row.status === 'realizado' && ['despesa', 'compra_cartao'].includes(row.type));
    const obligationRows = selectedRows.filter(row => row.status === 'compromisso' || row.type === 'parcela_cartao');
    const otherRows = selectedRows.filter(row => !historicalRows.includes(row) && !obligationRows.includes(row));
    const history = analyze(historicalRows);
    return { items, selectedRows, historicalRows, obligationRows, otherRows, pendingItems, excludedItems,
      byMonthCategory: history.byMonthCategory, totalHistoricalCents: historicalRows.reduce((sum, row) => sum + row.cents, 0),
      obligationTotalCents: obligationRows.reduce((sum, row) => sum + row.cents, 0) };
  }
  function paymentAllocationSummary(payment, obligations, allocations = []) {
    if (!payment || !Number.isSafeInteger(payment.cents) || payment.cents <= 0) fail('ALLOCATION_PAYMENT', 'Pagamento sintético inválido.');
    const confirmed = allocations.filter(item => item.confirmed === true);
    for (const item of confirmed) {
      if (!Number.isSafeInteger(item.cents) || item.cents <= 0) fail('ALLOCATION_AMOUNT', 'Alocação confirmada inválida.');
      const target = (obligations || []).find(obligation => obligation.id === item.obligationId);
      if (!target || (item.paymentId === payment.id && payment.cardId !== target.cardId)) fail('ALLOCATION_IDENTITY', 'Alocação sem obrigação/cartão correspondente.');
    }
    const paymentAllocated = confirmed.filter(item => item.paymentId === payment.id).reduce((sum, item) => sum + item.cents, 0);
    if (!Number.isSafeInteger(paymentAllocated) || paymentAllocated > payment.cents) fail('ALLOCATION_PAYMENT_CAP', 'Alocações confirmadas excedem o pagamento.');
    const obligationBalances = (obligations || []).map(obligation => {
      if (!Number.isSafeInteger(obligation.cents) || obligation.cents <= 0) fail('ALLOCATION_OBLIGATION', 'Obrigação sintética inválida.');
      const allocated = confirmed.filter(item => item.obligationId === obligation.id).reduce((sum, item) => sum + item.cents, 0);
      if (!Number.isSafeInteger(allocated) || allocated > obligation.cents) fail('ALLOCATION_OBLIGATION_CAP', 'Alocações confirmadas excedem o saldo da obrigação.');
      return { obligationId: obligation.id, openCents: obligation.cents - allocated };
    });
    return { paymentRemainingCents: payment.cents - paymentAllocated, obligations: obligationBalances };
  }
  function addPaymentAllocation(payment, obligations, allocations = [], allocation) {
    if (!allocation || allocation.confirmed !== true) fail('ALLOCATION_CONFIRMATION', 'Cada alocação exige confirmação explícita.');
    if (!Number.isSafeInteger(allocation.cents) || allocation.cents <= 0) fail('ALLOCATION_AMOUNT', 'Informe um valor positivo em centavos inteiros.');
    const obligation = (obligations || []).find(item => item.id === allocation.obligationId);
    if (!obligation || allocation.paymentId !== payment?.id) fail('ALLOCATION_TARGET', 'Pagamento ou obrigação indisponível.');
    if (obligation.status !== 'open') fail('ALLOCATION_OBLIGATION_STATUS', 'Só é possível alocar pagamento a uma obrigação aberta.');
    if (payment.cardId !== obligation.cardId) fail('ALLOCATION_IDENTITY', 'Pagamento e obrigação precisam pertencer ao mesmo cartão confirmado.');
    const before = paymentAllocationSummary(payment, obligations, allocations);
    const open = before.obligations.find(item => item.obligationId === obligation.id)?.openCents;
    if (allocation.cents > before.paymentRemainingCents) fail('ALLOCATION_PAYMENT_CAP', 'A alocação excede o saldo restante do pagamento.');
    if (allocation.cents > open) fail('ALLOCATION_OBLIGATION_CAP', 'A alocação excede o saldo aberto da obrigação.');
    const next = [...allocations, { ...allocation }];
    return { allocations: next, ...paymentAllocationSummary(payment, obligations, next) };
  }
  function validateFileMeta(file) {
    if (!file || !/\.(csv|xlsx|pdf)$/i.test(file.name || '')) fail('FILE_TYPE', 'Formato local não suportado; escolha CSV, XLSX ou PDF de texto.');
    if (!Number.isSafeInteger(file.size) || file.size < 1) fail('FILE_SIZE', 'Tamanho de arquivo local inválido.');
    if (file.size > MAX_BYTES) fail('FILE_SIZE', 'Arquivo acima do limite local de 5 MiB.');
    return true;
  }
  return { MAX_BYTES, MAX_ROWS, validateFileMeta, parseCSV, parseXLSX, parsePDF, parseDate, parseCents, analyze, projectOpenInstallments, assessBudgetCoverage, monthsBetween, proposeBudgets,
    reconcileDocuments, confirmReconciliationLink, invalidateReconciliationLinks, buildReconciledHistory, paymentAllocationSummary, addPaymentAllocation };
});
