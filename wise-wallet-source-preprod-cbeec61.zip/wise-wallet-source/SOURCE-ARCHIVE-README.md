# Wise Wallet — source offer (preproduction candidate)

This archive is a source snapshot derived from commit cbeec61b5d943eacf786bf36003d4dc7d3f241a3 on 2026-11-09. It is intended for code inspection and modification; it is not a data backup and contains no Firestore export, financial records, credentials, or deployment secrets.

Owner-specific display names and email allowlist entries have been replaced with placeholders. The Firebase hosting target is generic. Emulator seed credentials, test suites, internal release evidence, deployment project references, and local output folders are excluded. Configure your own Firebase project and family access values before building or running it.

The Maybe-derived UI source identifies commit 77b5469832758d1cbee1a940f3012a1ae1c74cd3. Its AGPL-3.0 license is included at public/licenses/maybe-AGPL-3.0.txt. The third-party spreadsheet parser licenses are included with their source under public/ensaio-importacao/vendor. The project is not affiliated with Maybe Finance.
