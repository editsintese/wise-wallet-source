import type { NextConfig } from 'next';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = dirname(fileURLToPath(import.meta.url));

const nextConfig: NextConfig = {
  output: 'export',
  ...(process.env.WISE_TEST_NEXT_DIST_DIR ? { distDir: process.env.WISE_TEST_NEXT_DIST_DIR } : {}),
  images: { unoptimized: true },
  experimental: { cpus: 1 },
  // The dev badge sits on top of the mobile bottom nav; errors still reach the terminal and console.
  devIndicators: false,
  turbopack: { root: projectRoot },
  allowedDevOrigins: ['127.0.0.1', '192.168.68.58'],
};

export default nextConfig;
