'use client';
import {MaybeField as ConnectedField} from './maybe-ui/primitives';

import {ReferenceRows,BudgetGroupView} from './maybe-ui/reference-views';
import {MaybeDialog} from './maybe-ui/dialog';
import {MaybeField,MaybeButton} from './maybe-ui/primitives';
import { FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { collection, doc, onSnapshot, serverTimestamp, setDoc } from 'firebase/firestore';
import { firebaseAuth, firestore } from './lib/firebase';
import { defaultCategories, defaultResponsibles, importedCategoryReferences, normalizeReferenceName, ReferenceItem, referenceId, resolveReferences, StoredReference } from './reference-data';
import { Button } from './design-system/button';
import { TextField } from './design-system/field';
import { Chip } from './design-system/chip';
import { calculateBudgetUsage, groupBudgetCategories, CategoryGroup } from './budget-domain';
import { TemporalInput } from './design-system/temporal-input';

type Kind = 'categories' | 'responsibles';
type BudgetCategory = { id: string; name?: string; categoryName?: string; subcategoria?: string; subcategory?: string; tipo?: string; valor_previsto?: number; valorPrevisto?: number; expectedAmount?: number };
type BudgetTransaction = { amount: number; kind: 'income' | 'expense'; category?: string; subcategory?: string; rawDate?: string; transactionDate?: string; archived?: boolean; cardPayment?: boolean; isCardPayment?: boolean };
const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

function ReferenceDialog({title,onClose,children}:{title:string;onClose:()=>void;children:React.ReactNode}){return <MaybeDialog title={title} onClose={onClose}>{children}</MaybeDialog>}

function ReferenceList({ title, description, kind, items, userId, detailContent }: { detailContent?:(item:ReferenceItem)=>React.ReactNode; title: string; description: string; kind: Kind; items: ReferenceItem[]; userId: string }) {
  const [creating,setCreating]=useState(false);
  const [saving, setSaving] = useState(false); const [message, setMessage] = useState('');
  const [editing, setEditing] = useState<ReferenceItem | null>(null);
  async function saveName(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!firestore || saving) return;
    const form = event.currentTarget; const name = String(new FormData(form).get('name') || '').trim().replace(/\s+/g, ' '); const id = referenceId(name);
    if (name.length < 2 || name.length > 50 || !id) { setMessage('Use um nome entre 2 e 50 caracteres.'); return; }
    const existing = items.find((item) => normalizeReferenceName(item.name) === normalizeReferenceName(name));
    if (existing && !existing.archived) { setMessage('Esse nome já está ativo.'); return; }
    setSaving(true); try { await setDoc(doc(firestore, 'households', 'family-wallet', kind, existing?.id || id), { name, archived: false, updatedAt: serverTimestamp(), updatedBy: userId, ...(!existing ? { createdAt: serverTimestamp(), createdBy: userId } : {}) }, { merge: true }); form.reset(); setMessage(name + ' salvo.'); } catch { setMessage('Não foi possível salvar agora.'); } finally { setSaving(false); }
  }
  async function edit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const name = String(new FormData(event.currentTarget).get('name') || '').trim().replace(/\s+/g, ' ');
    if (!editing || !firestore || saving) return;
    const duplicate = items.some((item) => item.id !== editing.id && !item.archived && normalizeReferenceName(item.name) === normalizeReferenceName(name));
    if (name.length < 2 || name.length > 50 || duplicate) { setMessage(duplicate ? 'Esse nome já está ativo.' : 'Use um nome entre 2 e 50 caracteres.'); return; }
    setSaving(true); try { await setDoc(doc(firestore, 'households', 'family-wallet', kind, editing.id), { name, updatedAt: serverTimestamp(), updatedBy: userId }, { merge: true }); setMessage(name + ' atualizado.'); setEditing(null); } catch { setMessage('Não foi possível atualizar agora.'); } finally { setSaving(false); }
  }
  async function toggle(item: ReferenceItem) {
    if (!firestore || saving) return; setSaving(true);
    try { await setDoc(doc(firestore, 'households', 'family-wallet', kind, item.id), { name: item.name, archived: !item.archived, updatedAt: serverTimestamp(), updatedBy: userId }, { merge: true }); setMessage(item.archived ? item.name + ' restaurado.' : item.name + ' arquivado.'); } catch { setMessage('Não foi possível atualizar agora.'); } finally { setSaving(false); }
  }
  return <section className="mb-table-container"><header className="mb-page-heading"><h3>{title}</h3><MaybeButton variant="primary" onClick={()=>{setMessage('');setCreating(true)}}>Adicionar</MaybeButton></header><p className="form-help">{description}</p>{creating&&<ReferenceDialog title={kind==='categories'?'Nova categoria':'Novo responsável'} onClose={()=>setCreating(false)}><form onSubmit={saveName}><MaybeField label="Novo nome"><input name="name" required minLength={2} maxLength={50}/></MaybeField><MaybeButton variant="primary" type="submit" disabled={saving}>Adicionar</MaybeButton>{message&&<p role="status">{message}</p>}</form></ReferenceDialog>}{message&&<p role="status">{message}</p>}<ReferenceRows kind={kind==='categories'?'category':'owner'} items={items} detailContent={detailContent} saving={saving} onEdit={item=>{setMessage('');setEditing(item)}} onToggle={item=>void toggle(item)}/>{editing&&<ReferenceDialog title={`Editar ${kind==='categories'?'categoria':'responsável'}`} onClose={()=>setEditing(null)}><form onSubmit={edit}>{message&&<p role="status">{message}</p>}<MaybeField label="Nome"><input name="name" required minLength={2} maxLength={50} defaultValue={editing.name}/></MaybeField><MaybeButton variant="primary" type="submit" disabled={saving}>Salvar alterações</MaybeButton></form></ReferenceDialog>}</section>;
}

function BudgetGroup({ group, month, transactions, saving, onEdit, onAdd }: { group: CategoryGroup; month: string; transactions: BudgetTransaction[]; saving: boolean; onEdit: (row: BudgetCategory) => void; onAdd: (group: CategoryGroup) => void }) {
 return <BudgetGroupView group={group} month={month} transactions={transactions} saving={saving} onEdit={onEdit} onAdd={onAdd}/>;
}

export function ReferenceDataScreen({ transactions = [] }: { transactions?: BudgetTransaction[] }) {
  const [referenceTab,setReferenceTab]=useState<'categories'|'responsibles'>('categories');
  const [savedCategories, setSavedCategories] = useState<StoredReference[]>([]); const [savedResponsibles, setSavedResponsibles] = useState<StoredReference[]>([]); const [budgetCategories, setBudgetCategories] = useState<BudgetCategory[]>([]); const [month, setMonth] = useState(new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' }).slice(0, 7)); const [message, setMessage] = useState(''); const [savingSubcategory, setSavingSubcategory] = useState(false); const [budgetDialog, setBudgetDialog] = useState<{ mode: 'limit'; row: BudgetCategory } | { mode: 'subcategory'; group: CategoryGroup } | null>(null);
  const userId = firebaseAuth?.currentUser?.uid || '';
  useEffect(() => { if (!firestore || !userId) return; const root = ['households', 'family-wallet'] as const; const categories = onSnapshot(collection(firestore, ...root, 'categories'), (snapshot) => setSavedCategories(snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as StoredReference)))); const responsibles = onSnapshot(collection(firestore, ...root, 'responsibles'), (snapshot) => setSavedResponsibles(snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as StoredReference)))); const imported = onSnapshot(collection(firestore, ...root, 'budgetCategories'), (snapshot) => setBudgetCategories(snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as BudgetCategory)))); return () => { categories(); responsibles(); imported(); }; }, [userId]);
  const importedReferences = useMemo(() => importedCategoryReferences(budgetCategories), [budgetCategories]);
  const categories = useMemo(() => resolveReferences(defaultCategories, [...savedCategories, ...importedReferences]), [budgetCategories, savedCategories]);
  const responsibles = useMemo(() => resolveReferences(defaultResponsibles, savedResponsibles), [savedResponsibles]);
  const groups = useMemo(() => {
    const byName = new Map(groupBudgetCategories(budgetCategories).map((group) => [normalizeReferenceName(group.name), group]));
    categories.filter((category) => !category.archived).forEach((category) => {
      const key = normalizeReferenceName(category.name);
      if (!byName.has(key)) byName.set(key, { id: key || category.id, name: category.name, rows: [], subcategories: [], monthlyLimit: 0 });
    });
    return [...byName.values()].sort((left, right) => left.name.localeCompare(right.name, 'pt-BR'));
  }, [budgetCategories, categories]);
  function editBudget(item: BudgetCategory) { setMessage(''); setBudgetDialog({ mode: 'limit', row: item }); }
  function addSubcategory(group: CategoryGroup) { setMessage(''); setBudgetDialog({ mode: 'subcategory', group }); }
  async function saveBudgetDialog(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!firestore || !budgetDialog || savingSubcategory) return;
    const form = new FormData(event.currentTarget);
    setSavingSubcategory(true);
    try {
      if (budgetDialog.mode === 'limit') {
        const amount = Number(String(form.get('amount') || '').replace(',', '.'));
        if (!Number.isFinite(amount) || amount < 0) { setMessage('Informe um limite igual ou maior que zero.'); return; }
        await setDoc(doc(firestore, 'households', 'family-wallet', 'budgetCategories', budgetDialog.row.id), { valor_previsto: amount, updatedAt: serverTimestamp(), updatedBy: userId }, { merge: true });
        setMessage('Limite mensal atualizado.');
      } else {
        const group = budgetDialog.group; const name = String(form.get('name') || '').trim().replace(/\s+/g, ' ');
        if (name.length < 2 || name.length > 50) { setMessage('Use um nome entre 2 e 50 caracteres.'); return; }
        if (group.rows.some((row) => normalizeReferenceName(String(row.subcategoria || row.subcategory || '')) === normalizeReferenceName(name))) { setMessage(`“${name}” já existe em ${group.name}.`); return; }
        const id = `manual-${referenceId(`${group.name}-${name}`)}`;
        await setDoc(doc(firestore, 'households', 'family-wallet', 'budgetCategories', id), { name: group.name, categoryName: group.name, subcategoria: name, subcategory: name, tipo: 'Despesa', valor_previsto: 0, createdAt: serverTimestamp(), createdBy: userId, updatedAt: serverTimestamp(), updatedBy: userId });
        setMessage(`Subcategoria “${name}” adicionada a ${group.name}.`);
      }
      setBudgetDialog(null);
    } catch { setMessage('Não foi possível atualizar o orçamento agora.'); }
    finally { setSavingSubcategory(false); }
  }
  return <section className="mb-transactions"><header className="mb-page-heading"><div className="mb-page-copy"><h2>Categorias</h2><p className="form-help">Nomes, subcategorias e limites mensais.</p></div></header><div className="mb-type-tabs" role="group" aria-label="Lista de referências"><Button variant="secondary" aria-pressed={referenceTab==='categories'} onClick={()=>setReferenceTab('categories')}>Categorias</Button><Button variant="secondary" aria-pressed={referenceTab==='responsibles'} onClick={()=>setReferenceTab('responsibles')}>Responsáveis</Button></div>{referenceTab==='categories'?<ReferenceList title="Categorias" description="Agrupam receitas e despesas nos filtros e relatórios." kind="categories" items={categories} userId={userId} detailContent={item=>{const group=groups.find(g=>normalizeReferenceName(g.name)===normalizeReferenceName(item.name));return group?<><MaybeField label="Mês do orçamento"><input type="month" value={month} onChange={event=>{if(event.target.value)setMonth(event.target.value)}}/></MaybeField><BudgetGroup group={group} month={month} transactions={transactions} saving={savingSubcategory} onEdit={editBudget} onAdd={addSubcategory}/><p className="form-help">Limites são orçamento, não obrigações. Inclui previsões por competência; a margem não é saldo disponível.</p></>:null}}/>:<ReferenceList title="Responsáveis" description="Identificam quem realizou ou acompanha cada lançamento." kind="responsibles" items={responsibles} userId={userId}/>}{message&&<p role="status">{message}</p>}{budgetDialog && <ReferenceDialog title={budgetDialog.mode === 'limit' ? 'Editar limite mensal' : `Nova subcategoria de ${budgetDialog.group.name}`} onClose={() => setBudgetDialog(null)}><form onSubmit={saveBudgetDialog}>{message&&<p role="status">{message}</p>}{budgetDialog.mode === 'limit' ? <ConnectedField label={"Limite mensal"} ><input defaultValue={budgetDialog.row.valor_previsto ?? budgetDialog.row.valorPrevisto ?? budgetDialog.row.expectedAmount ?? 0} min="0" name="amount" step="0.01" type="number" /></ConnectedField> : <ConnectedField label={"Nome da subcategoria"} ><input autoComplete="off" maxLength={50} minLength={2} name="name" required placeholder="Ex.: Mercado" /></ConnectedField>}<div className="reference-dialog-actions"><button className="secondary-button" onClick={() => setBudgetDialog(null)} type="button">Cancelar</button><Button type="submit" disabled={savingSubcategory}>{savingSubcategory ? 'Salvando…' : 'Salvar'}</Button></div></form></ReferenceDialog>}</section>;
}
