'use client';

import {RecordRow} from './maybe-ui/record-row';
import {MaybeButton} from './maybe-ui/primitives';
import type { AccountView } from './accounts-screen';
import { useEffect, useState } from 'react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { firestore } from './lib/firebase';

import { buildAccountActivity, type ActivityTransaction as Transaction, type ActivityPayment as Payment, type ActivityLedger as LedgerItem } from './account-activity-model';
const money = new Intl.NumberFormat('pt-BR', { style:'currency', currency:'BRL' });
const displayDate = (value:string) => /^\d{4}-\d{2}-\d{2}$/.test(value) ? `${value.slice(8,10)}/${value.slice(5,7)}/${value.slice(0,4)}` : 'Data não informada';

export function AccountActivity({account, transactions, payments, onBack}:{account:AccountView; transactions:Transaction[]; payments:Payment[]; onBack:()=>void}) {
  const [ledger, setLedger] = useState<LedgerItem[]>([]);
  const [paymentHistory, setPaymentHistory] = useState<Payment[]>([]);
  const [incompleteRecords, setIncompleteRecords] = useState(false);
  const [ledgerState, setLedgerState] = useState<'loading'|'ready'|'error'>('loading');
  useEffect(() => {
    setLedger([]); setPaymentHistory([]); setIncompleteRecords(false); setLedgerState('loading');
    if (!firestore) { setLedgerState('error'); return; }
    const entries = query(collection(firestore,'households','family-wallet','ledgerEntries'), where('type','in',['transfer','cardPaymentReversal','cardPaymentHistory','transactionReversal']));
    return onSnapshot(entries, snapshot => {
      const histories:Payment[]=[]; let incomplete=false;
      const rows = snapshot.docs.flatMap(entry => {
        const data=entry.data();
        if (typeof data.accountId !== 'string' || !data.accountId) { incomplete=true; return []; }
        if (data.accountId !== account.id) return [];
        if (data.type === 'cardPaymentHistory') {
          const previous=data.previousPayment; if (!previous || typeof previous !== 'object') { incomplete=true; return []; }
          const amount=Number.isSafeInteger(previous.amountCents)?previous.amountCents/100:Number(previous.amount);
          if (!Number.isFinite(amount) || amount <= 0 || !data.paymentId) { incomplete=true; return []; }
          const reversedDate=typeof previous.reversedAt==='string'?previous.reversedAt.slice(0,10):previous.reversedAt?.toDate?.().toLocaleDateString('en-CA',{timeZone:'America/Sao_Paulo'}) || undefined;
          histories.push({id:`history-${entry.id}`,originalPaymentId:String(data.paymentId||''),accountId:data.accountId,paymentDate:String(previous.paymentDate||''),competence:String(previous.competence||''),amount,reversed:previous.reversedAt!=null||previous.status==='reversed',reversedDate,balanceImpact:previous.balanceImpact,status:previous.status,version:Number.isSafeInteger(previous.version)?previous.version:undefined}); return [];
        }
        if (!Number.isSafeInteger(data.amountCents) || data.amountCents === 0) { incomplete=true; return []; }
        const date = typeof data.effectiveDate === 'string' ? data.effectiveDate : data.createdAt?.toDate?.().toLocaleDateString('en-CA',{timeZone:'America/Sao_Paulo'}) || '';
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || (data.type==='transactionReversal' && (typeof data.transactionId!=='string' || !data.transactionId))) incomplete=true;
        return [{id:entry.id, accountId:data.accountId, type:data.type as LedgerItem['type'], amountCents:data.amountCents, date, balanceImpact:data.balanceImpact, reversesPaymentId:data.reversesPaymentId,paymentVersion:data.paymentVersion,transactionId:typeof data.transactionId==='string'?data.transactionId:undefined}];
      });
      setLedger(rows); setPaymentHistory(histories); setIncompleteRecords(incomplete); setLedgerState('ready');
    }, () => { setLedger([]); setPaymentHistory([]); setLedgerState('error'); });
  },[account.id]);
  const sourceIncomplete = payments.some(item=>item.accountId===account.id && (!Number.isFinite(item.amount) || item.amount<=0 || !/^\d{4}-\d{2}-\d{2}$/.test(item.paymentDate||''))) || transactions.some(item=>item.accountId===account.id && !item.cardId && item.status==='realized' && (!Number.isFinite(item.amount) || item.amount<=0));
  const items = buildAccountActivity(account.id, transactions, [...payments, ...paymentHistory], ledger, ledgerState === 'ready' && !incompleteRecords && !sourceIncomplete);
  return <section className="mb-transactions" aria-labelledby="account-activity-title">
    <div className="mb-page-heading"><div><h2 id="account-activity-title">Movimentações · {account.name}</h2></div><MaybeButton onClick={onBack}>Voltar às contas</MaybeButton></div>
    <p className="form-help">Visão parcial: mostra lançamentos realizados sem cartão, pagamentos e registros disponíveis de transferências e estornos. Registros de correção são históricos e não devem ser somados aos lançamentos atuais. Correções antigas e movimentos sem registro correspondente podem não aparecer; os itens não permitem reconstruir o saldo.</p>
    {ledgerState==='loading' && <p role="status">Carregando transferências e estornos…</p>}
    {ledgerState==='error' && <p role="alert">Não foi possível carregar transferências e estornos. A lista está incompleta.</p>}
    {(incompleteRecords || sourceIncomplete) && <p role="alert">Há registros de movimentação incompletos. Alguns itens ou estornos podem não aparecer; confira o histórico antes de usar esta lista.</p>}
    {items.length ? <div className="mb-table-container">{items.map(item=><RecordRow key={item.id} title={item.label} meta={`${displayDate(item.date)}${item.detail?` · ${item.detail}`:''}`} value={<span className={item.noBalanceImpact?'neutral':item.amount<0?'expense':'income'}>{item.noBalanceImpact?'':item.amount<0?'−':'+'}{money.format(Math.abs(item.amount))}</span>}/>)}</div> : ledgerState==='ready' ? <p className="empty-state">Nenhuma movimentação disponível nesta visão.</p> : null}
  </section>;
}
