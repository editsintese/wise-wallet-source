import { occurrencesForRuleMonth } from './recurrence-domain.ts';

export type SummaryTransaction = {
  amount: number;
  kind: 'income' | 'expense';
  category?: string;
  status: 'realized' | 'planned';
  rawDate: string;
  purchaseDate?: string;
  paidAt?: string;
  archived?: boolean;
  recurrenceId?: string;
  occurrenceMonth?: string;
};

export type RecurrenceView = {
  id?: string;
  amount: number;
  kind: 'income' | 'expense';
  startDate: string;
  endDate?: string;
  frequency?: string;
  monthsOfYear?: number[];
  active?: boolean;
  cardId?: string;
  settledMonths?: string[];
  occurrenceTransactions?: Record<string,string>;
  monthlyAmounts?: Record<string,number>;
  dueDay?: number;
};

export type FinanceSummary = {
  realizedNetCents: number;
  realizedIncomeCents: number;
  realizedExpenseCents: number;
  plannedIncomeCents: number;
  plannedExpenseCents: number;
  projectedBalanceCents: number;
  targetDate: string;
  nextPlannedIncomeCents: number;
  nextPlannedExpenseCents: number;
  nextMonthProjectedCents: number;
  nextMonthTargetDate: string;
};

const cents = (value: number) => Math.round(Number(value || 0) * 100);
const todayIso = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' });
const realizedDate = (item: SummaryTransaction) => item.paidAt || item.purchaseDate || item.rawDate;
const endOfMonth = (month: string) => {
  const year = Number(month.slice(0, 4));
  const monthNumber = Number(month.slice(5, 7));
  const day = new Date(year, monthNumber, 0).getDate();
  return `${month}-${String(day).padStart(2, '0')}`;
};
const nextMonthOf = (month: string) => {
  const date = new Date(`${month}-01T12:00:00`);
  date.setMonth(date.getMonth() + 1);
  return date.toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' }).slice(0, 7);
};
const sum = <T extends { amount: number }>(items: T[]) => items.reduce((total, item) => total + cents(item.amount), 0);

export function calculateFinanceSummary(
  transactions: SummaryTransaction[],
  recurrences: RecurrenceView[],
  referenceDate = todayIso(),
): FinanceSummary {
  const month = referenceDate.slice(0, 7);
  const targetDate = endOfMonth(month);
  const nextMonth = nextMonthOf(month);
  const nextMonthTargetDate = endOfMonth(nextMonth);
  const active = transactions.filter((item) => item.category !== 'Investimento'); // Archived rows remain in history and financial projections; investment transfers are excluded from operating results.

  const realized = active.filter((item) => item.status === 'realized' && realizedDate(item).startsWith(month) && realizedDate(item) <= referenceDate);
  const realizedIncomeCents = sum(realized.filter((item) => item.kind === 'income'));
  const realizedExpenseCents = sum(realized.filter((item) => item.kind === 'expense'));
  const realizedNetCents = realizedIncomeCents - realizedExpenseCents;

  const planned = active.filter((item) => item.status === 'planned' && item.rawDate.startsWith(month));
  const rules = recurrences.map(item => ({...item,id:item.id || 'summary',description:''}));
  const represented = active.filter(item => item.status==='planned'||item.status==='realized');
  const pendingForMonth = (target:string) => rules.flatMap(rule => occurrencesForRuleMonth(rule,target).filter(occurrence => !rule.settledMonths?.includes(occurrence.occurrenceKey) && !rule.occurrenceTransactions?.[occurrence.occurrenceKey] && !represented.some(transaction => transaction.recurrenceId===rule.id && transaction.occurrenceMonth===occurrence.occurrenceKey)));
  const recurring = pendingForMonth(month);
  const plannedIncomeCents = sum(planned.filter((item) => item.kind === 'income')) + sum(recurring.filter((item) => item.kind === 'income'));
  const plannedExpenseCents = sum(planned.filter((item) => item.kind === 'expense')) + sum(recurring.filter((item) => item.kind === 'expense'));

  const nextPlanned = active.filter((item) => item.status === 'planned' && item.rawDate.startsWith(nextMonth));
  const nextRecurring = pendingForMonth(nextMonth);
  const nextPlannedIncomeCents = sum(nextPlanned.filter((item) => item.kind === 'income')) + sum(nextRecurring.filter((item) => item.kind === 'income'));
  const nextPlannedExpenseCents = sum(nextPlanned.filter((item) => item.kind === 'expense')) + sum(nextRecurring.filter((item) => item.kind === 'expense'));

  return {
    realizedNetCents,
    realizedIncomeCents,
    realizedExpenseCents,
    plannedIncomeCents,
    plannedExpenseCents,
    projectedBalanceCents: realizedNetCents + plannedIncomeCents - plannedExpenseCents,
    targetDate,
    nextPlannedIncomeCents,
    nextPlannedExpenseCents,
    nextMonthProjectedCents: nextPlannedIncomeCents - nextPlannedExpenseCents,
    nextMonthTargetDate,
  };
}
