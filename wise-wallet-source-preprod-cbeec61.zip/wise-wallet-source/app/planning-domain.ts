import { splitInstallments } from '../packages/finance-domain/index.mjs';
export type PlanningTransaction = { amount:number; kind:'income'|'expense'; status:string; transactionDate:string; archived?:boolean; historicalOnly?:boolean; cardId?:string };
export function partialCashForecast(currentCash:number, transactions:PlanningTransaction[], months:string[]) {
 let balance=Math.round(currentCash*100);
 return months.map(month=>{const net=transactions.filter(item=>item.status==='planned'&&!item.archived&&!item.historicalOnly&&!item.cardId&&item.transactionDate.startsWith(month)&&Number.isFinite(item.amount)).reduce((sum,item)=>sum+(item.kind==='income'?1:-1)*Math.round(item.amount*100),0);balance+=net;return {month,balance:balance/100};});
}
export function simulatePurchase(forecast:{month:string;balance:number}[], amountCents:number, installments:number, startMonth:string) {
 if (!Number.isSafeInteger(amountCents)||amountCents<0||!Number.isInteger(installments)||installments<1||installments>120||!/^\d{4}-(0[1-9]|1[0-2])$/.test(startMonth)) return null;
 const parts=splitInstallments(amountCents,installments);const [year,month]=startMonth.split('-').map(Number);let cumulative=0;
 return forecast.map(item=>{const [y,m]=item.month.split('-').map(Number),index=(y-year)*12+m-month;const value=index>=0&&index<parts.length?parts[index]:0;cumulative+=value;return {...item,purchaseAmount:value/100,balanceWithPurchase:(Math.round(item.balance*100)-cumulative)/100};});
}
