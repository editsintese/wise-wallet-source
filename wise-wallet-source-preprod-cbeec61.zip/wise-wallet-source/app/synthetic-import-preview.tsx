export function SyntheticImportPreview() {
  return <section aria-labelledby="import-preview-title">
    <h1 id="import-preview-title">Importação: ensaio local</h1>
    <p>Experimente a revisão e a conciliação com exemplos fictícios. A seleção de arquivos reais continua desativada.</p>
    <iframe
      title="Ensaio de importação com dados fictícios"
      src="/ensaio-importacao/index.html?synthetic-fixtures=1"
      style={{ width: '100%', minHeight: '80vh', border: 0 }}
    />
  </section>;
}
