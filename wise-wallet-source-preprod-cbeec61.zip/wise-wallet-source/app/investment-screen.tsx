'use client';

import {InvestmentAmendmentForm,type InvestmentAmendmentContext} from './maybe-ui/investment-amendment-form';
import {InvestmentForm} from './maybe-ui/investment-form';
import {InvestmentOverview} from './maybe-ui/investment-overview';
import { FormEvent, useEffect, useRef, useState } from 'react';
import { collection, doc, getDoc, onSnapshot } from 'firebase/firestore';
import { commandBackendEnabled, firebaseAuth, firestore } from './lib/firebase';
import { callWalletCommand, newIdempotencyKey } from './lib/wallet-commands';
import { createInvestmentRequestState } from './lib/investment-request';
import {MaybeButton} from './maybe-ui/primitives';

type Account = { id: string; name: string; version?: number; archived?: boolean };
type Investment = { id: string; name: string; institution: string; type: string; investedValue: number; currentValue: number; referenceDate: string; version?: number; archivedAt?: unknown };
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' });
const amount = (value: FormDataEntryValue | null) => Number(String(value || '').replace(/\./g, '').replace(',', '.'));
const toCents = (value: FormDataEntryValue | null) => Math.round(amount(value) * 100);

function InvestmentIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M3 20h18M5 20V9m5 11V9m4 11V9m5 11V9M3 9l9-6 9 6"/><path d="M2 21h20"/></svg>;
}

export function InvestmentScreen({ accounts = [] }: { accounts?: Account[] }) {
  const [items, setItems] = useState<Investment[]>([]); const [open, setOpen] = useState(false); const [editing, setEditing] = useState<Investment | null>(null); const [saving, setSaving] = useState(false); const [message, setMessage] = useState('');
  const [amending, setAmending] = useState<InvestmentAmendmentContext | null>(null);
  const activeAccounts = accounts.filter((account) => !account.archived);
  const request = useRef<ReturnType<typeof createInvestmentRequestState> | null>(null);
  if (!request.current) {
    const uid = firebaseAuth?.currentUser?.uid;
    const journalKey = `wise-investment-pending:v1:${uid}`;
    const journal = typeof window !== 'undefined' && uid ? {
      read: () => window.sessionStorage.getItem(journalKey),
      write: (value: string) => window.sessionStorage.setItem(journalKey, value),
      clear: () => window.sessionStorage.removeItem(journalKey),
    } : undefined;
    request.current = createInvestmentRequestState(payload => callWalletCommand('manageInvestment', payload), () => newIdempotencyKey('investment'), journal);
  }
  const [pending, setPending] = useState(false);
  useEffect(() => {if (request.current!.hasPending()) {setPending(true);setMessage('Existe uma operação aguardando confirmação nesta aba. Verifique antes de iniciar outra.');}}, []);
  useEffect(() => { if (!firestore) return; return onSnapshot(collection(firestore, 'households', 'family-wallet', 'investments'), snapshot => setItems(snapshot.docs.map(entry => ({ id: entry.id, ...(entry.data() as Omit<Investment, 'id'>) })).filter(item => item.archivedAt == null)), () => setMessage('Não foi possível carregar os investimentos.')); }, []);
  async function perform(action: string, payload: Record<string, unknown>) {
    if (!commandBackendEnabled) { setMessage('Esta operação exige o serviço seguro de investimentos ativo.'); return; }
    setSaving(true); setMessage('');
    try { await request.current!.submit(action, payload); setOpen(false); setEditing(null); setAmending(null); setMessage('Operação registrada.'); }
    catch { if (request.current!.hasPending()) {setOpen(false);setEditing(null);setAmending(null);} setMessage(request.current!.hasPending() ? 'A resposta não foi confirmada. Use “Verificar operação pendente” antes de iniciar outra operação. Confira o resultado antes de fechar esta aba.' : 'Operação não concluída. Confira os dados e reabra a posição para atualizar os valores.'); }
    finally { setPending(request.current!.hasPending()); setSaving(false); }
  }
  async function retry() {
    setSaving(true);
    try { await request.current!.retry(); setOpen(false); setEditing(null); setAmending(null); setMessage('Operação confirmada, sem duplicação.'); }
    catch { if (request.current!.hasPending()) {setOpen(false);setEditing(null);setAmending(null);} setMessage(request.current!.hasPending() ? 'Ainda não foi possível confirmar. Mantenha esta página aberta e tente verificar novamente.' : 'Operação recusada. Reabra a posição e confira os dados atualizados.'); }
    finally { setPending(request.current!.hasPending()); setSaving(false); }
  }
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const data = new FormData(event.currentTarget), accountId = String(data.get('accountId') || '');
    const account = activeAccounts.find(item => item.id === accountId);
    if (!account) { setMessage('Selecione uma conta ativa.'); return; }
    await perform('create', {name: String(data.get('name') || '').trim(), institution: String(data.get('institution') || '').trim(), type: String(data.get('type') || ''), amountCents: toCents(data.get('investedValue')), currentCents: toCents(data.get('currentValue')), accountId, expectedAccountVersion: account.version ?? null, referenceDate: String(data.get('referenceDate') || today())});
  }
  async function updatePosition(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!editing) return;
    const data = new FormData(event.currentTarget), operation = String(data.get('operation') || 'valuation');
    const payload: Record<string, unknown> = {investmentId: editing.id, expectedVersion: editing.version ?? 0, name: String(data.get('name') || '').trim(), institution: String(data.get('institution') || '').trim(), type: String(data.get('type') || ''), referenceDate: String(data.get('referenceDate') || today())};
    if (operation === 'valuation') payload.currentCents = toCents(data.get('currentValue'));
    else {
      const accountId = String(data.get('accountId') || ''), account = activeAccounts.find(item => item.id === accountId);
      if (!account) { setMessage('Selecione uma conta ativa.'); return; }
      Object.assign(payload, {amountCents: toCents(data.get('movementValue')), accountId, expectedAccountVersion: account.version ?? null});
    }
    await perform(operation, payload);
  }
  async function openAmendment(item: Investment) {
    if (!firestore || !item.version || saving || pending) return;
    setEditing(null); setSaving(true); setMessage('Carregando a última operação…');
    try {
      const latest = await getDoc(doc(firestore, 'households', 'family-wallet', 'investments', item.id, 'revisions', String(item.version)));
      const source = latest.data(), operation = source?.operation || source?.action;
      if (!source || !['create','contribution','withdrawal','valuation','correct'].includes(source.action) || !['create','contribution','withdrawal','valuation'].includes(operation)) throw new Error('unsupported-history');
      let amountCents = null, accountId = null;
      if (operation !== 'valuation') {
        const snapshot = await getDoc(doc(firestore, 'households', 'family-wallet', 'transactions', String(source.transactionId || source.commandId))), movement = snapshot.data();
        if (!movement || movement.investmentId !== item.id || movement.status !== 'realized') throw new Error('unsupported-movement');
        amountCents = movement.amountCents ?? Math.round(movement.amount * 100); accountId = movement.accountId;
      }
      setAmending({item: {...item, version: item.version}, operation, basis: source.action === 'correct' ? source.basis : source.previous, amountCents, accountId, accountName: accounts.find(a => a.id === accountId)?.name || 'Conta não disponível'});
      setMessage('');
    } catch { setMessage('A última operação não possui histórico compatível para correção. Nenhum registro foi alterado.'); }
    finally { setSaving(false); }
  }
  async function amend(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!amending) return;
    const data = new FormData(event.currentTarget), action = String(data.get('amendmentAction'));
    const payload: Record<string, unknown> = {investmentId: amending.item.id, expectedVersion: amending.item.version, expectedAccountVersion: amending.accountId ? accounts.find(a => a.id === amending.accountId)?.version ?? null : null, reason: String(data.get('reason') || '').trim()};
    if (action === 'correct') Object.assign(payload, {amountCents: amending.operation === 'valuation' ? null : toCents(data.get('amountCentsInput')), currentCents: ['create','valuation'].includes(amending.operation) ? toCents(data.get('currentCentsInput')) : null});
    await perform(action, payload);
  }
  async function remove(item: Investment) {
    if (!window.confirm(`Arquivar a posição ${item.name}? Apenas posições com valor atual zero podem ser arquivadas. O histórico e os movimentos serão preservados.`)) return;
    await perform('archive', {investmentId: item.id, expectedVersion: item.version ?? 0});
  }
  return <section className="investments"><InvestmentOverview items={items} onAdd={saving || pending ? undefined : () => {setMessage('');setOpen(true)}} onEdit={saving || pending ? undefined : item => {setMessage('');setEditing(item)}} onRemove={saving || pending ? undefined : item => void remove(item)} removeLabel="Arquivar"/>{message && <p className="form-help" role="status">{message}</p>}{pending && <MaybeButton disabled={saving} onClick={() => void retry()}>Verificar operação pendente</MaybeButton>}{open && <InvestmentForm accounts={activeAccounts} saving={saving || pending} error={message} onClose={() => {if (!saving) setOpen(false)}} onSubmit={save}/>}{editing && <InvestmentForm item={editing} accounts={activeAccounts} saving={saving || pending} error={message} onClose={() => {if (!saving) setEditing(null)}} onSubmit={updatePosition} onAmend={editing.version ? () => void openAmendment(editing) : undefined}/>}{amending&&<InvestmentAmendmentForm context={amending} saving={saving||pending} error={message} onClose={()=>{if(!saving)setAmending(null)}} onSubmit={amend}/>}</section>;
}
