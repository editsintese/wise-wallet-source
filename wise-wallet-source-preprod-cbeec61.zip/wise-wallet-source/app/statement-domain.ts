// Statement reconstruction per account (mobile-first "extrato").
// Canonical accounts rebuild the running balance exclusively from immutable
// ledger entries; legacy rows (pre-cutover) are attached as historical context
// without touching the stored balance. When evidence is missing or the
// reconstruction disagrees with the stored balance, the statement signals
// itself as partial/inconsistent instead of inventing numbers.

export type StatementInputRow = Record<string, unknown> & {
  id?: string;
  kind?: string;
  type?: string;
  status?: string;
  amount?: number;
  amountCents?: number;
  accountId?: string;
  transactionDate?: string;
  purchaseDate?: string;
  paidAt?: string;
  settlementDate?: string;
  effectiveDate?: string;
  paymentDate?: string;
  cardId?: string;
  reversed?: boolean;
  archived?: boolean;
  archivedAt?: unknown;
  historicalOnly?: boolean;
  deletedAt?: unknown;
  balanceImpact?: boolean;
  recurrenceId?: string;
};

export type StatementLedgerEntry = Record<string, unknown> & {
  id?: string;
  type?: string;
  accountId?: string;
  amountCents?: number;
  effectiveDate?: string;
  balanceImpact?: boolean;
  transactionId?: string;
  recurrenceId?: string;
  cardId?: string;
  competence?: string;
  reversesPaymentId?: string;
};

export type StatementAccount = {
  id: string;
  name: string;
  version?: number;
  serverBalance?: number;
  openingBalance: number;
  openingDate?: string;
  archived?: boolean;
};

export type StatementEntry = {
  id: string;
  date: string;
  type: string;
  label: string;
  amountCents: number;
  balanceImpact: boolean;
  detail?: string;
};

export type StatementDay = {
  date: string;
  entries: StatementEntry[];
  runningCents: number | null;
  runningKnown: boolean;
};

export type AccountStatement = {
  accountId: string;
  accountName: string;
  openingCents: number | null;
  openingKnown: boolean;
  days: StatementDay[];
  closingCents: number | null;
  storedCents: number | null;
  partial: boolean;
  consistent: boolean;
  reasons: string[];
};

const CENTS = (value: number) => Math.round(Number(value || 0) * 100);
const DATE_FALLBACK = '';

export function statementEntryLabel(type: string, row: StatementInputRow): string {
  switch (type) {
    case 'transactionReversal':
      return `Estorno de lançamento${row.recurrenceId ? ' · recorrência' : ''}`;
    case 'cardPayment':
      return `Pagamento de fatura · ${String(row.cardId || 'cartão')}`;
    case 'cardPaymentReversal':
      return `Estorno de fatura · ${String(row.cardId || 'cartão')}`;
    case 'openingBalanceAdjustment':
      return 'Ajuste de saldo inicial';
    case 'transfer':
      return 'Transferência';
    case 'income':
      return 'Receita';
    case 'expense':
      return 'Despesa';
    default:
      return String(type || 'Movimentação');
  }
}

function effectiveDateOf(row: StatementInputRow): string {
  const value = row.effectiveDate || row.settlementDate || row.paidAt || row.transactionDate || row.purchaseDate || row.paymentDate || '';
  return typeof value === 'string' ? value.slice(0, 10) : DATE_FALLBACK;
}

/** Legacy rows as historical context: they never touch canonical stored balances. */
function legacyEntries(rows: StatementInputRow[], accountId: string): StatementEntry[] {
  return rows
    .filter((row) => row.accountId === accountId)
    .filter((row) => row.status === 'realized' || row.status === 'paid')
    .filter((row) => !row.archived && row.archivedAt == null && row.deletedAt == null)
    .filter((row) => row.historicalOnly !== true)
    .filter((row) => (row.kind === 'income' || row.kind === 'expense' || row.type === 'income' || row.type === 'expense'))
    .map((row, index) => {
      const kind = row.kind === 'income' || row.type === 'income' ? 'income' : 'expense';
      const cents = Math.round(Number(row.amountCents ?? CENTS(Number(row.amount || 0))));
      return {
        id: String(row.id || `legacy-${index}`),
        date: effectiveDateOf(row),
        type: kind,
        label: String(row.description || (kind === 'income' ? 'Receita' : 'Despesa') || 'Movimentação'),
        amountCents: kind === 'income' ? cents : -cents,
        balanceImpact: false,
        detail: 'registro legado',
      };
    })
    .filter((entry) => entry.date);
}

export function buildAccountStatement(input: {
  account: StatementAccount;
  ledger: StatementLedgerEntry[];
  transactions: StatementInputRow[];
  cardPayments: StatementInputRow[];
}): AccountStatement {
  const { account, ledger, transactions, cardPayments } = input;
  const reasons: string[] = [];
  const canonical = account.version !== undefined;
  const storedCents = Number.isFinite(account.serverBalance) ? CENTS(account.serverBalance!) : null;
  const openingCents = Number.isFinite(Number(account.openingBalance)) ? CENTS(account.openingBalance) : 0;
  const ledgerRows = ledger.filter((entry) => entry.accountId === account.id).sort((a, b) => String(a.effectiveDate || '').localeCompare(String(b.effectiveDate || '')));

  const entries: StatementEntry[] = ledgerRows.map((entry, index) => {
    const amountCents = Number.isSafeInteger(entry.amountCents) ? Number(entry.amountCents) : CENTS(Number(entry.amount || 0));
    return {
      id: String(entry.id || `ledger-${index}`),
      date: String(entry.effectiveDate || '').slice(0, 10),
      type: String(entry.type || 'legacyEntry'),
      label: statementEntryLabel(String(entry.type || ''), entry as StatementInputRow),
      amountCents,
      balanceImpact: entry.balanceImpact !== false,
      detail: entry.competence ? `Competência ${String(entry.competence)}` : undefined,
    };
  }).filter((entry) => entry.date && Number.isSafeInteger(entry.amountCents));

  if (!canonical) {
    reasons.push('Conta legada: registros anteriores ao corte não possuem razão contábil imutável.');
    for (const entry of legacyEntries(transactions, account.id)) entries.push(entry);
    for (const payment of cardPayments.filter((row) => !row.reversed && row.accountId === account.id)) {
      const date = effectiveDateOf(payment);
      if (!date) continue;
      const cents = Math.round(Number(payment.amountCents ?? CENTS(Number(payment.amount || 0))));
      entries.push({
        id: String(payment.id || `legacy-payment-${date}`),
        date,
        type: 'cardPayment',
        label: `Pagamento de fatura · ${String(payment.cardId || 'cartão')}`,
        amountCents: -cents,
        balanceImpact: false,
        detail: 'registro legado',
      });
    }
  } else if (ledgerRows.length === 0) {
    reasons.push('A conta canônica ainda não possui lançamentos contábeis; o histórico legado não é reproduzível.');
  } else {
    const legacyAccountRows = legacyEntries(transactions, account.id).length;
    if (legacyAccountRows > 0) reasons.push('Registros legados aparecem como contexto, sem efeito sobre o saldo armazenado.');
  }

  entries.sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
  const dayMap = new Map<string, StatementEntry[]>();
  for (const entry of entries) {
    const list = dayMap.get(entry.date) || [];
    list.push(entry);
    dayMap.set(entry.date, list);
  }
  let running: number | null = openingCents;
  let runningKnown = canonical;
  const days: StatementDay[] = [...dayMap.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([date, dayEntries]) => {
    if (!canonical) {
      // Legacy reconstruction applies every movement to the running estimate.
      for (const entry of dayEntries) {
        running = (running ?? 0) + entry.amountCents;
      }
    } else {
      // Canonical: the stored balance only reflects balance-impacting ledger rows.
      for (const entry of dayEntries) {
        if (entry.balanceImpact) running = (running ?? 0) + entry.amountCents;
      }
    }
    return { date, entries: dayEntries, runningCents: running, runningKnown };
  });

  const closingCents = running;
  let consistent = true;
  if (canonical && storedCents !== null && closingCents !== null && closingCents !== storedCents) {
    consistent = false;
    reasons.push('O saldo reconstruído difere do saldo armazenado: pode haver lançamentos antigos fora da razão contábil.');
  }
  if (canonical && storedCents === null) {
    reasons.push('O saldo armazenado não está disponível nesta conta.');
  }
  const partial = !canonical || !consistent || reasons.some((reason) => reason.includes('não possui lançamentos') || reason.includes('legado'));

  return {
    accountId: account.id,
    accountName: account.name,
    openingCents: openingCents,
    openingKnown: canonical,
    days,
    closingCents,
    storedCents,
    partial,
    consistent,
    reasons: [...new Set(reasons)],
  };
}