import type { Metadata, Viewport } from 'next';
import './clareza.css';
import { ScrollToTop } from './scroll-to-top';
import { NextProjectionDialog } from './next-projection-dialog';
import { MobileZoomGuard } from './mobile-zoom-guard';

export const metadata: Metadata = {
  title: 'Wise Wallet Lite',
  description: 'Planejamento financeiro compartilhado para a família.',
  icons: { icon: '/favicon.svg' },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
  themeColor: '#f5f7fb',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><head><link rel="preload" href="/fonts/dm-sans/dm-sans.ttf" as="font" type="font/ttf" crossOrigin="anonymous" /></head><body>{children}<MobileZoomGuard /><ScrollToTop /><NextProjectionDialog /></body></html>;
}
