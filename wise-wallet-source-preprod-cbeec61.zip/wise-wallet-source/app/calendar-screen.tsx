'use client';
import {useEffect,useState} from 'react';
import {collection,onSnapshot} from 'firebase/firestore';
import {firestore} from './lib/firebase';
import {CalendarView} from './maybe-ui/calendar-view';
import type {TransactionView} from './transaction-model';
import type {RecurrenceRule} from './recurrence-domain';
export function CalendarScreen({transactions,recurrences,cardPayments}:{transactions:TransactionView[];recurrences:RecurrenceRule[];cardPayments:{cardId:string;competence:string;amount?:number;status?:string;reversed?:boolean}[]}){
 const [cards,setCards]=useState<{id:string;name:string;dueDay:number}[]>([]);
 useEffect(()=>{if(!firestore)return;return onSnapshot(collection(firestore,'households','family-wallet','cards'),snapshot=>setCards(snapshot.docs.map(entry=>({id:entry.id,name:String(entry.data().name||'Cartão'),dueDay:Number(entry.data().dueDay)||1}))));},[]);
 return <CalendarView transactions={transactions} recurrences={recurrences} cardPayments={cardPayments} cards={cards}/>;
}
