'use client';

import type {RegisteredRecurrenceTransaction} from './recurrence-rows';
import { useState } from 'react';
import {MaybeDialog as ResponsiveDialog} from './maybe-ui/dialog';
import {MaybeButton as Button} from './maybe-ui/primitives';
import { CurrencyInput, formatCurrencyAmount } from './design-system/currency-input';
import {MaybeField as Field} from './maybe-ui/primitives';
import { occurrencesForRuleMonth, type RecurrenceRule } from './recurrence-domain';

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

export function RecurrenceOccurrenceModal({ item, month, accounts, onClose, onConfirm, saving = false, preview=false, onPreviewComplete,registered,error:externalError,planned=false }: {planned?:boolean;error?:string;registered?:RegisteredRecurrenceTransaction; preview?:boolean;onPreviewComplete?:()=>void;title?:string;item: RecurrenceRule; month: string; accounts: { id: string; name: string; archived?: boolean }[]; onClose: () => void; onConfirm: (input: { amount: number; date: string; accountId: string }) => Promise<void>; saving?: boolean }) {
  const occurrence=registered?undefined:occurrencesForRuleMonth(item,month.slice(0,7)).find(entry=>entry.occurrenceKey===month);
  const [amount, setAmount] = useState(formatCurrencyAmount(registered?.amount ?? occurrence?.amount ?? item.amount));
  const [date, setDate] = useState(() => planned?(registered?.scheduledDate || registered?.rawDate || occurrence?.date || ''):new Date().toLocaleDateString('en-CA',{timeZone:'America/Sao_Paulo'}));
  const [accountId, setAccountId] = useState(registered?.accountId || item.accountId || '');
  const [error, setError] = useState('');
  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const parsed = Number(String(amount).replace(/\./g, '').replace(',', '.'));
    if (!Number.isFinite(parsed) || parsed <= 0 || !accountId || !date) { setError('Informe um valor, uma data e a conta usada.'); return; }
    setError(''); if(preview){onPreviewComplete?.();return;} await onConfirm({ amount: parsed, date, accountId });
  };
  const isIncome = (registered?.kind || item.kind) === 'income';
  return <ResponsiveDialog title={planned?'Confirmar compromisso previsto':isIncome ? 'Registrar recebimento' : 'Registrar pagamento'} onClose={onClose}>
    <p className="section-description">{item.description} · {month}</p>
    <form className="recurrence-occurrence-form" onSubmit={submit}>
      <Field label="Valor"><CurrencyInput value={amount} onValueChange={setAmount} aria-label="Valor da ocorrência" /></Field>
      <Field label={isIncome ? 'Conta de destino' : 'Conta de saída'}><select disabled={saving||Boolean(registered)} value={accountId} onChange={(event) => setAccountId(event.target.value)}><option value="">Selecione uma conta</option>{accounts.filter((account) => !account.archived).map((account) => <option key={account.id} value={account.id}>{account.name}</option>)}</select></Field>
      <Field label={planned?'Data programada':isIncome ? 'Data do recebimento' : 'Data do pagamento'}><input readOnly={planned} type="date" value={date} onChange={(event) => setDate(event.target.value)} /></Field>
      <p className="form-help">{preview?'Ensaio com dados fictícios. Nenhum lançamento ou saldo será alterado.':planned?'Confirma apenas o compromisso previsto. Nenhum saldo será movimentado.':'O pagamento será vinculado à ocorrência e atualizará o saldo da conta.'} {registered?'Valor do compromisso registrado':'Valor previsto'}: {money.format(registered?.amount ?? occurrence?.amount ?? item.amount ?? 0)}. {registered?'A conta original será mantida.':''}</p>
      {(externalError||error) && <p className="form-error" role="alert">{externalError||error}</p>}
      <div className="modal-actions"><Button variant="outline" onClick={onClose}>Cancelar</Button><Button variant="primary" type="submit" disabled={saving}>{preview?'Concluir ensaio':saving ? 'Salvando…' : planned?'Confirmar compromisso':isIncome ? 'Confirmar recebimento' : 'Confirmar pagamento'}</Button></div>
    </form>
  </ResponsiveDialog>;
}
