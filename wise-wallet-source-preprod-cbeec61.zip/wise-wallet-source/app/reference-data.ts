export type ReferenceItem = {id:string;name:string;archived:boolean;builtIn?:boolean};
export type StoredReference = {id:string;name:string;archived?:boolean};

export const defaultCategories=['Sem categoria','Alimentação','Casa','Compras','Pets','Transporte','Saúde','Receita','Outros'];
export const defaultResponsibles=['Família','Pessoa 1','Pessoa 2'];

export const normalizeReferenceName=(value:string)=>value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().replace(/\s+/g,' ').toLocaleLowerCase('pt-BR');
export const referenceId=(value:string)=>normalizeReferenceName(value).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,64);

export function importedCategoryReferences(rows:{name?:string;categoryName?:string}[]):StoredReference[]{
  return [...new Map(rows.map(item=>{const name=String(item.name||item.categoryName||'').trim();return [normalizeReferenceName(name),{id:referenceId(name),name,archived:false}];})).values()].filter(item=>item.name);
}

export function resolveReferences(defaults:string[],stored:StoredReference[]):ReferenceItem[]{
  const items=new Map(defaults.map(name=>[referenceId(name),{id:referenceId(name),name,archived:false,builtIn:true}]));
  for(const item of stored){if(!item.id||!item.name?.trim())continue;const previous=items.get(item.id);items.set(item.id,{id:item.id,name:item.name.trim(),archived:item.archived===true,builtIn:previous?.builtIn===true});}
  return [...items.values()].sort((a,b)=>Number(a.archived)-Number(b.archived)||a.name.localeCompare(b.name,'pt-BR',{sensitivity:'base'}));
}

export const activeReferenceNames=(items:ReferenceItem[],current?:string)=>[...new Set([...items.filter(item=>!item.archived).map(item=>item.name),...(current?[current]:[])])].sort((a,b)=>a.localeCompare(b,'pt-BR',{sensitivity:'base'}));
