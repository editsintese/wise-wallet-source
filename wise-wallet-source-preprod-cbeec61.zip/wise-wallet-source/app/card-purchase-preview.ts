import { addMonths, civilDate, splitInstallments } from '../packages/finance-domain/index.mjs';

/** Display-only projection using the same date and cent rules as manageCardPurchase. */
export function cardPurchasePreview(totalCents: number, count: number, firstInvoiceDate: string) {
  if (!Number.isSafeInteger(totalCents) || totalCents <= 0 || !Number.isSafeInteger(count) || count < 1 || count > 120 || totalCents < count) return [];
  try {
    civilDate(firstInvoiceDate);
    return splitInstallments(totalCents, count).map((amountCents: number, index: number) => ({
      number: index + 1,
      amountCents,
      date: addMonths(firstInvoiceDate, index),
    }));
  } catch { return []; }
}
