'use client';

import { useEffect, useState } from 'react';
import { FilterState } from './filter-state';

type SavedView = { id: string; name: string; state: FilterState };
const keyFor = (userId: string, section: string) => `wise-wallet-custom-views-${userId}-${section}`;

export function CustomSavedViews({ userId, section, current, onApply }: { userId: string; section: string; current: FilterState; onApply: (state: FilterState) => void }) {
  const [views, setViews] = useState<SavedView[]>([]);
  const save = (next: SavedView[]) => { setViews(next); window.localStorage.setItem(keyFor(userId, section), JSON.stringify(next)); };
  useEffect(() => {
    try { setViews(JSON.parse(window.localStorage.getItem(keyFor(userId, section)) || '[]') as SavedView[]); } catch { setViews([]); }
  }, [section, userId]);
  const create = () => {
    const name = window.prompt('Nome desta visão:');
    if (!name?.trim()) return;
    save([...views, { id: crypto.randomUUID(), name: name.trim(), state: current }]);
  };
  const rename = (view: SavedView) => {
    const name = window.prompt('Novo nome da visão:', view.name);
    if (!name?.trim()) return;
    save(views.map((item) => item.id === view.id ? { ...item, name: name.trim() } : item));
  };
  const remove = (view: SavedView) => {
    if (window.confirm(`Remover a visão “${view.name}”?`)) save(views.filter((item) => item.id !== view.id));
  };
  return <div className="custom-saved-views"><div><span>Suas visões</span><button className="text-button" type="button" onClick={create}>Salvar filtros atuais</button></div>{views.length > 0 && <ul>{views.map((view) => <li key={view.id}><button type="button" className="custom-view-apply" onClick={() => onApply(view.state)}>{view.name}</button><button type="button" className="text-button" onClick={() => rename(view)} aria-label={`Renomear ${view.name}`}>Renomear</button><button type="button" className="text-button danger" onClick={() => remove(view)} aria-label={`Remover ${view.name}`}>Remover</button></li>)}</ul>}</div>;
}
