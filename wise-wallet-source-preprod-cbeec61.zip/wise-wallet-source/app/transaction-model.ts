export type TransactionView = {
  id: string;
  description: string;
  amount: number;
  kind: 'income' | 'expense';
  status: 'realized' | 'planned';
  rawDate: string;
  purchaseDate?: string;
  paidAt?: string;
  category: string;
  subcategory?: string;
  owner: string;
  archived?: boolean;
  historicalOnly?: boolean;
  accountId?: string;
  cardId?: string;
  installmentNumber?: number;
  installmentCount?: number;
  installmentGroupId?: string;
  createdAt?: { seconds?: number; toMillis?: () => number } | string;
};

export type TransactionSort =
  | 'date-desc'
  | 'date-asc'
  | 'amount-desc'
  | 'amount-asc'
  | 'description-asc';

export type DateBasis = 'occurrence' | 'competence';

export const dateBasisLabel = (basis: DateBasis) =>
  basis === 'occurrence' ? 'Compra/lançamento' : 'Competência/fatura';

export const dateBasisDescription = (basis: DateBasis) =>
  basis === 'occurrence'
    ? 'Usa a data da compra e consolida parcelas na 1ª ocorrência.'
    : 'Usa a data da fatura; cada parcela aparece na sua competência.';

export const todayIso = () =>
  new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' });

export const occurrenceDate = (item: TransactionView) => item.purchaseDate || item.rawDate;

export const realizedDate = (item: TransactionView) => item.paidAt || occurrenceDate(item);

export const dateForBasis = (item: TransactionView, basis: DateBasis) =>
  (basis === 'occurrence' ? occurrenceDate(item) : item.rawDate) || '';

export const isDateInRange = (item: TransactionView, basis: DateBasis, start: string, end: string) => {
  const date = dateForBasis(item, basis);
  return Boolean(date) && date >= start && date <= end;
};

export const isPrimaryOccurrence = (item: TransactionView) =>
  !item.installmentNumber || item.installmentNumber === 1;

export const isRecentOccurrence = (item: TransactionView, cutoff = todayIso()) =>
  !item.archived &&
  isPrimaryOccurrence(item) &&
  occurrenceDate(item) <= cutoff &&
  (item.status !== 'realized' || realizedDate(item) <= cutoff);

export const normalizeSearch = (value: string) =>
  value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR').trim();

export const matchesSearch = (item: TransactionView, search: string) => {
  const term = normalizeSearch(search);
  if (!term) return true;
  return normalizeSearch(
    [item.description, item.category, item.owner].filter(Boolean).join(' '),
  ).includes(term);
};

export const sortTransactions = <T extends TransactionView>(
  items: T[],
  sort: TransactionSort,
  basis: DateBasis = 'occurrence',
) => [...items].sort((left, right) => {
  if (sort === 'amount-desc') return right.amount - left.amount;
  if (sort === 'amount-asc') return left.amount - right.amount;
  if (sort === 'description-asc') {
    return left.description.localeCompare(right.description, 'pt-BR', { sensitivity: 'base' });
  }
  const comparison = dateForBasis(left, basis).localeCompare(dateForBasis(right, basis));
  if (comparison) return sort === 'date-asc' ? comparison : -comparison;
  const createdTime = (item: TransactionView) => {
    if (typeof item.createdAt === 'string') return Date.parse(item.createdAt) || 0;
    if (item.createdAt?.toMillis) return item.createdAt.toMillis();
    return Number(item.createdAt?.seconds || 0) * 1000;
  };
  const createdComparison = createdTime(left) - createdTime(right);
  return sort === 'date-asc' ? createdComparison : -createdComparison;
});

export const installmentText = (item: TransactionView) =>
  item.installmentCount
    ? `${item.installmentNumber || 1} de ${item.installmentCount}`
    : 'À vista';
