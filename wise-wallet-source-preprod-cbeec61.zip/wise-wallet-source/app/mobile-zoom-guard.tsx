'use client';

import { useEffect } from 'react';

export function MobileZoomGuard() {
  useEffect(() => {
    const cancelGesture = (event: Event) => event.preventDefault();
    const cancelMultiTouch = (event: TouchEvent) => {
      if (event.touches.length > 1) event.preventDefault();
    };

    document.addEventListener('gesturestart', cancelGesture, { passive: false });
    document.addEventListener('gesturechange', cancelGesture, { passive: false });
    document.addEventListener('gestureend', cancelGesture, { passive: false });
    document.addEventListener('touchmove', cancelMultiTouch, { passive: false });

    return () => {
      document.removeEventListener('gesturestart', cancelGesture);
      document.removeEventListener('gesturechange', cancelGesture);
      document.removeEventListener('gestureend', cancelGesture);
      document.removeEventListener('touchmove', cancelMultiTouch);
    };
  }, []);

  return null;
}
