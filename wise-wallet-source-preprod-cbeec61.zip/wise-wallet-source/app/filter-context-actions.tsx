'use client';

import { useState } from 'react';

export function FilterContextActions({ activeCount }: { activeCount: number }) {
  const [copied, setCopied] = useState(false);
  const copyLink = async () => {
    const link = window.location.href;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      window.prompt('Copie o link desta visão:', link);
    }
  };
  return <div className="filter-context-actions"><span className={activeCount ? 'filters-active' : 'filters-default'}>{activeCount ? `${activeCount} filtro(s) ativo(s)` : 'Sem filtros adicionais'}</span><button className="text-button" type="button" onClick={() => void copyLink()}>{copied ? 'Link copiado' : 'Copiar link desta visão'}</button></div>;
}
