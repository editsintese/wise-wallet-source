import { invoicePaymentSummary } from './invoice-payments.ts';
import { occurrencesForRuleMonth } from './recurrence-domain.ts';
import type { RecurrenceRule } from './recurrence-domain.ts';
import type { TransactionView } from './transaction-model.ts';

export type CalendarTransaction = Omit<TransactionView, 'status'> & {
  status: TransactionView['status'] | 'cancelled';
  recurrenceId?: string;
  occurrenceMonth?: string;
  cancelled?: boolean;
  deletedAt?: unknown;
};
export type CalendarCard = { id: string; name: string; dueDay: number };
export type CalendarPayment = { cardId: string; competence: string; amount?: number; reversed?: boolean; status?: string };
export type CalendarEvent = {
  id: string;
  date: string;
  description: string;
  amount: number;
  kind: 'income' | 'expense';
  source: 'transaction' | 'recurrence' | 'invoice';
  status?: string;
  item?: TransactionView;
};

const normalizedDescription = (value: string) => value
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '')
  .trim()
  .replace(/\s+/g, ' ')
  .toLocaleLowerCase('pt-BR');

const invoiceDueDate = (month: string, dueDay: number) => {
  const [year, monthNumber] = month.split('-').map(Number);
  const lastDay = new Date(year, monthNumber, 0).getDate();
  return `${month}-${String(Math.min(Math.max(1, dueDay || 1), lastDay)).padStart(2, '0')}`;
};

export function buildCalendarEvents({
  month,
  transactions,
  recurrences,
  cards,
  cardPayments,
}: {
  month: string;
  transactions: CalendarTransaction[];
  recurrences: RecurrenceRule[];
  cards: CalendarCard[];
  cardPayments: CalendarPayment[];
}): CalendarEvent[] {
  const monthTransactions = transactions.filter((item): item is CalendarTransaction & { status: TransactionView['status'] } =>
    !item.archived && !item.cancelled && item.status !== 'cancelled' && !item.deletedAt && item.rawDate.startsWith(month),
  );
  const transactionEvents: CalendarEvent[] = monthTransactions.map((item) => ({
    id: `transaction-${item.id}`,
    date: item.rawDate,
    description: item.description,
    amount: item.amount,
    kind: item.kind,
    source: 'transaction',
    status: item.status,
    item,
  }));

  const representedTransactionIds = new Set<string>();
  const recurrenceEvents: CalendarEvent[] = recurrences.flatMap(item => occurrencesForRuleMonth(item,month).flatMap(occurrence => {
    const represented = monthTransactions.find(transaction => {
      if(representedTransactionIds.has(transaction.id)||transaction.cardId)return false;
      const linked=transaction.recurrenceId===item.id && transaction.occurrenceMonth===occurrence.occurrenceKey;
      const matching=transaction.status==='planned' && transaction.kind===item.kind && normalizedDescription(transaction.description)===normalizedDescription(item.description) && Math.round(transaction.amount*100)===Math.round(occurrence.amount*100) && (!transaction.accountId||!item.accountId||transaction.accountId===item.accountId) && (item.frequency!=='weekly'||transaction.rawDate===occurrence.date);
      return linked||matching;
    });
    if(represented){representedTransactionIds.add(represented.id);return [];}
    return [{id:`recurrence-${item.id}-${occurrence.occurrenceKey}`,date:occurrence.date,description:item.description,amount:occurrence.amount,kind:item.kind,source:'recurrence' as const,status:occurrence.status==='realized'?'liquidada':'prevista'}];
  }));

  const invoiceEvents: CalendarEvent[] = cards.flatMap((card) => {
    const actualItems = monthTransactions.filter((item) => item.cardId === card.id && !item.historicalOnly);
    const recordedOccurrences = new Set(actualItems
      .filter((item) => item.recurrenceId && item.occurrenceMonth)
      .map((item) => `${item.recurrenceId}|${item.occurrenceMonth}`));
    const scheduledCardOccurrences = recurrences
      .filter((item) => item.cardId === card.id)
      .flatMap((item) => occurrencesForRuleMonth(item, month))
      .filter((item) => !recordedOccurrences.has(`${item.recurrenceId}|${item.occurrenceKey}`));
    const total = actualItems.reduce((sum, item) => sum + (item.kind === 'income' ? -item.amount : item.amount), 0)
      + scheduledCardOccurrences.reduce((sum, item) => sum + (item.kind === 'income' ? -item.amount : item.amount), 0);
    if (total === 0) return [];
    const summary = invoicePaymentSummary(cardPayments.map(payment => ({ ...payment, amount: payment.amount ?? NaN })), card.id, month, total);
    return [{
      id: `invoice-${card.id}-${month}`,
      date: invoiceDueDate(month, card.dueDay),
      description: `Fatura ${card.name}`,
      amount: Math.abs(total),
      kind: total < 0 ? 'income' as const : 'expense' as const,
      source: 'invoice' as const,
      status: summary.uncertain ? 'pagamento a conferir' : summary.fullyPaid ? 'liquidada' : summary.paid > 0 ? 'parcialmente paga' : summary.scheduled > 0 ? 'pagamento agendado' : 'em aberto',
    }];
  });

  return [...transactionEvents, ...recurrenceEvents, ...invoiceEvents]
    .sort((left, right) => left.date.localeCompare(right.date) || left.source.localeCompare(right.source));
}
