import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { firestore } from './lib/firebase';
import { referenceId, StoredReference } from './reference-data';

const cleanName = (value: string) => value.trim().replace(/\s+/g, ' ');

export async function saveCategoryOption(value: string, userId: string): Promise<StoredReference> {
  const name = cleanName(value);
  if (!firestore || name.length < 2 || name.length > 50) throw new Error('invalid-category');
  const id = referenceId(name);
  if (!id) throw new Error('invalid-category');
  await setDoc(doc(firestore, 'households', 'family-wallet', 'categories', id), {
    name,
    archived: false,
    createdAt: serverTimestamp(),
    createdBy: userId,
    updatedAt: serverTimestamp(),
    updatedBy: userId,
  }, { merge: true });
  return { id, name, archived: false };
}

export async function saveSubcategoryOption(category: string, value: string, userId: string) {
  const name = cleanName(value);
  const categoryName = cleanName(category);
  if (!firestore || categoryName.length < 2 || name.length < 2 || name.length > 50) throw new Error('invalid-subcategory');
  const id = `manual-${referenceId(`${categoryName}-${name}`)}`;
  if (id === 'manual-') throw new Error('invalid-subcategory');
  await setDoc(doc(firestore, 'households', 'family-wallet', 'budgetCategories', id), {
    name: categoryName,
    categoryName,
    subcategoria: name,
    subcategory: name,
    tipo: 'Despesa',
    valor_previsto: 0,
    createdAt: serverTimestamp(),
    createdBy: userId,
    updatedAt: serverTimestamp(),
    updatedBy: userId,
  });
  return name;
}
