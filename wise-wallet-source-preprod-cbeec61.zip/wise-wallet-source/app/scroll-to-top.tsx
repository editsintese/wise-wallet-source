'use client';

import { useEffect, useState } from 'react';

export function ScrollToTop() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const scroller = document.querySelector<HTMLElement>('.workspace');
    if (!scroller) return;
    const update = () => setVisible(scroller.scrollTop > 360);
    update();
    scroller.addEventListener('scroll', update, { passive: true });
    return () => scroller.removeEventListener('scroll', update);
  }, []);
  return <button className={`scroll-top-button ${visible ? 'visible' : ''}`} type="button" aria-label="Voltar ao início" onClick={() => document.querySelector<HTMLElement>('.workspace')?.scrollTo({ top: 0, behavior: 'smooth' })}><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><path d="M12 20V4m-7 7 7-7 7 7"/></svg></button>;
}
