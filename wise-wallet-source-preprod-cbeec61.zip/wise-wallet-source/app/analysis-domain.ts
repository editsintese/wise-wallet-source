import type {TransactionView} from './transaction-model';
export type AnalysisTransaction=TransactionView&{cancelled?:boolean;type?:string};
export function buildAnalysis(items:AnalysisTransaction[],options:{endMonth:string;months:number;kind?:string;status?:string;owner?:string;category?:string}){
 const count=[3,6,12].includes(options.months)?options.months:6;
 const end=new Date(options.endMonth+'-01T12:00:00');
 if(Number.isNaN(end.valueOf()))throw Error('invalid-month');
 const months=Array.from({length:count},(_,i)=>{const d=new Date(end);d.setMonth(d.getMonth()+i-count+1);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`});
 const visible=items.filter(t=>!t.archived&&!t.cancelled&&!['transfer','card-payment','cardPayment'].includes(t.type||'')&&Number.isFinite(t.amount)&&months.includes(t.rawDate.slice(0,7))&&(!options.kind||options.kind==='all'||t.kind===options.kind)&&(!options.status||options.status==='all'||t.status===options.status)&&(!options.owner||options.owner==='all'||t.owner===options.owner)&&(!options.category||options.category==='all'||t.category===options.category));
 const sum=(rows:AnalysisTransaction[],kind:string)=>rows.filter(t=>t.kind===kind).reduce((s,t)=>s+Math.round(t.amount*100),0);
 const incomeCents=sum(visible,'income'),expenseCents=sum(visible,'expense');
 const group=(key:'category'|'owner')=>[...new Set(visible.filter(t=>t.kind==='expense').map(t=>t[key]||'Não informado'))].map(name=>({name,amountCents:sum(visible.filter(t=>(t[key]||'Não informado')===name),'expense')})).sort((a,b)=>b.amountCents-a.amountCents);
 return {visible,incomeCents,expenseCents,netCents:incomeCents-expenseCents,plannedCount:visible.filter(t=>t.status==='planned').length,months:months.map(month=>{const rows=visible.filter(t=>t.rawDate.startsWith(month));return {month,incomeCents:sum(rows,'income'),expenseCents:sum(rows,'expense')}}),categories:group('category'),owners:group('owner')};
}
