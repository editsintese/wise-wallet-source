'use client';

import { FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { addDoc, collection, deleteDoc, doc, onSnapshot, serverTimestamp, updateDoc, writeBatch } from 'firebase/firestore';
import { commandBackendEnabled, firebaseAuth, firestore } from './lib/firebase';
import { accountFromDoc } from './canonical-adapters';
import { callWalletCommand, newIdempotencyKey } from './lib/wallet-commands';
import { TransactionChips } from './transaction-components';
import { persistFilterState, readFilterState } from './filter-state';
import { FilterContextActions } from './filter-context-actions';
import { dateBasisDescription, dateBasisLabel, matchesSearch, sortTransactions, TransactionSort, TransactionView } from './transaction-model';
import { FinancialListItem } from './design-system/financial-list-item';
import { MoneyValue } from './design-system/money-value';
import { moneyTone } from './design-system/money-tone';
import { InstitutionLogo } from './design-system/institution-logo';
import { CurrencyInput, formatCurrencyAmount, formatCurrencyInput } from './design-system/currency-input';
import { CardPurchaseDialog } from './maybe-ui/card-purchase-dialog';
import { MaybeDialog } from './maybe-ui/dialog';
import { MaybeButton } from './maybe-ui/primitives';
import { CardsGrid,InvoiceList,CardModal,PaymentModal,EditModal } from './maybe-ui/card-views';
import { invoicePaymentSummary } from './invoice-payments';
import { isRecurrenceActiveInMonth, occurrencesForRuleMonth } from './recurrence-domain';
import { activeReferenceNames, defaultCategories, importedCategoryReferences, normalizeReferenceName, resolveReferences, StoredReference } from './reference-data';
import { saveCategoryOption, saveSubcategoryOption } from './reference-data-actions';

type Card = { id: string; name: string; holder: string; limit: number; limitCents?: number; closingDay: number; dueDay: number; accountId?: string; availableFromBank?: number | null; usedFromBank?: number | null; currentInvoiceFromBank?: number | null; bankCheckedAt?: string; invoiceCheckedAt?: string; active?: boolean; observations?: string; version?: number; archivedAt?: unknown };
type Account = { id: string; name: string; version?: number; archived?: boolean };
type CardTransaction = TransactionView & { subcategory?: string; clientGeneration?: string; version?: number; cardRevision?: number; recurrenceId?: string; occurrenceMonth?: string; cancelled?: boolean };
type Recurrence = { id: string; description: string; amount: number; kind: 'income' | 'expense'; category?: string; subcategory?: string; owner?: string; startDate: string; endDate?: string; frequency?: string; monthsOfYear?: number[]; active?: boolean; cardId?: string; accountId?: string };
type Payment = { id: string; cardId: string; competence: string; accountId: string; paymentDate: string; amount: number; balanceImpact?: boolean; reversed?: boolean; status?: string; scheduledFor?: string };
type BudgetRow = { id: string; name?: string; categoryName?: string; subcategoria?: string; subcategory?: string };

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' });
const cardPaymentFailure = (error: unknown) => {
  const value = error && typeof error === 'object' ? error as { code?: unknown; details?: unknown; customData?: { reason?: unknown } } : {};
  const code = String(value.code || '').replace(/^functions\//, '');
  const details = value.details && typeof value.details === 'object' ? value.details as { reason?: unknown } : {};
  const reason = String(details.reason || value.customData?.reason || code || 'desconhecido');
  const messages: Record<string, string> = {
    'already-exists': 'Esta fatura já tem uma liquidação registrada. Atualize a tela e confira o histórico.',
    'failed-precondition': 'A liquidação foi recusada por uma condição da fatura, da conta ou da data.',
    'invalid-argument': 'Os dados enviados para liquidar a fatura são inválidos. Confira a data e a competência.',
    'not-found': 'A conta, o cartão ou a fatura não foi encontrado. Atualize a tela e tente novamente.',
    'permission-denied': 'Sua conta não tem permissão para liquidar esta fatura.',
    'resource-exhausted': 'Muitas tentativas em sequência. Aguarde um pouco e tente novamente.',
    'unauthenticated': 'Sua sessão expirou. Entre novamente para liquidar a fatura.',
    aborted: 'A conta foi atualizada ao mesmo tempo. Atualize a tela e tente novamente.',
    internal: 'O serviço encontrou um erro interno ao liquidar a fatura.',
    unavailable: 'O serviço de liquidação está temporariamente indisponível.',
  };
  return `${messages[reason] || 'Não foi possível liquidar a fatura.'} (motivo: ${reason})`;
};
const cardPurchaseFailure = (error: unknown) => { const e=error && typeof error==='object'?error as {code?:unknown;details?:{reason?:unknown}}:{}; const reason=String(e.details?.reason||e.code||'').replace(/^functions\//,''); return reason==='failed-precondition' ? 'Compra não alterada: confira pagamentos, agendamentos e dados da fatura.' : reason==='permission-denied' ? 'Sua conta não tem permissão para alterar compras.' : 'Não foi possível salvar a compra. Atualize a tela e confira os dados.'; };
const parseAmount = (value: unknown) => { const raw = String(value || '').replace(/[^0-9,.-]/g, ''); const normalized = raw.includes(',') ? raw.replace(/\./g, '').replace(',', '.') : raw; return Number(normalized) || 0; };
const createdAfterBankCheck = (createdAt: TransactionView['createdAt'], bankCheckedAt?: string) => {
  if (!bankCheckedAt || !createdAt) return true;
  const milliseconds = typeof createdAt === 'string'
    ? Date.parse(createdAt)
    : createdAt.toMillis?.() || Number(createdAt.seconds || 0) * 1000;
  if (!milliseconds) return true;
  const createdDate = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo' }).format(new Date(milliseconds));
  return createdDate > bankCheckedAt;
};
const addMonths = (iso: string, count: number) => { const [year, month, day] = iso.split('-').map(Number); const date = new Date(year, month - 1 + count, 1); const last = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate(); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(Math.min(day, last)).padStart(2, '0')}`; };
const nextDueDate = (card: Card) => { const base = new Date(`${today()}T12:00:00`); const monthOffset = base.getDate() > card.dueDay ? 1 : 0; const date = new Date(base.getFullYear(), base.getMonth() + monthOffset, 1); const last = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate(); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(Math.min(card.dueDay || 1, last)).padStart(2, '0')}`; };
const formatDate = (date: string) => new Date(`${date}T12:00:00`).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
const formatCompetence = (month: string) => new Date(`${month}-01T12:00:00`).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
const dueDateForCompetence = (month: string, dueDay: number) => {
  const [year, monthNumber] = month.split('-').map(Number);
  const lastDay = new Date(year, monthNumber, 0).getDate();
  return `${month}-${String(Math.min(Math.max(1, dueDay || 1), lastDay)).padStart(2, '0')}`;
};


export function CardsScreen({ budgetRows = [] }: { budgetRows?: BudgetRow[] }) {
  const [cards, setCards] = useState<Card[]>([]); const [accounts, setAccounts] = useState<Account[]>([]); const [transactions, setTransactions] = useState<CardTransaction[]>([]); const [recurrences, setRecurrences] = useState<Recurrence[]>([]); const [payments, setPayments] = useState<Payment[]>([]); const [savedCategories, setSavedCategories] = useState<StoredReference[]>([]);
  const [modal, setModal] = useState<'card' | 'purchase' | 'payment' | 'edit' | null>(null); const [selected, setSelected] = useState<Card | null>(null); const [editing, setEditing] = useState<CardTransaction | null>(null); const [competence, setCompetence] = useState(today().slice(0, 7)); const [saving, setSaving] = useState(false); const [message, setMessage] = useState('');
  const purchaseSavingRef = useRef(false); const purchaseAttemptRef = useRef<{signature:string;key:string}|null>(null);
  const [confirmation, setConfirmation] = useState<{ title: string; description: string; confirmLabel: string; cancelLabel?: string; onConfirm: () => Promise<void> } | null>(null);

  useEffect(() => {
    if (!firestore) return;
    const root = ['households', 'family-wallet'] as const;
    const stopCards = onSnapshot(collection(firestore, ...root, 'cards'), (snapshot) => { const next = snapshot.docs.map((entry) => { const data=entry.data(); return { id: entry.id, ...(data as Omit<Card, 'id'>), limit:Number(data.limitCents)/100||Number(data.limit)||0, availableFromBank:data.availableFromBankCents===null?null:Number(data.availableFromBankCents)/100||Number(data.availableFromBank)||null, usedFromBank:data.usedFromBankCents===null?null:Number(data.usedFromBankCents)/100||Number(data.usedFromBank)||null, currentInvoiceFromBank:data.currentInvoiceFromBankCents===null?null:Number(data.currentInvoiceFromBankCents)/100||Number(data.currentInvoiceFromBank)||null, version:Number(data.version)||undefined, archivedAt:data.archivedAt }; }); setCards(next.filter(card=>!card.archivedAt)); });
    const stopAccounts = onSnapshot(collection(firestore, ...root, 'accounts'), (snapshot) => setAccounts(snapshot.docs.map((entry) => accountFromDoc(entry.id,entry.data()))));
    const stopTransactions = onSnapshot(collection(firestore, ...root, 'transactions'), (snapshot) => setTransactions(snapshot.docs.map((entry) => ({
      id: entry.id, description: String(entry.data().description || ''), amount: entry.data().amountCents != null ? Number(entry.data().amountCents) / 100 : Number(entry.data().amount ?? NaN), kind: entry.data().kind === 'income' || entry.data().type === 'income' ? 'income' : 'expense', status: entry.data().status === 'realized' ? 'realized' : 'planned', rawDate: String(entry.data().transactionDate || entry.data().competenceDate || entry.data().dueDate || ''), purchaseDate: String(entry.data().purchaseDate || ''), paidAt: String(entry.data().paidAt || entry.data().settlementDate || ''), category: String(entry.data().category || 'Sem categoria'), subcategory: String(entry.data().subcategory || entry.data().subcategoria || ''), owner: String(entry.data().owner || 'Família'), cardId: String(entry.data().cardId || ''), accountId: String(entry.data().accountId || ''), recurrenceId: String(entry.data().recurrenceId || '') || undefined, occurrenceMonth: String(entry.data().occurrenceMonth || '') || undefined, archived: Boolean(entry.data().archivedAt != null || entry.data().archived), cancelled: entry.data().status === 'cancelled' || entry.data().deletedAt != null, installmentNumber: Number(entry.data().installmentNumber || 0) || undefined, installmentCount: Number(entry.data().installmentCount || 0) || undefined, installmentGroupId: String(entry.data().installmentGroupId || ''), clientGeneration: String(entry.data().clientGeneration || '') || undefined, version: Number(entry.data().version) || undefined, cardRevision: Number(entry.data().cardRevision) || 0, createdAt: entry.data().createdAt,
    }))));
    const stopPayments = onSnapshot(collection(firestore, ...root, 'cardPayments'), (snapshot) => setPayments(snapshot.docs.map((entry) => ({ id: entry.id, ...(entry.data() as Omit<Payment, 'id'>), reversed: entry.data().reversedAt != null || entry.data().status === 'reversed', amount:entry.data().amountCents != null ? Number(entry.data().amountCents)/100 : Number(entry.data().amount ?? NaN) }))));
    const stopRecurrences = onSnapshot(collection(firestore, ...root, 'recurrences'), (snapshot) => setRecurrences(snapshot.docs.map((entry) => ({ id: entry.id, ...(entry.data() as Omit<Recurrence, 'id'>) }))));
    const stopCategories = onSnapshot(collection(firestore, ...root, 'categories'), (snapshot) => setSavedCategories(snapshot.docs.map((entry) => ({ id: entry.id, ...(entry.data() as Omit<StoredReference, 'id'>) }))));
    return () => { stopCards(); stopAccounts(); stopTransactions(); stopPayments(); stopRecurrences(); stopCategories(); };
  }, []);

  const [invoiceFocus,setInvoiceFocus]=useState<{cardId:string;month:string;sequence:number}>();
  const current = today().slice(0, 7);
  const recurringCardTransactions = (month: string): CardTransaction[] => recurrences.flatMap((item) => {
    if (!item.cardId || !isRecurrenceActiveInMonth(item, month)) return [];
    return occurrencesForRuleMonth(item,month).filter(occurrence=>!transactions.some(transaction=>!transaction.archived&&!transaction.cancelled&&transaction.recurrenceId===item.id&&transaction.occurrenceMonth===occurrence.occurrenceKey)).map(occurrence=>({id:occurrence.id,description:occurrence.description,amount:occurrence.amount,kind:occurrence.kind,status:'planned' as const,rawDate:occurrence.date,purchaseDate:occurrence.date,category:occurrence.category||'Sem categoria',owner:occurrence.owner||'Família',cardId:item.cardId,accountId:item.accountId||'',recurrenceId:item.id,occurrenceMonth:occurrence.occurrenceKey}));
  });
  const invoiceTransactions = (month: string) => [...transactions, ...recurringCardTransactions(month)];
  const invoiceTotal = (cardId: string, month: string) => invoiceTransactions(month).filter((item) => !item.archived && !item.cancelled && item.cardId === cardId && item.rawDate.startsWith(month)).reduce((sum, item) => sum + (item.kind === 'income' ? -item.amount : item.amount), 0);
  const invoiceAmount = (cardId: string, month: string) => {
    const calculated = invoiceTotal(cardId, month);
    const card = cards.find((item) => item.id === cardId);
    const bankSnapshot = Number(card?.currentInvoiceFromBank || 0);
    return calculated > 0 || month !== current || !bankSnapshot ? calculated : bankSnapshot;
  };
  const categoryOptions = activeReferenceNames(resolveReferences(defaultCategories, [...savedCategories, ...importedCategoryReferences(budgetRows)]));
  const viewInvoices = () => document.getElementById('card-invoices')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  const openInvoices = useMemo(() => new Map(cards.map((card) => {
    const months = new Set(transactions
      .filter((item) => item.cardId === card.id && !item.archived && !item.cancelled && /^\d{4}-\d{2}-\d{2}$/.test(item.rawDate))
      .map((item) => item.rawDate.slice(0, 7)));
    for (let offset = 0; offset <= 12; offset += 1) months.add(addMonths(`${current}-01`, offset).slice(0, 7));
    const invoice = [...months].sort().map((month) => {
      const amount = invoiceAmount(card.id, month);
      const summary = invoicePaymentSummary(payments,card.id,month,amount);
      const total = summary.outstanding; const paid = summary.fullyPaid;
      return { month, total, paid, dueDate: dueDateForCompetence(month, card.dueDay) };
    }).find((item) => !item.paid && item.total > 0) || null;
    return [card.id, invoice] as const;
  })), [cards, current, payments, transactions, recurrences]);
  const availableCredit = (card: Card) => {
    const limit = Number(card.limit) || 0;
    const hasBankSnapshot = Boolean(card.bankCheckedAt) && card.availableFromBank != null && Number.isFinite(Number(card.availableFromBank));
    const baseAvailable = hasBankSnapshot ? Number(card.availableFromBank) : limit - (Number(card.usedFromBank) || 0);
    const sinceCheck = transactions.filter((item) => item.cardId === card.id && !item.archived && !item.cancelled && createdAfterBankCheck(item.createdAt, card.bankCheckedAt));
    const months = new Set(sinceCheck.map(item=>item.rawDate.slice(0,7)));
    const outstandingSinceCheck = [...months].reduce((sum,month)=>{
      const total=sinceCheck.filter(item=>item.rawDate.startsWith(month)).reduce((value,item)=>value+(item.kind==='income'?-item.amount:item.amount),0);
      // A bank snapshot may already include earlier payments; do not attribute them to later purchases.
      return sum + (hasBankSnapshot ? Math.max(0,total) : invoicePaymentSummary(payments,card.id,month,total).outstanding);
    },0);
    return Math.min(limit, baseAvailable - outstandingSinceCheck);
  };

  async function saveCard(event: FormEvent<HTMLFormElement>) { event.preventDefault(); if (!firestore) return; const form = new FormData(event.currentTarget); const data = { name: String(form.get('name')).trim(), holder: String(form.get('holder')), limit: parseAmount(form.get('limit')), closingDay: Number(form.get('closingDay')) || 0, dueDay: Number(form.get('dueDay')) || 0, accountId: String(form.get('accountId') || ''), availableFromBank: parseAmount(form.get('availableFromBank')), usedFromBank: parseAmount(form.get('usedFromBank')), currentInvoiceFromBank: parseAmount(form.get('currentInvoiceFromBank')), bankCheckedAt: String(form.get('bankCheckedAt') || ''), invoiceCheckedAt: String(form.get('invoiceCheckedAt') || ''), observations: String(form.get('observations') || '').trim(), updatedAt: serverTimestamp() }; if (data.limit <= 0) { setMessage('Informe um limite válido.'); return; } setSaving(true); try { if (selected) await updateDoc(doc(firestore, 'households', 'family-wallet', 'cards', selected.id), data); else await addDoc(collection(firestore, 'households', 'family-wallet', 'cards'), { ...data, createdAt: serverTimestamp() }); setModal(null); setSelected(null); setMessage('Cartão salvo.'); } catch { setMessage('Não foi possível salvar o cartão.'); } finally { setSaving(false); } }
  function removeCard(card: Card) { if (!firestore) return; setConfirmation({ title: `Excluir ${card.name}?`, description: 'As compras e faturas já registradas serão preservadas.', confirmLabel: 'Excluir cartão', onConfirm: async () => { setSaving(true); try { await deleteDoc(doc(firestore!, 'households', 'family-wallet', 'cards', card.id)); setMessage('Cartão excluído.'); setConfirmation(null); } catch { setMessage('Não foi possível excluir o cartão.'); } finally { setSaving(false); } } }); }
  async function savePurchase(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();if(!firestore||!selected||purchaseSavingRef.current)return;const form=new FormData(event.currentTarget),count=Math.max(1,Math.min(120,Number(form.get('count'))||1)),kind=String(form.get('kind'))==='income'?'income':'expense';
    const values={cardId:selected.id,accountId:selected.accountId||'',description:String(form.get('description')||'').trim(),category:String(form.get('category')||''),subcategory:String(form.get('subcategory')||''),owner:String(form.get('owner')||''),amountCents:Math.round(parseAmount(form.get('amount'))*100),kind,status:String(form.get('status')||'planned'),purchaseDate:String(form.get('purchaseDate')||today()),invoiceDate:String(form.get('date')||'')};
    const signature=JSON.stringify({values,count});if(purchaseAttemptRef.current?.signature!==signature)purchaseAttemptRef.current={signature,key:newIdempotencyKey('card-purchase')};purchaseSavingRef.current=true;setSaving(true);try{await callWalletCommand('manageCardPurchase',{householdId:'family-wallet',idempotencyKey:purchaseAttemptRef.current.key,action:'create',payload:{values,count}});purchaseAttemptRef.current=null;setModal(null);setSelected(null);setMessage(kind==='income'?'Estorno vinculado ao cartão.':count>1?`${count} parcelas vinculadas ao cartão.`:'Compra vinculada ao cartão.');}catch(error){setMessage(cardPurchaseFailure(error));}finally{purchaseSavingRef.current=false;setSaving(false);}
  }
  async function savePayment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!firestore || !selected) return;
    const form=new FormData(event.currentTarget), accountId=String(form.get('accountId')||''), account=accounts.find(item=>item.id===accountId);
    const paymentDate=String(form.get('paymentDate')||''), mode=String(form.get('mode')), amountCents=Math.round(parseAmount(form.get('amount'))*100);
    const summary=invoicePaymentSummary(payments,selected.id,competence,invoiceAmount(selected.id,competence));
    if(!account || account.archived || !paymentDate || amountCents<=0 || amountCents>Math.round(summary.available*100)) {setMessage('Confira a conta e o valor disponível para pagamento ou agendamento.');return;}
    setSaving(true); try { if(!commandBackendEnabled)throw new Error('backend-required'); await callWalletCommand('managePartialCardPayment',{householdId:'family-wallet',idempotencyKey:newIdempotencyKey('card-payment'),action:'create',payload:{cardId:selected.id,accountId,competence,amountCents,paymentDate,mode,expectedAccountVersion:account.version??null}}); setMessage(mode==='scheduled'?'Pagamento agendado. Confirme a baixa quando ele acontecer.':'Pagamento registrado sem duplicar a despesa.');setModal(null);setSelected(null); } catch(error){setMessage(cardPaymentFailure(error));} finally{setSaving(false);}
  }
  function reversePayment(card:Card,payment:Payment) {
    const account=accounts.find(item=>item.id===payment.accountId);if(!account){setMessage('Não foi possível localizar a conta usada no pagamento.');return;}
    const balanceNote=payment.balanceImpact===false?'O saldo não será alterado, pois o pagamento é histórico.':'O valor voltará para a conta usada.';
    setConfirmation({title:`Estornar pagamento · ${card.name}`,description:`${money.format(payment.amount)} · competência ${payment.competence}. ${balanceNote}`,confirmLabel:'Estornar pagamento',onConfirm:async()=>{setSaving(true);try{await callWalletCommand('reverseCardPayment',{householdId:'family-wallet',idempotencyKey:newIdempotencyKey('card-payment-reversal'),payload:{paymentId:payment.id,expectedAccountVersion:account.version??null}});setMessage('Pagamento estornado.');setConfirmation(null);}catch(error){setMessage(cardPaymentFailure(error));}finally{setSaving(false);}}});
  }
  function handleSchedule(payment:Payment,action:'settle'|'cancel') {
    const account=accounts.find(item=>item.id===payment.accountId);
    if(action==='settle'&&!account){setMessage('Não foi possível localizar a conta do agendamento.');return;}
    setConfirmation({title:action==='settle'?'Confirmar pagamento agendado?':'Cancelar agendamento?',description:action==='settle'?`Registre a baixa de ${money.format(payment.amount)} na data de hoje. O saldo será atualizado quando aplicável.`:`O agendamento de ${money.format(payment.amount)} será cancelado sem movimentar a conta.`,confirmLabel:action==='settle'?'Confirmar pagamento':'Cancelar agendamento',onConfirm:async()=>{setSaving(true);try{await callWalletCommand('managePartialCardPayment',{householdId:'family-wallet',idempotencyKey:newIdempotencyKey('card-payment'),action,payload:action==='settle'?{paymentId:payment.id,paymentDate:today(),expectedAccountVersion:account?.version??null}:{paymentId:payment.id}});setMessage(action==='settle'?'Pagamento confirmado.':'Agendamento cancelado.');setConfirmation(null);}catch(error){setMessage(cardPaymentFailure(error));}finally{setSaving(false);}}});
  }
  function removeTransaction(item: CardTransaction) { if (item.recurrenceId) { setMessage('Esta linha é gerada pela recorrência. Edite a recorrência para alterar as próximas faturas.'); return; } if (!firestore) return; if (item.installmentGroupId && (item.installmentCount || 0) > 1) { if (!commandBackendEnabled || !item.cardId) { setMessage('O cancelamento seguro exige o serviço de comandos.'); return; } setConfirmation({ title: 'Cancelar compra parcelada?', description: 'Todas as parcelas serão canceladas e o histórico será preservado. Pagamentos nos ciclos impedem o cancelamento.', cancelLabel: 'Manter compra', confirmLabel: 'Cancelar compra', onConfirm: async () => { setSaving(true); try { await callWalletCommand('cancelCardInstallments', { householdId: 'family-wallet', idempotencyKey: newIdempotencyKey('cancel-installments'), payload: { cardId: item.cardId, groupId: item.installmentGroupId } }); setMessage('Compra e parcelas canceladas; histórico preservado.'); setConfirmation(null); } catch { setMessage('Não foi possível cancelar. Verifique os pagamentos e a integridade das parcelas.'); } finally { setSaving(false); } } }); return; } setConfirmation({ title: 'Arquivar lançamento da fatura?', description: `“${item.description}” será removido da lista ativa e seu histórico será preservado.`, confirmLabel: 'Arquivar lançamento', onConfirm: async () => { setSaving(true); try { await callWalletCommand('manageCardPurchase',{householdId:'family-wallet',idempotencyKey:newIdempotencyKey('card-purchase-archive'),action:'archive',payload:{transactionId:item.id,expectedRevision:item.cardRevision??0}});setMessage('Lançamento arquivado. O histórico foi preservado.');setConfirmation(null); } catch(error) { setMessage(cardPurchaseFailure(error)); } finally { setSaving(false); } } }); }

  async function editTransaction(event: FormEvent<HTMLFormElement>) {event.preventDefault();if(!firestore||!editing||!editing.cardId)return;const form=new FormData(event.currentTarget);const values={cardId:editing.cardId,accountId:editing.accountId||'',description:String(form.get('description')||'').trim(),category:String(form.get('category')||editing.category),subcategory:String(form.get('subcategory')||''),owner:editing.owner||'Família',amountCents:Math.round(parseAmount(form.get('amount'))*100),kind:String(form.get('kind'))==='income'?'income':'expense',purchaseDate:String(form.get('purchaseDate')||editing.purchaseDate||editing.rawDate),invoiceDate:String(form.get('date')||''),status:String(form.get('status')||'planned')};setSaving(true);try{await callWalletCommand('manageCardPurchase',{householdId:'family-wallet',idempotencyKey:newIdempotencyKey('card-purchase-update'),action:'update',payload:{transactionId:editing.id,expectedRevision:editing.cardRevision??0,values}});setModal(null);setEditing(null);setMessage('Lançamento atualizado.');}catch(error){setMessage(cardPurchaseFailure(error));}finally{setSaving(false);}}


  return <section className="cards-page">
    <header className="cards-page-heading"><span aria-hidden="true" className="cards-page-heading-icon"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="5" width="18" height="14" rx="1"/><path d="M3 9h18M7 15h4"/></svg></span><div><p className="eyebrow">CRÉDITO EM FAMÍLIA</p><h2>Cartões</h2><p>Acompanhe limites, faturas e compras da família.</p></div><span className="cards-count">{cards.length} {cards.length === 1 ? 'cartão' : 'cartões'}</span><button className="primary-button" type="button" onClick={() => { setSelected(null); setModal('card'); }}>+ <span>Adicionar cartão</span></button></header>
    {message && <p className="form-help cards-message" role="status">{message}</p>}
    <CardsGrid cards={cards} availableCredit={availableCredit} openInvoices={openInvoices} onViewInvoices={card=>{setInvoiceFocus(previous=>({cardId:card.id,month:openInvoices.get(card.id)?.month||current,sequence:(previous?.sequence||0)+1}));viewInvoices();}} onPurchase={card=>{setSelected(card);setModal('purchase')}} onPay={(card,month)=>{setMessage('');setSelected(card);setCompetence(month);setModal('payment')}} onEdit={card=>{setSelected(card);setModal('card')}} onRemove={removeCard}/>

    <InvoiceList focusInvoice={invoiceFocus} cards={cards} accounts={accounts} transactions={transactions} transactionForMonth={invoiceTransactions} payments={payments} onReverse={reversePayment} onSchedule={handleSchedule} onEdit={(item) => { if (item.installmentGroupId && (item.installmentCount || 0) > 1) { setMessage('Parcelas não podem ser alteradas individualmente.'); return; } const paid = payments.some((payment) => !payment.reversed && payment.status !== 'reversed' && payment.status !== 'cancelled' && payment.cardId === item.cardId && payment.competence === item.rawDate.slice(0, 7)); if (paid) { setMessage('Estorne a liquidação da fatura antes de alterar este lançamento.'); return; } setEditing(item); setModal('edit'); }} onPay={(card, month) => { setMessage(''); setSelected(card); setCompetence(month); setModal('payment'); }} onRemove={removeTransaction} />
    {modal === 'card' && <CardModal card={selected} accounts={accounts} saving={saving} onClose={() => setModal(null)} onSubmit={saveCard} />}
    {modal === 'purchase' && selected && <CardPurchaseDialog onCreateCategory={async name => (await saveCategoryOption(name, firebaseAuth?.currentUser?.uid || '')).name} onCreateSubcategory={async (category,name) => saveSubcategoryOption(category,name,firebaseAuth?.currentUser?.uid || '')} card={selected} budgetRows={budgetRows} categoryOptions={categoryOptions} saving={saving} onClose={() => setModal(null)} onSubmit={savePurchase} />}
    {modal === 'payment' && selected && <PaymentModal card={selected} accounts={accounts} competence={competence} total={invoicePaymentSummary(payments,selected.id,competence,invoiceAmount(selected.id,competence)).available} saving={saving} message={message} onClose={() => setModal(null)} onSubmit={savePayment} />}
    {modal === 'edit' && editing && <EditModal onCreateCategory={async name=>(await saveCategoryOption(name,firebaseAuth?.currentUser?.uid||'')).name} onCreateSubcategory={async(category,name)=>saveSubcategoryOption(category,name,firebaseAuth?.currentUser?.uid||'')} key={editing.id} transaction={editing} budgetRows={budgetRows} categoryOptions={categoryOptions} saving={saving} onClose={() => setModal(null)} onSubmit={editTransaction} />}
    {confirmation && <MaybeDialog className="card-confirmation-dialog" title={confirmation.title} onClose={() => !saving && setConfirmation(null)} footer={<div className="card-confirmation-actions"><MaybeButton variant="outline" disabled={saving} onClick={() => setConfirmation(null)}>{confirmation.cancelLabel || 'Cancelar'}</MaybeButton><MaybeButton variant="danger" disabled={saving} onClick={() => void confirmation.onConfirm()}>{saving ? 'Aguarde…' : confirmation.confirmLabel}</MaybeButton></div>}><p className="card-confirmation-copy">{confirmation.description}</p></MaybeDialog>}
  </section>;
}

function Modal({title,children,onClose}:{title:string;children:React.ReactNode;onClose:()=>void}){return <MaybeDialog title={title} onClose={onClose}>{children}</MaybeDialog>;}
