'use client';
import {RecordRow} from './maybe-ui/record-row';

import { useEffect, useMemo, useState } from 'react';
import { MaybeDialog } from './maybe-ui/dialog';
import { MaybeButton, MaybeField } from './maybe-ui/primitives';
import {buildReportCsv,reportRangeValid} from './report-export';
import { persistFilterState, readFilterState } from './filter-state';
import { FilterContextActions } from './filter-context-actions';
import { dateBasisDescription, dateBasisLabel, isDateInRange, matchesSearch, sortTransactions, TransactionSort, TransactionView } from './transaction-model';
import { moneyTone } from './design-system/money-tone';

type Account = { id: string; name: string };
type ReportTransaction = TransactionView & {cancelled?:boolean};

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const signedMoney = (value: number) => `${value > 0 ? '+' : value < 0 ? '−' : ''}${money.format(Math.abs(value))}`;
const formatDate = (value: string) => new Date(`${value}T12:00:00`).toLocaleDateString('pt-BR');
const formatMonth = (value: string) => new Date(`${value}-01T12:00:00`).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
const formatGeneratedAt = () => new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short', timeZone: 'America/Sao_Paulo' }).format(new Date());

export function ReportsScreen({ transactions, accounts, start, end, setStart, setEnd, onEdit, readOnly = false }: {
  readOnly?: boolean;
  transactions: ReportTransaction[];
  accounts: Account[];
  start: string;
  end: string;
  setStart: (value: string) => void;
  setEnd: (value: string) => void;
  onEdit: (item: ReportTransaction) => void;
}) {
  const [detail,setDetail]=useState<ReportTransaction|null>(null);
  const [includeAnalysis, setIncludeAnalysis] = useState(false);
  const [status, setStatus] = useState<'all' | 'realized' | 'planned'>('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<TransactionSort>('date-desc');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [ownerFilter, setOwnerFilter] = useState('all');
  const [filtersReady, setFiltersReady] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);

  useEffect(() => { const saved = readFilterState('reports', { start, end, includeAnalysis: false, status: 'all', search: '', sort: 'date-desc', categoryFilter: 'all', ownerFilter: 'all' }); setStart(String(saved.start)); setEnd(String(saved.end)); setIncludeAnalysis(Boolean(saved.includeAnalysis)); setStatus(saved.status as typeof status); setSearch(String(saved.search)); setSort(saved.sort as TransactionSort); setCategoryFilter(String(saved.categoryFilter)); setOwnerFilter(String(saved.ownerFilter)); setFiltersReady(true); }, []);
  useEffect(() => { if (filtersReady) persistFilterState('reports', { start, end, includeAnalysis, status, search, sort, categoryFilter, ownerFilter }); }, [categoryFilter, end, filtersReady, includeAnalysis, ownerFilter, search, sort, start, status]);

  const resetFilters = () => { setStart(`${new Date().getFullYear()}-01-01`); setEnd(new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' })); setStatus('all'); setSearch(''); setSort('date-desc'); setCategoryFilter('all'); setOwnerFilter('all'); };
  const activeFilterCount = [start !== `${new Date().getFullYear()}-01-01`, end !== new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' }), status !== 'all', Boolean(search), sort !== 'date-desc', categoryFilter !== 'all', ownerFilter !== 'all'].filter(Boolean).length;
  const availableCategories = useMemo(() => [...new Set(transactions.map((item) => item.category).filter(Boolean))].sort(), [transactions]);
  const availableOwners = useMemo(() => [...new Set(transactions.map((item) => item.owner).filter(Boolean))].sort(), [transactions]);
  const visible = useMemo(() => sortTransactions(transactions.filter((item) => !item.archived && !item.cancelled && reportRangeValid(start,end) &&
    isDateInRange(item, 'competence', start, end) &&
    (status === 'all' || item.status === status) &&
    (categoryFilter === 'all' || item.category === categoryFilter) &&
    (ownerFilter === 'all' || item.owner === ownerFilter) && matchesSearch(item, search)
  ), sort), [categoryFilter, end, ownerFilter, search, sort, start, status, transactions]);

  const totals = useMemo(() => visible.reduce((result, item) => {
    if (item.kind === 'income') result.income += item.amount; else result.expense += item.amount;
    return result;
  }, { income: 0, expense: 0 }), [visible]);

  const expenseBreakdown = useMemo(() => {
    const categoryTotals = new Map<string, number>(); const ownerTotals = new Map<string, number>();
    visible.forEach((item) => { if (item.kind !== 'expense') return; categoryTotals.set(item.category, (categoryTotals.get(item.category) || 0) + item.amount); ownerTotals.set(item.owner, (ownerTotals.get(item.owner) || 0) + item.amount); });
    const rows = (totals: Map<string, number>, key: 'category' | 'owner') => [...totals.entries()].map(([name, total]) => ({ [key]: name, total })).sort((left, right) => right.total - left.total);
    return { categories: rows(categoryTotals, 'category') as Array<{ category: string; total: number }>, owners: rows(ownerTotals, 'owner') as Array<{ owner: string; total: number }> };
  }, [visible]);
  const categories = expenseBreakdown.categories;
  const owners = expenseBreakdown.owners;
  const dailyRows = useMemo(() => {
    const first = new Date(`${start}T12:00:00`); const last = new Date(`${end}T12:00:00`);
    if (Number.isNaN(first.valueOf()) || Number.isNaN(last.valueOf()) || first > last) return [];
    const totalsByDay = new Map<string, { income: number; expense: number }>();
    visible.forEach((item) => { const current = totalsByDay.get(item.rawDate) || { income: 0, expense: 0 }; current[item.kind] += item.amount; totalsByDay.set(item.rawDate, current); });
    const rows: Array<{ date: string; income: number; expense: number }> = [];
    for (const cursor = new Date(first); cursor <= last && rows.length < 366; cursor.setDate(cursor.getDate() + 1)) { const date = cursor.toLocaleDateString('en-CA'); const total = totalsByDay.get(date) || { income: 0, expense: 0 }; rows.push({ date, ...total }); }
    return rows;
  }, [end, start, visible]);
  const dailyMaximum = Math.max(1, ...dailyRows.map((item) => Math.max(item.income, item.expense)));
  const dailyActivityRows = dailyRows.filter((item) => item.income > 0 || item.expense > 0);
  const monthlyRows = useMemo(() => {
    const grouped = new Map<string, { income: number; expense: number }>();
    visible.forEach((item) => { const key = item.rawDate.slice(0, 7); const current = grouped.get(key) || { income: 0, expense: 0 }; current[item.kind] += item.amount; grouped.set(key, current); });
    return [...grouped.entries()].sort(([left], [right]) => left.localeCompare(right)).map(([month, totals]) => ({ month, ...totals, balance: totals.income - totals.expense }));
  }, [visible]);

  function exportCsv() {
    if(!reportRangeValid(start,end))return;
    const csv=buildReportCsv(visible,accounts);
    const link = document.createElement('a'); link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); link.download = `wise-wallet-${start}-a-${end}.csv`; link.click(); URL.revokeObjectURL(link.href);
  }

  return <section className="mb-transactions report-export" aria-label="Relatórios"><header className="mb-page-heading"><div className="mb-page-copy"><h2>Relatórios</h2><p className="form-help">De {start?formatDate(start):'data não informada'} até {end?formatDate(end):'data não informada'} · competência/fatura.</p></div><div className="report-export-controls"><MaybeButton aria-haspopup="dialog" onClick={()=>setFiltersOpen(true)}>Filtros{activeFilterCount?` · ${activeFilterCount}`:''}</MaybeButton><MaybeButton variant="primary" disabled={!reportRangeValid(start,end)} onClick={exportCsv}>Exportar CSV</MaybeButton>{!readOnly&&<MaybeButton onClick={()=>window.print()}>Imprimir / PDF</MaybeButton>}</div></header>
    {filtersOpen && <MaybeDialog title="Filtros de relatório" closeLabel="Fechar filtros" onClose={() => setFiltersOpen(false)} footer={<MaybeButton variant="primary" onClick={() => setFiltersOpen(false)}>Ver resultados</MaybeButton>}><div className="mb-filter-grid">
      <MaybeField label="De · competência/fatura"><input type="date" value={start} onChange={(event) => setStart(event.target.value)} /></MaybeField>
      <MaybeField label="Até"><input type="date" value={end} onChange={(event) => setEnd(event.target.value)} /></MaybeField>
      <MaybeField label="Situação"><select value={status} onChange={(event) => setStatus(event.target.value as typeof status)}><option value="all">Realizadas e previstas</option><option value="realized">Somente realizadas</option><option value="planned">Somente previstas</option></select></MaybeField>
      <MaybeField label="Categoria"><select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)}><option value="all">Todas as categorias</option>{availableCategories.map((category) => <option key={category} value={category}>{category}</option>)}</select></MaybeField>
      <MaybeField label="Responsável"><select value={ownerFilter} onChange={(event) => setOwnerFilter(event.target.value)}><option value="all">Todos os responsáveis</option>{availableOwners.map((owner) => <option key={owner} value={owner}>{owner}</option>)}</select></MaybeField>
      <MaybeField label="Ordenar"><select value={sort} onChange={(event) => setSort(event.target.value as TransactionSort)}><option value="date-desc">Mais recentes</option><option value="date-asc">Mais antigas</option><option value="amount-desc">Maior valor</option><option value="amount-asc">Menor valor</option><option value="description-asc">Descrição A–Z</option></select></MaybeField>
      <MaybeField label="Buscar lançamento" className="report-search"><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Nome, categoria ou responsável" /></MaybeField>
      <label className="report-analysis-toggle"><input type="checkbox" checked={includeAnalysis} onChange={(event) => setIncludeAnalysis(event.target.checked)} /><span>{readOnly ? 'Exibir análise detalhada' : 'Incluir análise no PDF'}</span></label>
      <MaybeButton variant="ghost" className="reset-filters" type="button" onClick={resetFilters}>Limpar filtros</MaybeButton>
    </div>
      <p className="filter-help"><strong>{dateBasisLabel('competence')}:</strong> {dateBasisDescription('competence')}</p>
      {!readOnly && <FilterContextActions activeCount={activeFilterCount} />}
    </MaybeDialog>}
 {!reportRangeValid(start,end)&&<p role="alert">Informe um intervalo válido, com a data inicial até a data final.</p>}
 <dl className="mb-summary"><div><dt>Receitas no recorte</dt><dd>{signedMoney(totals.income)}</dd></div><div><dt>Despesas no recorte</dt><dd>{signedMoney(-totals.expense)}</dd></div><div><dt>Diferença no período</dt><dd>{signedMoney(totals.income-totals.expense)}</dd></div></dl><p className="mb-list-note">{visible.length} lançamento(s), incluindo {visible.filter(t=>t.status==='planned').length} previsto(s). Totais por competência; a diferença não é saldo disponível. A exportação contém somente o recorte filtrado, sem adicionar pagamentos de fatura novamente.</p>
 <section className="mb-table-container"><h3>Dias com lançamentos</h3><div className="analysis-month-head" aria-hidden="true"><span>Data</span><span>Receitas</span><span>Despesas</span></div>{dailyActivityRows.map(row=><div className="analysis-month-row" key={row.date}><strong>{formatDate(row.date)}</strong><span><small>Receitas</small>{money.format(row.income)}</span><span><small>Despesas</small>{money.format(row.expense)}</span></div>)}{!dailyActivityRows.length&&<p className="mb-empty">Nenhum dia com lançamentos neste recorte.</p>}{dailyRows.length===366&&<p className="form-help">O detalhamento diário mostra os primeiros 366 dias. O resumo, a lista e o CSV usam todo o intervalo filtrado.</p>}</section>
 <section className="mb-table-container"><h3>Resultado por competência</h3><div className="analysis-month-head" aria-hidden="true"><span>Competência</span><span>Receitas</span><span>Despesas</span></div>{monthlyRows.map(row=><div className="analysis-month-row" key={row.month}><strong className="report-month-label">{formatMonth(row.month)}<span className="form-help">Diferença: {signedMoney(row.balance)}</span></strong><span><small>Receitas</small>{money.format(row.income)}</span><span><small>Despesas</small>{money.format(row.expense)}</span></div>)}{!monthlyRows.length&&<p className="mb-empty">Nenhum mês com lançamentos neste recorte.</p>}</section>
 {includeAnalysis&&<section className="mb-table-container"><h3>Distribuição das despesas</h3>{[{title:'Por categoria',rows:categories.map(c=>({name:c.category,total:c.total}))},{title:'Por responsável',rows:owners.map(o=>({name:o.owner,total:o.total}))}].map(group=><section className="report-distribution" key={group.title}><h4>{group.title}</h4>{group.rows.map(row=><div className="report-distribution-row" key={row.name}><span>{row.name}</span><strong>{money.format(row.total)}</strong></div>)}{!group.rows.length&&<p className="mb-empty">Sem despesas.</p>}</section>)}</section>}
 <section className="mb-table-container"><h3>Lançamentos do período</h3>{visible.map(item=><RecordRow key={item.id} title={item.description} meta={<>{formatDate(item.rawDate)} · {item.category} · {item.status==='planned'?'Prevista':'Realizada'}<br/>{accounts.find(a=>a.id===item.accountId)?.name||'Conta não informada'} · {item.owner}</>} value={signedMoney(item.kind==='income'?item.amount:-item.amount)} onOpen={()=>setDetail(item)} actions={!readOnly?<MaybeButton variant="ghost" onClick={()=>onEdit(item)}>Editar</MaybeButton>:undefined}/>)}{!visible.length&&<p className="mb-empty">Nenhum lançamento corresponde aos filtros.</p>}</section>
 {detail&&<MaybeDialog title="Detalhes do lançamento" onClose={()=>setDetail(null)} footer={<MaybeButton variant="primary" onClick={()=>setDetail(null)}>Voltar ao relatório</MaybeButton>}><div className="transaction-detail"><h4>{detail.description}</h4><strong>{signedMoney(detail.kind==='income'?detail.amount:-detail.amount)}</strong><dl>{[['Competência/fatura',formatDate(detail.rawDate)],['Compra/lançamento',formatDate(detail.purchaseDate||detail.rawDate)],['Categoria',detail.category],['Responsável',detail.owner],['Situação',detail.status==='planned'?'Prevista':'Realizada']].map(([name,value])=><div key={name}><dt>{name}</dt><dd>{value}</dd></div>)}</dl><p className="form-help">O lançamento não comprova quitação individual de parcela nem cobertura integral do histórico.</p></div></MaybeDialog>}
 </section>;
}
