'use client';
import {duplicateTransactions} from './duplicate-transactions';
import {RecordRow} from './maybe-ui/record-row';

import { useEffect, useMemo, useState } from 'react';
import { MaybeDialog } from './maybe-ui/dialog';
import { MaybeButton, MaybeField } from './maybe-ui/primitives';
import { moneyTone } from './design-system/money-tone';
import { persistFilterState, readFilterState } from './filter-state';
import { FilterContextActions } from './filter-context-actions';
import { CustomSavedViews } from './custom-saved-views';
import { FilterState } from './filter-state';
import {
  DateBasis,
  dateBasisDescription,
  dateBasisLabel,
  dateForBasis,
  isPrimaryOccurrence,
  matchesSearch,
  sortTransactions,
  todayIso,
  TransactionSort,
  TransactionView,
} from './transaction-model';
import { TemporalInput } from './design-system/temporal-input';

export type BulkItem = TransactionView & { paidAt?: string; isRecurrenceForecast?:boolean };

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const dateLabel = (value: string) => value
  ? new Date(`${value}T12:00:00`).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })
  : 'Data não informada';

export function BulkTransactions({ items, onBatch, onEdit, userId, accounts = [], cards = [], stateSection = 'transactions', readOnly = false, onInspect }: {
  items: BulkItem[];
  onBatch: (action: 'pay' | 'archive' | 'restore', items: BulkItem[]) => boolean | void | Promise<boolean | void>;
  onEdit: (item: BulkItem) => void;
  onDelete?: (item: BulkItem) => void;
  userId: string;
  accounts?: { id: string; name: string }[];
  cards?: { id: string; name: string }[];
  stateSection?: string;
  readOnly?: boolean;
  onInspect?: (item: BulkItem) => void;
}) {
  const [archive, setArchive] = useState(false);
  const [month, setMonth] = useState(todayIso().slice(0, 7));
  const [search, setSearch] = useState('');
  const [basis, setBasis] = useState<DateBasis>('occurrence');
  const [sort, setSort] = useState<TransactionSort>('date-desc');
  const [kind, setKind] = useState<'all' | 'income' | 'expense'>('all');
  const [status, setStatus] = useState<'all' | 'realized' | 'planned'>('all');
  const [owner, setOwner] = useState('all');
  const [account, setAccount] = useState('all');
  const [filtersReady, setFiltersReady] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [batchBusy,setBatchBusy]=useState(false);
  const [selected, setSelected] = useState<string[]>([]);

  useEffect(() => { const saved = readFilterState(stateSection, { archive: false, month: todayIso().slice(0, 7), search: '', basis: 'occurrence', sort: 'date-desc', kind: 'all', status: 'all', owner: 'all', account: 'all' }); setArchive(Boolean(saved.archive)); setMonth(String(saved.month)); setSearch(String(saved.search)); setBasis(saved.basis as DateBasis); setSort(saved.sort as TransactionSort); setKind(saved.kind as typeof kind); setStatus(saved.status as typeof status); setOwner(String(saved.owner)); setAccount(String(saved.account)); setFiltersReady(true); }, [stateSection]);
  useEffect(() => { if (filtersReady) persistFilterState(stateSection, { archive, month, search, basis, sort, kind, status, owner, account }); }, [archive, basis, filtersReady, kind, month, owner, account, search, sort, status, stateSection]);

  const visible = useMemo(() => {
    const filtered = items.filter((item) => {
      if (Boolean(item.archived) !== archive) return false;
      if (basis === 'occurrence' && !isPrimaryOccurrence(item)) return false;
      if (month !== 'all' && !dateForBasis(item, basis).startsWith(month)) return false;
      if (kind !== 'all' && item.kind !== kind) return false;
      if (status !== 'all' && item.status !== status) return false;
      if (owner !== 'all' && item.owner !== owner) return false;
      if (account !== 'all' && item.accountId !== account) return false;
      return matchesSearch(item, search);
    });
    return sortTransactions(filtered, sort, basis);
  }, [archive, basis, items, kind, month, owner, account, search, sort, status]);

  const duplicates=useMemo(()=>duplicateTransactions(items),[items]);
  const chosen = visible.filter((item) => selected.includes(item.id));
  const selectable = visible.filter(item=>!item.isRecurrenceForecast);
  const all = selectable.length > 0 && selectable.every((item) => selected.includes(item.id));
  const toggle = (id: string) => setSelected((current) =>
    current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  const chooseAll = () => setSelected(all ? [] : selectable.map((item) => item.id));
  const act = async (action: 'pay' | 'archive' | 'restore') => {
    if(batchBusy)return;setBatchBusy(true);
    try{const result=await onBatch(action,chosen);if(result!==false)setSelected([]);}finally{setBatchBusy(false);}
  };
  const resetFilters = () => {
    setMonth(todayIso().slice(0, 7)); setSearch(''); setBasis('occurrence'); setSort('date-desc');
    setKind('all'); setStatus('all'); setOwner('all'); setAccount('all'); setSelected([]);
  };
  const applyPreset = (preset: 'planned' | 'family-expenses') => { setArchive(false); setMonth(todayIso().slice(0, 7)); setSearch(''); setBasis(preset === 'planned' ? 'competence' : 'occurrence'); setSort('date-desc'); setKind(preset === 'family-expenses' ? 'expense' : 'all'); setStatus(preset === 'planned' ? 'planned' : 'all'); setOwner(preset === 'family-expenses' ? 'Família' : 'all'); setAccount('all'); setSelected([]); };
  const applyCustomView = (state: FilterState) => { setArchive(Boolean(state.archive)); setMonth(String(state.month || todayIso().slice(0, 7))); setSearch(String(state.search || '')); setBasis((state.basis || 'occurrence') as DateBasis); setSort((state.sort || 'date-desc') as TransactionSort); setKind((state.kind || 'all') as typeof kind); setStatus((state.status || 'all') as typeof status); setOwner(String(state.owner || 'all')); setAccount(String(state.account || 'all')); setSelected([]); };
  const owners = [...new Set(['Família', 'Pessoa 1', 'Pessoa 2', ...items.map((item) => item.owner)])].sort();
  const activeFilterCount = [archive, month !== todayIso().slice(0, 7), Boolean(search), basis !== 'occurrence', sort !== 'date-desc', kind !== 'all', status !== 'all', owner !== 'all', account !== 'all'].filter(Boolean).length;

  // Port of Maybe transactions/index, _summary and _transaction. Filters and commands remain Wise.
  const listIncome = visible.filter(item => item.kind === 'income').reduce((sum,item)=>sum+Math.round(item.amount*100),0)/100;
  const listExpense = visible.filter(item => item.kind === 'expense').reduce((sum,item)=>sum+Math.round(item.amount*100),0)/100;
  const dateGroups: {date:string;items:BulkItem[]}[] = [];
  for (const item of visible) {
    const date = sort.startsWith('date') ? dateForBasis(item,basis) : '';
    const last = dateGroups[dateGroups.length-1];
    if (last?.date === date) last.items.push(item); else dateGroups.push({date,items:[item]});
  }
  return <section className="mb-transactions" data-source="maybe-transactions">
    <header className="mb-page-heading"><h2>{archive ? 'Arquivo' : 'Transações'}</h2><MaybeButton onClick={() => {setArchive(!archive);setSelected([]);}}>{archive ? 'Ver ativos' : 'Ver arquivo'}</MaybeButton></header>
    <dl className="mb-summary"><div><dt>Lançamentos visíveis</dt><dd>{visible.length}</dd></div><div><dt>Receitas na lista</dt><dd>{money.format(listIncome)}</dd></div><div><dt>Despesas na lista</dt><dd>{money.format(listExpense)}</dd></div></dl>
    <p className="mb-list-note">Totais da lista filtrada, incluindo previsões. Não representam saldo da conta nem quitação de faturas.</p>
    {duplicates.size>0&&<p className="mb-list-note" role="status">Há possíveis duplicatas, inclusive no arquivo. Os registros e totais foram preservados; arquivar não estorna o saldo.</p>}
    <div className="mb-table-container">
    <MaybeButton className="mb-filter-trigger" type="button" aria-expanded={filtersOpen} aria-controls="transaction-filters" onClick={() => setFiltersOpen(true)}>Filtros{activeFilterCount ? ` · ${activeFilterCount}` : ''}</MaybeButton>
    {filtersOpen && <MaybeDialog id="transaction-filters" title="Filtros de transações" closeLabel="Fechar filtros" onClose={() => setFiltersOpen(false)} footer={<MaybeButton variant="primary" onClick={() => setFiltersOpen(false)}>Ver resultados</MaybeButton>}>
    <div className="mb-filter-grid">
      <MaybeField label="Buscar" className="search-field"><input aria-label="Buscar" type="search" value={search}
        onChange={(event) => { setSearch(event.target.value); setSelected([]); }} placeholder="Nome, categoria ou responsável" /></MaybeField>
      <MaybeField label="Mês"><input type="month" value={month === 'all' ? '' : month}
        onChange={(event) => { setMonth(event.target.value || 'all'); setSelected([]); }} /></MaybeField>
      <MaybeField label="Data considerada"><select aria-label="Data considerada" value={basis}
        onChange={(event) => { setBasis(event.target.value as DateBasis); setSelected([]); }}>
        <option value="occurrence">{dateBasisLabel('occurrence')}</option>
        <option value="competence">{dateBasisLabel('competence')}</option>
      </select></MaybeField>
      <MaybeField label="Tipo"><select value={kind} onChange={(event) => { setKind(event.target.value as typeof kind); setSelected([]); }}>
        <option value="all">Entradas e saídas</option><option value="income">Entradas</option><option value="expense">Saídas</option>
      </select></MaybeField>
      <MaybeField label="Situação"><select value={status} onChange={(event) => { setStatus(event.target.value as typeof status); setSelected([]); }}>
        <option value="all">Realizadas e previstas</option><option value="realized">Realizadas</option><option value="planned">Previstas</option>
      </select></MaybeField>
      <MaybeField label="Responsável"><select value={owner} onChange={(event) => { setOwner(event.target.value); setSelected([]); }}><option value="all">Todos responsáveis</option>{owners.map((item) => <option key={item}>{item}</option>)}</select></MaybeField>
      <MaybeField label="Conta"><select aria-label="Conta" value={account} onChange={(event) => { setAccount(event.target.value); setSelected([]); }}><option value="all">Todas as contas</option>{account !== 'all' && !accounts.some((item) => item.id === account) && <option value={account}>Conta indisponível</option>}{accounts.map((item) => <option value={item.id} key={item.id}>{item.name}</option>)}</select></MaybeField>
      <MaybeField label="Ordenar"><select value={sort}
        onChange={(event) => { setSort(event.target.value as TransactionSort); setSelected([]); }}>
        <option value="date-desc">Mais recentes</option><option value="date-asc">Mais antigas</option>
        <option value="amount-desc">Maior valor</option><option value="amount-asc">Menor valor</option>
        <option value="description-asc">Descrição A–Z</option>
      </select></MaybeField>
      <MaybeButton variant="ghost" className="clear-month" type="button"
        onClick={() => { setMonth('all'); setSelected([]); }}>Todos os meses</MaybeButton>
      <MaybeButton variant="ghost" className="reset-filters" type="button" onClick={resetFilters}>Limpar filtros</MaybeButton>
    </div>
      <div className="saved-views"><span>Visões rápidas</span><MaybeButton type="button" onClick={() => applyPreset('planned')}>Previstas do mês</MaybeButton><MaybeButton type="button" onClick={() => applyPreset('family-expenses')}>Despesas da família</MaybeButton></div>
      {!readOnly && <CustomSavedViews userId={userId} section="transactions" current={{ archive, month, search, basis, sort, kind, status, owner, account }} onApply={applyCustomView} />}
      <p className="filter-help"><strong>{dateBasisLabel(basis)}:</strong> {dateBasisDescription(basis)}</p>
      {!readOnly && <FilterContextActions activeCount={activeFilterCount} />}
    </MaybeDialog>}

    <div className="mb-selection-toolbar">{!readOnly && <label><input type="checkbox" checked={all} onChange={chooseAll} disabled={!selectable.length}/> Selecionar todas filtradas</label>}<span>{readOnly ? `${visible.length} resultado(s)` : `${chosen.length} selecionada(s) · ${visible.length} resultado(s)`}</span></div>
    {chosen.length>0 && <div className="mb-selection-actions">{!archive && <><MaybeButton disabled={batchBusy} onClick={()=>void act('pay')}>Marcar como realizado</MaybeButton><MaybeButton disabled={batchBusy} onClick={()=>void act('archive')}>Arquivar</MaybeButton></>}{archive && <MaybeButton disabled={batchBusy} onClick={()=>void act('restore')}>Restaurar</MaybeButton>}</div>}

    <div className="mb-date-groups">{dateGroups.map((group,index)=><section className="mb-date-group" key={`${group.date}-${index}`}><h3>{group.date ? dateLabel(group.date) : 'Lançamentos'}<span>{group.items.length}</span></h3>{group.items.map(item=><RecordRow key={item.id} title={duplicates.has(item.id)?`${item.description} · Possível duplicata (${duplicates.get(item.id)!.length})`:item.description} meta={<>{item.category} · {item.status==='planned'?'Prevista':'Realizada'} · {item.owner}<br/>{cards.find(card=>card.id===item.cardId)?.name||accounts.find(a=>a.id===item.accountId)?.name||'Conta não informada'}{item.installmentCount?` · Parcela ${item.installmentNumber}/${item.installmentCount}`:''}{item.cardId&&basis==='occurrence'?` · Fatura ${dateLabel(item.rawDate)}`:''}{item.isRecurrenceForecast?' · Previsão de recorrência, sem baixa':''}</>} value={<span className={moneyTone(item.kind==='income'?item.amount:-item.amount)}>{item.amount===0?'':item.kind==='expense'?'−':'+'}{money.format(item.amount)}</span>} onOpen={readOnly?onInspect?()=>onInspect(item):undefined:!item.isRecurrenceForecast?()=>onEdit(item):undefined} selection={!readOnly?<input type="checkbox" checked={selected.includes(item.id)} disabled={item.isRecurrenceForecast} onChange={()=>toggle(item.id)} aria-label={`Selecionar ${item.description}`}/>:undefined}/>)}</section>)}</div>
    {!visible.length && <p className="mb-empty">Nenhum lançamento corresponde aos filtros.</p>}
    </div>
  </section>;
}
