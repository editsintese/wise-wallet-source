import {occurrencesForRuleMonth,type RecurrenceRule,type RecurrenceOccurrence} from './recurrence-domain.ts';
export type RegisteredRecurrenceTransaction={id:string;amount:number;status?:string;description?:string;category?:string;kind?:'income'|'expense';accountId?:string;cardId?:string;owner?:string;rawDate?:string;scheduledDate?:string;recurrenceId?:string;occurrenceMonth?:string;recurrencePending?:boolean;archived?:boolean};
export type RecurrenceRow={item:RecurrenceRule;occurrence:RecurrenceOccurrence;registered?:RegisteredRecurrenceTransaction};
/** A recorded commitment survives rule pause/change and represents its original occurrence exactly once. */
export function buildRecurrenceRows(active:RecurrenceRule[],all:RecurrenceRule[],transactions:RegisteredRecurrenceTransaction[],month:string):RecurrenceRow[]{
 const registered:RecurrenceRow[]=transactions.flatMap(transaction=>{
  const item=all.find(rule=>rule.id===transaction.recurrenceId),key=transaction.occurrenceMonth,date=transaction.scheduledDate||transaction.rawDate||'';
  if(!item||!key||item.pendingOccurrenceTransactions?.[key]!==transaction.id||transaction.status!=='planned'||transaction.recurrencePending!==true||transaction.cardId||transaction.archived||!Number.isFinite(transaction.amount)||transaction.amount<=0||date.slice(0,7)!==month)return [];
  return [{item,registered:transaction,occurrence:{id:`registered-${transaction.id}`,recurrenceId:item.id,month,occurrenceKey:key,date,amount:transaction.amount,kind:transaction.kind||item.kind,status:'planned',accountId:transaction.accountId,description:transaction.description||item.description,category:transaction.category,owner:transaction.owner}}];
 });
 const keys=new Set(registered.map(row=>`${row.item.id}|${row.occurrence.occurrenceKey}`));
 const projected:RecurrenceRow[]=active.flatMap(item=>occurrencesForRuleMonth(item,month).filter(occurrence=>!keys.has(`${item.id}|${occurrence.occurrenceKey}`)).map(occurrence=>({item,occurrence})));
 return [...projected,...registered].sort((a,b)=>a.occurrence.date.localeCompare(b.occurrence.date)||a.occurrence.description.localeCompare(b.occurrence.description,'pt-BR'));
}

/** Use the recorded commitment's values in the payment dialog, not a subsequently edited rule. */
export function resolveRegisteredOccurrence(rule:RecurrenceRule,key:string,transactions:RegisteredRecurrenceTransaction[]):RecurrenceRule|null{
 const id=rule.pendingOccurrenceTransactions?.[key];if(!id)return rule;
 const entry=transactions.find(transaction=>transaction.id===id&&transaction.recurrenceId===rule.id&&transaction.occurrenceMonth===key&&transaction.status==='planned'&&transaction.recurrencePending===true);
 if(!entry||!Number.isFinite(entry.amount)||entry.amount<=0)return null;
 return {...rule,description:entry.description||rule.description,amount:entry.amount,kind:entry.kind||rule.kind,accountId:entry.accountId,category:entry.category,owner:entry.owner};
}
