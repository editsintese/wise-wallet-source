export type InvoicePayment = { cardId: string; competence: string; amount: number; reversed?: boolean; status?: string };
export function invoicePaymentSummary(payments: InvoicePayment[], cardId: string, competence: string, total: number) {
  let paidCents = 0, scheduledCents = 0, uncertain = false;
  for (const payment of payments) {
    if (payment.cardId !== cardId || payment.competence !== competence || payment.reversed || payment.status === 'reversed' || payment.status === 'cancelled') continue;
    const cents = Math.round(payment.amount * 100);
    if (!Number.isSafeInteger(cents) || cents <= 0 || Math.abs(payment.amount - cents / 100) > 1e-7 || (payment.status && !['paid','scheduled'].includes(payment.status))) { uncertain = true; continue; }
    if (payment.status === 'scheduled') scheduledCents += cents; else paidCents += cents;
  }
  const totalCents = Math.max(0, Math.round(total * 100));
  return { paid: paidCents / 100, scheduled: scheduledCents / 100, outstanding: Math.max(0, totalCents - paidCents) / 100, available: uncertain ? 0 : Math.max(0, totalCents - paidCents - scheduledCents) / 100, fullyPaid: !uncertain && totalCents > 0 && paidCents >= totalCents, uncertain };
}
