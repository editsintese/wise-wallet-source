import type {TransactionView} from './transaction-model';
export function reportRangeValid(start:string,end:string){const valid=(date:string)=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return false;const d=new Date(date+'T00:00:00Z');return !Number.isNaN(d.valueOf())&&d.toISOString().slice(0,10)===date};return valid(start)&&valid(end)&&start<=end}
export function buildReportCsv(items:TransactionView[],accounts:{id:string;name:string}[]){
 const rows=[['Competência','Descrição','Categoria','Conta','Responsável','Situação','Tipo','Valor'],...items.map(item=>[item.rawDate,item.description,item.category,item.historicalOnly?'Somente histórico · sem impacto no saldo':accounts.find(a=>a.id===item.accountId)?.name||'Não informada',item.owner,item.historicalOnly?'Histórico':item.status==='planned'?'Prevista':'Realizada',item.kind==='income'?'Receita':'Despesa',item.amount.toFixed(2).replace('.',',')])];
 const cell=(value:string)=>{const safe=/^[\s]*[=+\-@]/.test(value)?"'"+value:value;return '"'+safe.replaceAll('"','""')+'"'};
 return '\uFEFF'+rows.map(row=>row.map(value=>cell(String(value))).join(';')).join('\r\n');
}
