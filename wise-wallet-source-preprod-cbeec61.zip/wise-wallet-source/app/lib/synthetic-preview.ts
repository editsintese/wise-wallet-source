/** The fixture-only tool is available solely in a local development session. */
export function isSyntheticPreviewAllowed(environment: string | undefined, hostname: string): boolean {
  return environment === 'development' && (hostname === 'localhost' || hostname === '127.0.0.1');
}
