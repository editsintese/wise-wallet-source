/** Mirrors the existing private wallet allowlist. This is a UI guard; server rules remain authoritative. */
export const familyWalletEmails=['family-user@example.invalid','family-user@example.invalid'] as const;
const localSyntheticEmail=process.env.NODE_ENV==='development'&&process.env.NEXT_PUBLIC_USE_FIREBASE_EMULATORS==='true'?String(process.env.NEXT_PUBLIC_WISE_QA_EMAIL||'').trim().toLowerCase():'';
export function isFamilyEmail(email:string|null|undefined){const normalized=String(email||'').trim().toLowerCase();return familyWalletEmails.some(allowed=>allowed===normalized)||Boolean(localSyntheticEmail&&normalized===localSyntheticEmail);}
export function isFamilyIdentity(user:{email?:string|null;emailVerified?:boolean}|null|undefined){const normalized=String(user?.email||'').trim().toLowerCase();return Boolean(user&&(user.emailVerified||(localSyntheticEmail&&normalized===localSyntheticEmail))&&isFamilyEmail(normalized));}
export function isCurrentFamilySession(current:{uid:string;email?:string|null;emailVerified?:boolean}|null|undefined,uid:string,generation:number,currentGeneration:number){return current?.uid===uid&&generation===currentGeneration&&isFamilyIdentity(current);}
