export type RecoveryStorage=Pick<Storage,'getItem'|'setItem'|'removeItem'|'key'|'length'>;
const intent=(value:unknown):unknown=>Array.isArray(value)?value.map(intent):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).filter(([key])=>!['idempotencyKey','expectedVersion','expectedAccountVersion','expectedRevision','fromVersion','toVersion'].includes(key)).sort(([a],[b])=>a.localeCompare(b)).map(([key,v])=>[key,intent(v)])):value;
/** Recover one command per operation/user. Persist before dispatch; never generate a replacement key. */
export function createCommandRecovery(storage:RecoveryStorage,uid:string,send:(operation:string,payload:unknown)=>Promise<unknown>){
 const prefix=`wise-command-pending:v1:${encodeURIComponent(uid)}:`;
 const read=(operation:string)=>{const saved=storage.getItem(prefix+operation);return saved?JSON.parse(saved) as {operation:string;payload:unknown;signature:string}:null;};
 async function execute(operation:string,request:{operation:string;payload:unknown;signature:string}){
  if(request.operation!==operation)throw Error('invalid-command-journal');
  try{const result=await send(operation,request.payload);storage.removeItem(prefix+operation);return result;}
  catch(error){const value=error as {code?:string;details?:{reason?:string}},reason=value.details?.reason,code=String(value.code||'').replace('functions/','');if(['invalid-argument','version-conflict','permission-denied','failed-precondition','not-found','idempotency-conflict','already-exists','unauthenticated','rate-limited'].includes(reason||'')||['invalid-argument','permission-denied','unauthenticated','failed-precondition','not-found','already-exists','aborted'].includes(code))storage.removeItem(prefix+operation);throw error;}
 }
 const busy=new Set<string>();
 return {
  list:()=>Array.from({length:storage.length},(_,i)=>storage.key(i)).filter((key):key is string=>Boolean(key?.startsWith(prefix))).map(key=>key.slice(prefix.length)),
  submit:async(operation:string,payload:unknown)=>{
   if(busy.has(operation))throw Error('command-busy');
   const signature=JSON.stringify(intent(payload)),pending=read(operation);
   if(pending&&pending.signature!==signature)throw Error('another-command-pending');
   const request=pending||{operation,payload,signature};storage.setItem(prefix+operation,JSON.stringify(request));busy.add(operation);
   try{return await execute(operation,request);}finally{busy.delete(operation);}
  },
  retry:async(operation:string)=>{if(busy.has(operation))throw Error('command-busy');const pending=read(operation);if(!pending)throw Error('command-not-pending');busy.add(operation);try{return await execute(operation,pending);}finally{busy.delete(operation);}},
 };
}
