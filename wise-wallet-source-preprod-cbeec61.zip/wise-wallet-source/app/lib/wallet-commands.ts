import {createCommandRecovery} from './command-recovery';
import {httpsCallable} from 'firebase/functions';
import {commandBackendEnabled,firebaseFunctions,firebaseAuth} from './firebase';

async function rawWalletCommand<T>(operation:string,payload:unknown):Promise<T>{
 if(!commandBackendEnabled||!firebaseFunctions)throw new Error('command-backend-disabled');
 const call=httpsCallable<{schemaVersion:1;operation:string;payload:unknown},T>(firebaseFunctions,'walletCommand');
 try{return (await call({schemaVersion:1,operation,payload})).data;}catch(error){if((error as {details?:{reason?:string}})?.details?.reason==='bank-reference-conflict'&&typeof window!=='undefined')window.dispatchEvent(new Event('wise-bank-reference-conflict'));throw error;}
}

let recovery:{uid:string;store:ReturnType<typeof createCommandRecovery>}|null=null;
function commandRecovery(){const uid=firebaseAuth?.currentUser?.uid;if(!uid||typeof window==='undefined')throw Error('auth-required');if(recovery?.uid!==uid)recovery={uid,store:createCommandRecovery(window.sessionStorage,uid,(operation,payload)=>{if(firebaseAuth?.currentUser?.uid!==uid)throw Error('auth-changed');return rawWalletCommand(operation,payload);})};return recovery.store;}
const changed=()=>{if(typeof window!=='undefined')window.dispatchEvent(new Event('wise-command-pending'));};
export async function callWalletCommand<T>(operation:string,payload:unknown):Promise<T>{
 if(['createManualEntry','bulkTransactions','manageInvestment'].includes(operation)||!(payload as {idempotencyKey?:string})?.idempotencyKey)return rawWalletCommand<T>(operation,payload);
 try{return await commandRecovery().submit(operation,payload) as T;}finally{changed();}
}
export function pendingWalletCommands(){return commandRecovery().list();}
export async function retryWalletCommand(operation:string){try{return await commandRecovery().retry(operation);}finally{changed();}}

export function newIdempotencyKey(prefix:string){return `${prefix}-${crypto.randomUUID()}`.slice(0,128);}

export function callManualEntry(payload:Record<string,unknown>){return callWalletCommand('createManualEntry',payload);}

export function callBulkTransactions(request:Record<string,unknown>){const {payload,...identity}=request;return callWalletCommand('bulkTransactions',{...identity,...(payload as Record<string,unknown>)});}
