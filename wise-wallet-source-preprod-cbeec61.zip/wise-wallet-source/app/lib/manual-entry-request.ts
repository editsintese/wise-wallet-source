// One recoverable manual creation per user/tab. Keep versions from the first attempt.
export function createManualEntryRequest(send: (request: Record<string, unknown>) => Promise<unknown>, key: () => string, journal: {read: () => string | null; write: (value: string) => void; clear: () => void}) {
  let pending: {intent: string; request: Record<string, unknown>} | null = null;
  let busy = false, unavailable = false;
  try {
    const saved = journal.read();
    if (saved) {
      const value = JSON.parse(saved);
      if (typeof value.intent !== 'string' || value.request?.householdId !== 'family-wallet' || typeof value.request.idempotencyKey !== 'string' || !value.request.payload || typeof value.request.payload !== 'object') throw Error('invalid-manual-entry-journal');
      pending = value;
    }
  } catch { unavailable = true; }
  function clear() { journal.clear(); pending = null; }
  async function execute() {
    if (unavailable || !pending || busy) throw Error('manual-entry-unavailable');
    busy = true;
    try { const result = await send(pending.request); clear(); return result; }
    catch (error) {
      const reason = (error as {details?: {reason?: string}})?.details?.reason;
      if (reason && ['bank-reference-conflict','invalid-argument','version-conflict','permission-denied','failed-precondition','not-found','idempotency-conflict','already-exists','unauthenticated'].includes(reason)) clear();
      throw error;
    } finally { busy = false; }
  }
  return {
    hasPending: () => pending !== null,
    retry: execute,
    submit: async (payload: Record<string, unknown>) => {
      if (unavailable || busy) throw Error('manual-entry-unavailable');
      const {expectedAccountVersion: _version, ...values} = payload;
      const intent = JSON.stringify(values);
      if (pending && pending.intent !== intent) throw Error('manual-entry-pending');
      if (!pending) {
        const value = {intent, request: {householdId: 'family-wallet', idempotencyKey: key(), payload}};
        // Refuse dispatch if the recovery record cannot be persisted.
        journal.write(JSON.stringify(value)); pending = value;
      }
      return execute();
    },
  };
}
