import { getApps, initializeApp } from 'firebase/app';
import { initializeAppCheck, ReCaptchaEnterpriseProvider } from 'firebase/app-check';
import { connectAuthEmulator, getAuth } from 'firebase/auth';
import { connectFirestoreEmulator, getFirestore } from 'firebase/firestore';
import { connectFunctionsEmulator, getFunctions } from 'firebase/functions';

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

export const firebaseConfigured = Object.values(firebaseConfig).every(Boolean);
export const firebaseApp = firebaseConfigured ? (getApps()[0] ?? initializeApp(firebaseConfig)) : null;

export const firebaseAuth = firebaseApp ? getAuth(firebaseApp) : null;
export const firestore = firebaseApp ? getFirestore(firebaseApp) : null;
export const firebaseFunctions = firebaseApp ? getFunctions(firebaseApp,'southamerica-east1') : null;
export const commandBackendEnabled = process.env.NEXT_PUBLIC_USE_COMMAND_BACKEND === 'true';
export const emulatorEnabled = process.env.NEXT_PUBLIC_USE_FIREBASE_EMULATORS === 'true';

if (commandBackendEnabled && !emulatorEnabled && firebaseApp && typeof window !== 'undefined') {
  const siteKey=process.env.NEXT_PUBLIC_FIREBASE_APP_CHECK_SITE_KEY;
  if (!siteKey) throw new Error('App Check não configurado para o ambiente persistente.');
  initializeAppCheck(firebaseApp,{provider:new ReCaptchaEnterpriseProvider(siteKey),isTokenAutoRefreshEnabled:true});
}

// An explicit demo build can only use emulators, never a cloud project.
// The host can be localhost or the Mac's LAN IP so the homologation build can
// also be opened from a phone on the same Wi-Fi.
if (emulatorEnabled && typeof window !== 'undefined') {
  if (!firebaseConfig.projectId?.startsWith('demo-')) throw new Error('Emuladores exigem projeto demo.');
  const emulatorHost = window.location.hostname || '127.0.0.1';
  const marker=globalThis as typeof globalThis & {walletEmulatorsConnected?:boolean};
  if (!marker.walletEmulatorsConnected && firebaseAuth && firestore && firebaseFunctions) {
    connectAuthEmulator(firebaseAuth,`http://127.0.0.1:${process.env.NEXT_PUBLIC_AUTH_EMULATOR_PORT || '9097'}`,{disableWarnings:true});
    connectFirestoreEmulator(firestore,'127.0.0.1',Number(process.env.NEXT_PUBLIC_FIRESTORE_EMULATOR_PORT || 8089));
    connectFunctionsEmulator(firebaseFunctions,'127.0.0.1',Number(process.env.NEXT_PUBLIC_FUNCTIONS_EMULATOR_PORT || 5007));
    marker.walletEmulatorsConnected=true;
  }
}
