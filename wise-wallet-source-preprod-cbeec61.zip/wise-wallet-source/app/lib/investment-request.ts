// Keep the exact request after an ambiguous response; live account versions may change meanwhile.
export function createInvestmentRequestState(send: (request: Record<string, unknown>) => Promise<unknown>, key: () => string, journal?: {read: () => string | null; write: (value: string) => void; clear: () => void}) {
  let pending: {intent: string; request: Record<string, unknown>} | null = null;
  let busy = false;
  let journalError = false;
  try {
    const saved = journal?.read();
    if (saved) {
      const value = JSON.parse(saved);
      if (typeof value.intent !== 'string' || value.request?.householdId !== 'family-wallet' || typeof value.request?.idempotencyKey !== 'string' || !['create','valuation','contribution','withdrawal','archive','correct','reverse'].includes(value.request?.action) || !value.request?.payload) throw new Error('invalid-investment-journal');
      pending = value;
    }
  } catch { journalError = true; }
  function clear() { journal?.clear(); pending = null; }
  async function execute() {
    if (journalError) throw new Error('investment-journal-unavailable');
    if (!pending || busy) throw new Error('investment-request-busy');
    busy = true;
    try { const result = await send(pending.request); clear(); return result; }
    catch (error) {
      const reason = (error as {details?: {reason?: string}})?.details?.reason;
      if (reason && ['bank-reference-conflict','invalid-argument','version-conflict','permission-denied','failed-precondition','not-found','idempotency-conflict','already-exists','unauthenticated'].includes(reason)) clear();
      throw error;
    } finally { busy = false; }
  }
  return {
    hasPending: () => pending !== null,
    retry: execute,
    submit: async (action: string, payload: Record<string, unknown>) => {
      if (journalError) throw new Error('investment-journal-unavailable');
      const {expectedAccountVersion: _account, expectedVersion: _position, ...values} = payload;
      const intent = JSON.stringify([action, values]);
      if (pending && pending.intent !== intent) throw new Error('investment-request-pending');
      if (!pending) pending = {intent, request: {householdId: 'family-wallet', idempotencyKey: key(), action, payload}};
      // Persist before dispatch: if storage fails, no financial request is sent.
      try { journal?.write(JSON.stringify(pending)); } catch (error) { pending = null; throw error; }
      return execute();
    },
  };
}
