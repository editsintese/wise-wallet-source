'use client';
import {MaybeField as ConnectedField} from './maybe-ui/primitives';

import {MaybeButton} from './maybe-ui/primitives';
import {RecordRow} from './maybe-ui/record-row';
import {MaybeDialog} from './maybe-ui/dialog';
import type {RegisteredRecurrenceTransaction} from './recurrence-rows';
import {RecurrenceList} from './maybe-ui/recurrence-list';
import { FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { commandBackendEnabled } from './lib/firebase';
import { callWalletCommand, newIdempotencyKey } from './lib/wallet-commands';
import { Button } from './design-system/button';
import { Field } from './design-system/field';
import { ResponsiveDialog } from './design-system/dialog';
import { parseMoneyInput } from './web-finance';
import { Chip } from './design-system/chip';
import { CurrencyInput, formatCurrencyAmount } from './design-system/currency-input';
import { moneyTone } from './design-system/money-tone';
import { Recurrence } from './monthly-overview';
import { hasAmbiguousWeeklyMonth, isRecurrenceActiveInMonth, occurrencesForRuleMonth, recurrenceMonthAmount } from './recurrence-domain';

type Account = { id: string; name: string; archived?: boolean };
type Card = { id: string; name: string };
type RecurrenceRecord = Recurrence & { owner?: string; accountId?: string; cardId?: string; active?: boolean; endDate?: string; frequency?: string; observations?: string; version?: number };

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const currentMonth = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' }).slice(0, 7);
const monthLabel = (month: string) => new Date(month + '-01T12:00:00').toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
const frequencyLabel = (value?: string) => ({monthly: 'Mensal', weekly: 'Semanal', yearly: 'Anual', annual: 'Anual', anual: 'Anual'}[String(value || 'monthly').toLowerCase()] || 'Mensal');
const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const monthsOfYear = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

export function RecurrencesScreen({ recurrences, accounts, cards, transactions, payments, initialEdit, onCloseInitialEdit, onToggleMonth, onEditOccurrence, onEditForecast, onUpdate, onArchive, onConfirmPlanned }: { recurrences: RecurrenceRecord[]; accounts: Account[]; cards: Card[]; transactions: RegisteredRecurrenceTransaction[]; payments:{cardId:string;competence:string;amount:number;reversed?:boolean;status?:string}[]; initialEdit?: RecurrenceRecord | null; onCloseInitialEdit?: () => void; onToggleMonth: (id: string, month: string) => void; onEditOccurrence: (id:string) => void; onEditForecast: (id:string, month:string, amount:number) => Promise<void>; onUpdate: (id: string, patch: Record<string, unknown>, expectedRevision?:number) => Promise<void>; onArchive: (id: string) => Promise<void>;onConfirmPlanned?:(item:RecurrenceRecord,key:string)=>void }) {
  const [month, setMonth] = useState(currentMonth());
  const [editing, setEditing] = useState<RecurrenceRecord | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [createError, setCreateError] = useState('');
  const [resumeError,setResumeError]=useState('');
  const [resuming,setResuming]=useState<string|null>(null);
  async function resumeRule(item:RecurrenceRecord){if(resuming)return;setResuming(item.id);setResumeError('');try{await onUpdate(item.id,{active:true,archivedAt:null},item.ruleRevision??0);}catch{setResumeError('Não foi possível retomar a regra. Confira possíveis bloqueios ou dados atualizados.');}finally{setResuming(null);}}
  const [editError, setEditError] = useState('');
  const [forecast, setForecast] = useState<{item:RecurrenceRecord;month:string}|null>(null);
  const [forecastError, setForecastError] = useState('');
  const [forecastSaving, setForecastSaving] = useState(false);
  const editDialogRef = useRef<HTMLElement>(null);
  const editCloseRef = useRef<HTMLButtonElement>(null);
  const onCloseInitialEditRef = useRef(onCloseInitialEdit);
  const active = useMemo(() => recurrences.filter((item) => isRecurrenceActiveInMonth(item,month)).sort((left, right) => left.description.localeCompare(right.description, 'pt-BR')), [recurrences,month]);
  useEffect(() => { if (initialEdit) setEditing(initialEdit); }, [initialEdit]);
  useEffect(() => { onCloseInitialEditRef.current = onCloseInitialEdit; }, [onCloseInitialEdit]);


  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const amount = Number(String(form.get('amount') || '').replace(',', '.'));
    const cardId = String(form.get('cardId') || '');
    if (!String(form.get('description') || '').trim() || !Number.isFinite(amount) || amount <= 0) return;
    const values={description:String(form.get('description')).trim(),category:String(form.get('category')||'').trim(),amount,kind:String(form.get('kind')||'expense'),owner:String(form.get('owner')||'Família'),frequency:String(form.get('frequency')||'monthly'),dueDay:Number(form.get('dueDay')||1),startDate:String(form.get('startDate')||currentMonth()+'-01'),endDate:String(form.get('endDate')||''),accountId:String(form.get('accountId')||''),cardId:String(form.get('cardId')||''),monthsOfYear:form.getAll('monthsOfYear').map(Number).filter(Boolean),active:true,observations:String(form.get('observations')||'')};
    try {setCreateError('');if(!commandBackendEnabled)throw new Error('backend-required');const card=Boolean(values.cardId);await callWalletCommand(card?'manageCardRecurrence':'manageRecurrenceRule',{householdId:'family-wallet',idempotencyKey:newIdempotencyKey(card?'card-recurrence-create':'recurrence-rule-create'),action:'create',payload:{values}});}catch{setCreateError('Não foi possível criar a recorrência. Confira se há fatura paga no período e se a frequência é mensal ou anual.');return;}
    formElement.reset(); setShowForm(false);
  }

  async function saveEdit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!editing) return;
    const form = new FormData(event.currentTarget);
    try { setEditError(''); await onUpdate(editing.id, {
      description: String(form.get('description') || '').trim(), category: String(form.get('category') || '').trim(),
      amount: Number(String(form.get('amount') || '').replace(',', '.')), kind: String(form.get('kind') || 'expense'),
      owner: String(form.get('owner') || 'Família'), frequency: String(form.get('frequency') || 'monthly'),
      dueDay: Number(form.get('dueDay') || 1), startDate: String(form.get('startDate') || editing.startDate), endDate: String(form.get('endDate') || ''),
      weekDay: Number(form.get('weekDay') || 0) || null,
      accountId: String(form.get('accountId') || ''), cardId: String(form.get('cardId') || ''), monthsOfYear: form.getAll('monthsOfYear').map(Number).filter(Boolean), observations: String(form.get('observations') || '')
    }, editing.ruleRevision??0);
    setEditing(null); } catch { setEditError('Não foi possível salvar. Confira faturas pagas ou agendadas e tente novamente.'); }
  }

  const rows=active.flatMap(item=>occurrencesForRuleMonth(item,month).map(occurrence=>({item,occurrence})));
  const paidCount = rows.filter(({item,occurrence}) => !item.cardId && item.settledMonths?.includes(occurrence.occurrenceKey)).length;
  const cardCount = active.filter((item) => Boolean(item.cardId)).length;
  const unsettledCount = rows.filter(({item,occurrence}) => !item.cardId && !item.settledMonths?.includes(occurrence.occurrenceKey)).length;
  const monthShort = monthsOfYear[Number(month.slice(5, 7)) - 1]?.toUpperCase() || 'MÊS';
  return <section className="mb-transactions">
    <header className="mb-page-heading"><div className="mb-page-copy"><h2>Recorrências</h2><p>Entradas e despesas que se repetem ao longo do ano.</p></div><div className="recurrence-heading-actions"><ConnectedField label={"Mês"} ><input type="month" value={month} onChange={(event) => setMonth(event.target.value)} /></ConnectedField><Button onClick={() => setShowForm((value) => !value)}>{showForm ? 'Fechar formulário' : '+ Nova recorrência'}</Button></div></header>
    <dl className="mb-summary"><div><dt>Recorrências ativas</dt><dd>{active.length}</dd></div><div><dt>Ocorrências baixadas no mês</dt><dd>{paidCount}</dd></div><div><dt>Associadas a cartão</dt><dd>{cardCount}</dd></div></dl>
    {showForm && <MaybeDialog title="Nova recorrência" onClose={()=>setShowForm(false)}><form className="recurrence-editor-form" onSubmit={create}>{createError && <p role="alert">{createError}</p>}<Field label="Descrição"><input name="description" required placeholder="Ex.: Aluguel" /></Field><Field label="Categoria"><input name="category" placeholder="Moradia" /></Field><Field label="Tipo"><select name="kind"><option value="expense">Despesa</option><option value="income">Receita</option></select></Field><Field label="Valor previsto"><CurrencyInput name="amount" required defaultValue={0} /></Field><Field label="Periodicidade"><select name="frequency"><option value="monthly">Mensal</option><option value="yearly">Anual / meses selecionados</option><option value="weekly">Semanal</option></select></Field><Field label="Dia"><input name="dueDay" type="number" min="1" max="31" defaultValue="1" /></Field><Field label="Início"><input name="startDate" type="date" required /></Field><Field label="Fim"><input name="endDate" type="date" /></Field><Field label="Responsável"><input name="owner" defaultValue="Família" /></Field><Field label="Conta"><select name="accountId"><option value="">Não associar</option>{accounts.filter((item) => !item.archived).map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></Field><Field label="Cartão"><select name="cardId"><option value="">Não associar</option>{cards.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></Field><fieldset className="month-check-grid"><legend>Meses de incidência anual</legend>{monthsOfYear.map((label, index) => <label key={label}><input type="checkbox" name="monthsOfYear" value={index + 1} />{label}</label>)}</fieldset><Field label="Observações"><textarea name="observations" rows={2} /></Field><Button type="submit">Salvar recorrência</Button></form></MaybeDialog>}
    {active.some(item=>hasAmbiguousWeeklyMonth(item,month)) && <p role="alert" className="form-help">Há recorrências semanais antigas com baixa registrada apenas por mês. Suas semanas não foram projetadas; é preciso conferir os vínculos antes de usá-las.</p>}
    <RecurrenceList onConfirmPlanned={onConfirmPlanned} active={active} recordedRules={recurrences} month={month} accounts={accounts} cards={cards} transactions={transactions} payments={payments} onToggleMonth={onToggleMonth} onEditOccurrence={onEditOccurrence} onForecast={(item,month)=>{setForecastError('');setForecast({item,month})}} onEditRule={item=>{setEditError('');setEditing(item)}} onArchive={onArchive}/>
    {!active.length && !transactions.some(item=>item.recurrencePending&&item.status==='planned'&&String(item.scheduledDate||item.rawDate||'').startsWith(month)) && <p className="empty-state">Nenhuma recorrência ativa cadastrada.</p>}
    {recurrences.some(item=>item.active===false&&!item.closedForFuture)&&<section className="mb-table-container" aria-label="Regras pausadas"><h3>Regras pausadas</h3><p className="mb-list-note">Retomar volta a exibir previsões. Não registra pagamentos automaticamente.</p>{recurrences.filter(item=>item.active===false&&!item.closedForFuture).map(item=><RecordRow key={item.id} title={item.description} meta="Pausada" value={money.format(item.amount)} actions={<MaybeButton disabled={Boolean(resuming)} onClick={()=>void resumeRule(item)}>{resuming===item.id?'Retomando…':'Retomar regra'}</MaybeButton>}/>)}{resumeError&&<p role="alert">{resumeError}</p>}</section>}
    {forecast && <ResponsiveDialog open title="Editar previsão do mês" onClose={() => {if(!forecastSaving)setForecast(null);}}><p className="section-description">{forecast.item.description} · {monthLabel(forecast.month)}</p><form onSubmit={async event=>{event.preventDefault();try{const value=parseMoneyInput(String(new FormData(event.currentTarget).get('amount')||''));if(value<=0)throw new Error('invalid');setForecastSaving(true);setForecastError('');await onEditForecast(forecast.item.id,forecast.month,value);setForecast(null);}catch{setForecastError('Não foi possível salvar. Confira o valor e se a recorrência ainda está ativa e sem baixa.');}finally{setForecastSaving(false);}}}><Field label="Valor previsto neste mês"><CurrencyInput name="amount" defaultValue={formatCurrencyAmount(recurrenceMonthAmount(forecast.item,forecast.month,transactions) ?? forecast.item.amount)} required /></Field><p className="form-help">A previsão geral e os outros meses permanecem iguais. Nenhum pagamento ou recebimento será registrado.</p>{forecastError && <p role="alert">{forecastError}</p>}<div className="modal-actions"><Button variant="secondary" onClick={()=>setForecast(null)} disabled={forecastSaving}>Cancelar</Button><Button type="submit" disabled={forecastSaving}>{forecastSaving?'Salvando…':'Salvar previsão'}</Button></div></form></ResponsiveDialog>}
    {editing && <MaybeDialog title="Editar recorrência" onClose={()=>{setEditing(null);onCloseInitialEdit?.()}}><form onSubmit={saveEdit}>{editError && <p role="alert">{editError}</p>}{editing.cardId && <p className="form-help">Se houver faturas antigas pagas, alterações permitidas passam a valer a partir do mês atual; o histórico anterior será preservado.</p>}<Field label="Descrição"><input name="description" defaultValue={editing.description} required /></Field><div className="form-grid"><Field label="Categoria"><input name="category" defaultValue={editing.category} /></Field><Field label="Tipo"><select name="kind" defaultValue={editing.kind}><option value="expense">Despesa</option><option value="income">Receita</option></select></Field></div><div className="form-grid"><Field label="Valor previsto"><CurrencyInput name="amount" defaultValue={formatCurrencyAmount(editing.amount)} required /></Field><Field label="Periodicidade"><select name="frequency" defaultValue={editing.frequency || 'monthly'}><option value="monthly">Mensal</option><option value="yearly">Anual / meses selecionados</option><option value="weekly">Semanal</option></select></Field></div><div className="form-grid"><Field label="Dia"><input name="dueDay" type="number" min="1" max="31" defaultValue={editing.dueDay || 1} /></Field><Field label="Responsável"><input name="owner" defaultValue={editing.owner || 'Família'} /></Field></div><div className="form-grid"><Field label="Início"><input name="startDate" type="date" defaultValue={editing.startDate} required /></Field><Field label="Fim"><input name="endDate" type="date" defaultValue={editing.endDate || ''} /></Field></div><Field label="Conta"><select name="accountId" defaultValue={editing.accountId || ''}><option value="">Não associar</option>{accounts.filter((item) => !item.archived).map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></Field><Field label="Cartão"><select name="cardId" defaultValue={editing.cardId || ''}><option value="">Não associar</option>{cards.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></Field><fieldset className="month-check-grid"><legend>Meses de incidência anual</legend>{monthsOfYear.map((label, index) => <label key={label}><input type="checkbox" name="monthsOfYear" value={index + 1} defaultChecked={editing.monthsOfYear?.includes(index + 1)} />{label}</label>)}</fieldset><Field label="Observações"><textarea name="observations" defaultValue={editing.observations || ''} rows={2} /></Field><Button type="submit">Salvar alterações</Button></form></MaybeDialog>}
  </section>;
}
