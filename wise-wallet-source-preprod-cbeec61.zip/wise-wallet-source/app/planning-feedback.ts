const money=(value:number)=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(value);
export function goalFeedback(target:number,current:number){
 if(!Number.isFinite(target)||!Number.isFinite(current)||target<=0||current<0)return {remaining:null,title:'Revise os valores da meta',recommendation:'Informe um objetivo positivo e o valor já acumulado antes de definir um aporte.'};
 const remaining=Math.max(0,Math.round((target-current)*100)/100);
 return remaining===0?{remaining,title:'Meta atingida pelos valores informados',recommendation:'Confirme se o valor está disponível e se a finalidade da meta foi atendida antes de redistribuir a reserva.'}:{remaining,title:`Faltam ${money(remaining)} para a meta`,recommendation:'Defina um prazo e compare o aporte necessário com seu orçamento completo. Preserve os compromissos e a reserva antes de aumentar os aportes.'};
}
export function purchaseFeedback(rows:{month:string;balance:number;balanceWithPurchase:number;purchaseAmount:number}[],installments:number){
 if(!rows.length)return null;
 const worst=rows.reduce((lowest,row)=>row.balanceWithPurchase<lowest.balanceWithPurchase?row:lowest,rows[0]);
 const impact=Math.round(rows.reduce((sum,row)=>sum+row.purchaseAmount,0)*100)/100;
 const visibleInstallments=rows.filter(row=>row.purchaseAmount>0).length;
 const before=rows.some(row=>row.balance<0);
 return {negative:worst.balanceWithPurchase<0,month:worst.month,impact,title:worst.balanceWithPurchase<0?(before?'A projeção já tinha déficit; a compra aumenta o compromisso':'A compra deixa a projeção parcial negativa'):'A compra reduz a margem disponível',explanation:`Impacto no recorte: ${money(impact)}. Menor projeção: ${money(worst.balanceWithPurchase)}.`,recommendations:worst.balanceWithPurchase<0?['Compare uma compra menor ou adie o primeiro vencimento e refaça a simulação.','Confira quais despesas podem ser ajustadas; não use crédito adicional para tratar o déficit como resolvido.']:['Confira faturas, recorrências e outras despesas que não entram neste cálculo antes de assumir a compra.','Compare o valor restante com suas metas e com a reserva que precisa preservar.'],outside:installments>visibleInstallments?'Há parcelas fora do recorte. Confira também esses meses antes de decidir.':null};
}
