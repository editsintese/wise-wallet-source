import { weeklyDatesForMonth } from '../packages/finance-domain/index.mjs';

export type RecurrenceKind = 'income' | 'expense';

export type RecurrenceRule = {
  id: string;
  description: string;
  amount: number;
  kind: RecurrenceKind;
  startDate: string;
  endDate?: string;
  frequency?: string;
  dueDay?: number;
  weekDay?: number;
  monthsOfYear?: number[];
  active?: boolean;
  settledMonths?: string[];
  occurrenceTransactions?: Record<string, string>;
  pendingOccurrenceTransactions?: Record<string, string>;
  monthlyAmounts?: Record<string, number>;
  ruleRevision?:number;
  closedForFuture?:boolean;
  accountId?: string;
  cardId?: string;
  category?: string;
  subcategory?: string;
  owner?: string;
  observations?: string;
  version?: number;
};

export type RecurrenceOccurrence = {
  id: string;
  recurrenceId: string;
  month: string;
  occurrenceKey: string;
  date: string;
  amount: number;
  kind: RecurrenceKind;
  status: 'planned' | 'realized';
  accountId?: string;
  cardId?: string;
  category?: string;
  subcategory?: string;
  owner?: string;
  description: string;
};

const monthKey = (value: string) => String(value || '').slice(0, 7);

export const occurrenceId = (recurrenceId: string, month: string) =>
  `occ-${recurrenceId}-${month}`.replace(/[^a-zA-Z0-9_-]/g, '-');

export function isRecurrenceActiveInMonth(item: RecurrenceRule, month: string): boolean {
  if (item.active === false || !/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) return false;
  // Imported workbook rows may leave the optional start month blank. A blank
  // start means “active from the beginning of the available timeline”, rather
  // than an inactive rule.
  const start = monthKey(item.startDate);
  const end = monthKey(item.endDate || '');
  if ((start && !/^\d{4}-\d{2}$/.test(start)) || (start && month < start) || (end && month > end)) return false;

  const frequency = String(item.frequency || 'monthly').toLowerCase();
  if (frequency === 'yearly' || frequency === 'annual' || frequency === 'anual') {
    const monthNumber = Number(month.slice(5, 7));
    const selected = (item.monthsOfYear || []).map(Number).filter((value) => value >= 1 && value <= 12);
    return selected.length ? selected.includes(monthNumber) : (!start || monthNumber === Number(start.slice(5, 7)));
  }
  return true;
}

export function recurrenceOccurrence(item: RecurrenceRule, month: string): RecurrenceOccurrence | null {
  if (!isRecurrenceActiveInMonth(item, month) || String(item.frequency||'monthly').toLowerCase()==='weekly') return null;
  const anchor = Math.max(1, Math.min(31, Math.floor(Number(item.dueDay || (item.startDate || '').slice(8, 10)) || 1)));
  const [year, monthNumber] = month.split('-').map(Number);
  const endOfMonth = new Date(0); endOfMonth.setUTCHours(0, 0, 0, 0); endOfMonth.setUTCFullYear(year, monthNumber, 0);
  const day = Math.min(anchor, endOfMonth.getUTCDate());
  return {
    id: occurrenceId(item.id, month),
    recurrenceId: item.id,
    month,
    occurrenceKey: month,
    date: `${month}-${String(day).padStart(2, '0')}`,
    amount: Number(item.monthlyAmounts?.[month] ?? item.amount ?? 0),
    kind: item.kind,
    status: item.settledMonths?.includes(month) ? 'realized' : 'planned',
    accountId: item.accountId || undefined,
    cardId: item.cardId || undefined,
    category: item.category,
    subcategory: item.subcategory,
    owner: item.owner,
    description: item.description,
  };
}

export function hasAmbiguousWeeklyMonth(item:RecurrenceRule,month:string):boolean { return String(item.frequency||'monthly').toLowerCase()==='weekly' && Boolean(item.settledMonths?.includes(month)||item.occurrenceTransactions?.[month]); }

export function occurrencesForRuleMonth(item:RecurrenceRule, month:string):RecurrenceOccurrence[] {
  if(String(item.frequency||'monthly').toLowerCase()!=='weekly') { const itemOccurrence=recurrenceOccurrence(item,month);return itemOccurrence?[itemOccurrence]:[]; }
  if(item.active===false || hasAmbiguousWeeklyMonth(item,month))return [];
  let dates:string[];try {dates=weeklyDatesForMonth(item.startDate,month,item.endDate||'');}catch{return [];}
  return dates.map(date=>({id:occurrenceId(item.id,date),recurrenceId:item.id,month,occurrenceKey:date,date,amount:Number(item.monthlyAmounts?.[month]??item.amount??0),kind:item.kind,status:item.settledMonths?.includes(date)?'realized':'planned',accountId:item.accountId||undefined,cardId:item.cardId||undefined,category:item.category,subcategory:item.subcategory,owner:item.owner,description:item.description}));
}

export function occurrencesForMonth(items: RecurrenceRule[], month: string): RecurrenceOccurrence[] {
  return items.flatMap(item=>occurrencesForRuleMonth(item,month));
}

export function calculateProjectedFree(input: {
  currentCash: number;
  plannedIncome: number;
  pendingExpenses: number;
  pendingInvoices: number;
}) {
  return Number(input.currentCash || 0) + Number(input.plannedIncome || 0) - Number(input.pendingExpenses || 0) - Number(input.pendingInvoices || 0);
}

/** Paid months use their linked transaction; missing links must not masquerade as estimates. */
export function recurrenceMonthAmount(item:RecurrenceRule, month:string, transactions:{id:string;amount:number}[]):number|null {
 if(!item.settledMonths?.includes(month)){const amount=item.monthlyAmounts?.[month.slice(0,7)] ?? item.amount;return Number.isFinite(amount)?amount:null;}
 const id=item.occurrenceTransactions?.[month];
 const transaction=id?transactions.find(entry=>entry.id===id):undefined;
 return transaction && Number.isFinite(transaction.amount)?transaction.amount:null;
}

/** Only explicit monthly forecasts are shown as virtual entries; no financial record is created. */
export function monthlyForecasts(items:RecurrenceRule[], transactions:{recurrenceId?:string;occurrenceMonth?:string;status?:string;deletedAt?:unknown}[], payments:{cardId:string;competence:string;amount:number;reversed?:boolean;status?:string}[]=[]):RecurrenceOccurrence[] {
 return items.flatMap(item=>Object.keys(item.monthlyAmounts||{}).flatMap(month=>{
  return occurrencesForRuleMonth(item,month).filter(occurrence=>!item.settledMonths?.includes(occurrence.occurrenceKey)&&!item.occurrenceTransactions?.[occurrence.occurrenceKey]&&!transactions.some(t=>t.recurrenceId===item.id&&t.occurrenceMonth===occurrence.occurrenceKey&&t.status!=='cancelled'&&t.deletedAt==null)&&Number.isFinite(occurrence.amount)&&occurrence.amount>0);
 }));
}
