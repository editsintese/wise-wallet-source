'use client';

import React from 'react';
import { installmentText, TransactionView } from './transaction-model';
import { Chip } from './design-system/chip';

export function TransactionChips({ item, accountName, cardName }: { item: TransactionView; accountName?: string; cardName?: string }) {
  return <div className="transaction-chips">
    <Chip tone="category">{item.category || 'Sem categoria'}</Chip>
    {item.subcategory?.trim() && <Chip tone="subcategory">{item.subcategory}</Chip>}
    <Chip tone="owner">{item.owner || 'Família'}</Chip>
    <Chip tone="status">
      {item.status === 'planned' ? 'Prevista' : 'Realizada'}
    </Chip>
    {item.accountId && <Chip tone="account">{accountName || 'Conta'}</Chip>}
    {item.cardId && <Chip tone="payment">{cardName || 'Cartão'}</Chip>}
    {item.historicalOnly && <Chip tone="neutral">Somente histórico · sem impacto no saldo</Chip>}
    <Chip tone="neutral">{installmentText(item)}</Chip>
  </div>;
}
