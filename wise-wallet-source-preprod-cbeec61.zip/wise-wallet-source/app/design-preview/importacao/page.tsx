import { notFound } from 'next/navigation';
import { SyntheticImportPreview } from '../../synthetic-import-preview';
import { PreviewShell } from '../preview-shell';

export default function ImportPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();

  return <PreviewShell active="Importação"><SyntheticImportPreview /></PreviewShell>;
}
