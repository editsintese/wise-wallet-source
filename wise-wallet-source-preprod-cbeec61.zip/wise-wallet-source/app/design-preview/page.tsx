import { notFound } from 'next/navigation';
import { MonthlyOverview } from '../monthly-overview';
import { PreviewShell } from './preview-shell';
import { previewAccounts, previewCards, previewInvestments, previewRecurrences, previewTransactions } from './preview-data';

export default function DesignPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();

  return <PreviewShell active="Visão geral">
    <main aria-labelledby="design-preview-page-title">
      <h1 className="design-preview-visually-hidden" id="design-preview-page-title">Visão geral</h1>
      <MonthlyOverview
        accounts={previewAccounts}
        balances={new Map([['preview-main', 3275.5], ['preview-savings', 6800]])}
        transactions={previewTransactions}
        cardPayments={[]}
        cards={previewCards}
        recurrences={previewRecurrences}
        investments={previewInvestments}
      />
    </main>
  </PreviewShell>;
}
