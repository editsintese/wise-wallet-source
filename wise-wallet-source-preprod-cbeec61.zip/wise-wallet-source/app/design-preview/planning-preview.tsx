function ForecastIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M4 19V5M4 19h17"/><path d="m7 15 4-4 3 2 5-6"/><path d="M16 7h3v3"/>
  </svg>;
}

const forecast = [
  { month: 'Set 2026', baseline: 'R$ 10.075,50', installment: '—', withPurchase: 'R$ 10.075,50' },
  { month: 'Out 2026', baseline: 'R$ 9.780,00', installment: 'R$ 400,00', withPurchase: 'R$ 9.380,00' },
  { month: 'Nov 2026', baseline: 'R$ 10.450,00', installment: 'R$ 400,00', withPurchase: 'R$ 10.050,00' },
  { month: 'Dez 2026', baseline: 'R$ 12.300,00', installment: 'R$ 400,00', withPurchase: 'R$ 11.900,00' },
  { month: 'Jan 2027', baseline: 'R$ 11.950,00', installment: '—', withPurchase: 'R$ 11.950,00' },
  { month: 'Fev 2027', baseline: 'R$ 12.600,00', installment: '—', withPurchase: 'R$ 12.600,00' },
];

const goals = [
  { name: 'Reserva de emergência', current: 'R$ 6.800,00', target: 'R$ 15.000,00', percent: 45 },
  { name: 'Viagem em família', current: 'R$ 2.400,00', target: 'R$ 6.000,00', percent: 40 },
];

export function PlanningPreview() {
  return <main className="planning-preview" aria-labelledby="planning-preview-title">
    <header className="planning-preview-heading">
      <div className="planning-preview-heading-icon"><ForecastIcon /></div>
      <div className="planning-preview-heading-copy"><h1 id="planning-preview-title">Planejamento</h1><p>Projete o caixa e teste decisões sem criar lançamentos.</p></div>
      <label className="planning-preview-month">Mês de referência<input type="month" value="2026-09" readOnly aria-label="Mês de referência da prévia" /></label>
    </header>

    <section className="planning-preview-summary" aria-label="Resumo do planejamento">
      <article className="highlight"><span>Saldo projetado em setembro</span><strong>R$ 10.075,50</strong></article>
      <article><span>Menor saldo nos próximos 6 meses</span><strong>R$ 9.380,00</strong></article>
      <article><span>Saldo disponível atual</span><strong>R$ 10.075,50</strong></article>
    </section>

    <div className="planning-preview-sections">
      <section className="planning-preview-panel goals" aria-labelledby="planning-preview-goals-title">
        <header><div><h2 id="planning-preview-goals-title">Metas financeiras</h2><p>Reserva e investimento</p></div><span className="planning-preview-count">2 metas</span></header>
        <div className="planning-preview-goals-list">
          {goals.map((goal) => <article className="planning-preview-goal" key={goal.name}>
            <div className="planning-preview-goal-title"><div><h3>{goal.name}</h3><span>{goal.current} de {goal.target}</span></div><strong>{goal.percent}%</strong></div>
            <div className="planning-preview-progress" role="img" aria-label={`${goal.percent}% da meta atingida`}><span style={{ width: `${goal.percent}%` }} /></div>
          </article>)}
        </div>
        <p className="planning-preview-fake-data">Metas e valores ilustrativos nesta prévia.</p>
      </section>

      <section className="planning-preview-panel simulator" aria-labelledby="planning-preview-simulator-title">
        <header><div><h2 id="planning-preview-simulator-title">Essa compra cabe no fluxo?</h2><p>Simulação sem criar um lançamento.</p></div><span className="planning-preview-sim-tag">Somente simulação</span></header>
        <div className="planning-preview-inputs" aria-label="Parâmetros ilustrativos da compra">
          <label>Valor total<input value="R$ 1.200,00" readOnly /></label>
          <label>Parcelas<input value="3" readOnly /></label>
          <label>Primeira parcela<input value="01 out 2026" readOnly /></label>
        </div>
        <div className="planning-preview-diagnosis"><strong>A compra cabe no fluxo projetado</strong><span>3 parcelas de R$ 400,00 · menor saldo: R$ 9.380,00</span></div>
        <div className="planning-preview-table-wrap">
          <table>
            <thead><tr><th scope="col">Mês</th><th scope="col">Saldo sem compra</th><th scope="col">Parcela</th><th scope="col">Saldo com compra</th></tr></thead>
            <tbody>{forecast.map((row) => <tr key={row.month}><th scope="row">{row.month}</th><td data-label="Saldo sem compra">{row.baseline}</td><td data-label="Parcela">{row.installment}</td><td data-label="Saldo com compra">{row.withPurchase}</td></tr>)}</tbody>
          </table>
        </div>
      </section>
    </div>
    <p className="planning-preview-note">Dados fictícios para referência visual. Os valores não alteram o caixa nem criam lançamentos.</p>
  </main>;
}
