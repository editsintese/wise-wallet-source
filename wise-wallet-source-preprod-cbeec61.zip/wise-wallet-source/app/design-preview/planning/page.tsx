import { notFound } from 'next/navigation';
import { PlanningPreview } from '../planning-preview';
import { PreviewShell } from '../preview-shell';

export default function PlanningPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();
  return <PreviewShell active="Planejamento"><PlanningPreview /></PreviewShell>;
}
