function CardIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="3" y="5" width="18" height="14" rx="1"/><path d="M3 9h18M7 15h4"/>
  </svg>;
}

const cards = [
  {
    name: 'Cartão cotidiano', holder: 'Família', ending: '•• 2048', color: 'blue',
    limit: 'R$ 8.000,00', used: 'R$ 3.900,00', available: 'R$ 4.100,00', percent: 49,
    closing: '25 set', due: '05 out', invoice: 'R$ 1.820,40',
  },
  {
    name: 'Cartão viagens', holder: 'Pessoa 1', ending: '•• 7316', color: 'purple',
    limit: 'R$ 5.000,00', used: 'R$ 1.240,00', available: 'R$ 3.760,00', percent: 25,
    closing: '15 set', due: '20 out', invoice: 'R$ 580,00',
  },
];

const purchases = [
  { title: 'Mercado da semana', card: 'Cartão cotidiano', category: 'Alimentação · 12 set', due: '05 out', amount: 'R$ 286,40', status: 'Prevista' },
  { title: 'Itens para casa', card: 'Cartão cotidiano', category: 'Casa · 14 set', due: '05 out', amount: 'R$ 1.440,80', status: 'Prevista' },
  { title: 'Farmácia', card: 'Cartão cotidiano', category: 'Saúde · 18 set', due: '05 out', amount: 'R$ 93,20', status: 'Prevista' },
  { title: 'Reserva da viagem', card: 'Cartão viagens', category: 'Viagens · parcela 2 de 6', due: '20 out', amount: 'R$ 580,00', status: 'Prevista' },
];

export function CardsPreview() {
  return <main className="cards-preview" aria-labelledby="cards-preview-title">
    <header className="cards-preview-heading">
      <div className="cards-preview-heading-icon"><CardIcon /></div>
      <div><h1 id="cards-preview-title">Cartões</h1><p>Acompanhe limites, faturas e compras da família.</p></div>
      <span className="cards-preview-count">2 cartões</span>
    </header>

    <section className="cards-preview-grid" aria-label="Resumo dos cartões">
      {cards.map((card) => <article className={`cards-preview-item ${card.color}`} key={card.name}>
        <div className="cards-preview-item-heading">
          <div className="cards-preview-item-icon"><CardIcon /></div>
          <div className="cards-preview-title-group"><span>{card.holder} · {card.ending}</span><h2>{card.name}</h2></div>
          <span className="cards-preview-demo-chip">Prévia</span>
        </div>
        <div className="cards-preview-limit-heading"><span>Limite utilizado</span><strong>{card.percent}%</strong></div>
        <div className="cards-preview-progress" role="img" aria-label={`${card.percent}% do limite utilizado`}><span style={{ width: `${card.percent}%` }} /></div>
        <dl className="cards-preview-values">
          <div><dt>Limite total</dt><dd>{card.limit}</dd></div>
          <div><dt>Utilizado</dt><dd>{card.used}</dd></div>
          <div><dt>Disponível</dt><dd>{card.available}</dd></div>
        </dl>
        <div className="cards-preview-invoice">
          <div><span>Fatura em aberto</span><small>Fecha {card.closing} · vence {card.due}</small></div>
          <strong>{card.invoice}</strong>
        </div>
      </article>)}
    </section>

    <section className="cards-preview-purchases" aria-labelledby="cards-preview-purchases-title">
      <header className="cards-preview-section-heading">
        <div><h2 id="cards-preview-purchases-title">Compras nas próximas faturas</h2><p>Valores ilustrativos para esta prévia.</p></div>
        <span className="cards-preview-count">4 lançamentos</span>
      </header>
      <div className="cards-preview-table-wrap">
        <table>
          <thead><tr><th scope="col">Compra</th><th scope="col">Cartão</th><th scope="col">Fatura</th><th scope="col">Valor</th><th scope="col">Situação</th></tr></thead>
          <tbody>{purchases.map((purchase) => <tr key={purchase.title}>
            <td data-label="Compra"><strong>{purchase.title}</strong><small>{purchase.category}</small></td>
            <td data-label="Cartão">{purchase.card}</td>
            <td data-label="Fatura">{purchase.due}</td>
            <td data-label="Valor" className="cards-preview-purchase-value">{purchase.amount}</td>
            <td data-label="Situação"><span className="cards-preview-status">{purchase.status}</span></td>
          </tr>)}</tbody>
        </table>
      </div>
    </section>
    <p className="cards-preview-note">Os dados desta tela são fictícios e não alteram cartões, compras ou faturas.</p>
  </main>;
}
