import { notFound } from 'next/navigation';
import { TransactionsPreview } from '../transactions-preview';

export default function TransactionsPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();

  return <TransactionsPreview />;
}
