const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

type CalendarEvent = { title: string; amount: number; kind: 'income' | 'expense'; source: 'transaction' | 'recurrence' | 'invoice'; meta: string; status: string };

const eventsByDay: Record<number, CalendarEvent[]> = {
  2: [{ title: 'Salário', amount: 3500, kind: 'income', source: 'transaction', meta: 'Lançamento · 02 set.', status: 'Realizada' }],
  5: [{ title: 'Aluguel', amount: 1550, kind: 'expense', source: 'recurrence', meta: 'Recorrência mensal', status: 'Prevista' }],
  8: [{ title: 'Internet residencial', amount: 120, kind: 'expense', source: 'recurrence', meta: 'Recorrência mensal', status: 'Liquidada' }],
  10: [{ title: 'Fatura Cartão cotidiano', amount: 1240, kind: 'expense', source: 'invoice', meta: 'Vencimento de fatura', status: 'Em aberto' }],
  12: [{ title: 'Mercado', amount: 820, kind: 'expense', source: 'transaction', meta: 'Lançamento · 12 set.', status: 'Realizada' }],
  15: [
    { title: 'Mensalidade escolar', amount: 450, kind: 'expense', source: 'transaction', meta: 'Lançamento · 15 set.', status: 'Realizada' },
    { title: 'Energia elétrica', amount: 168, kind: 'expense', source: 'recurrence', meta: 'Recorrência mensal', status: 'Prevista' },
    { title: 'Renda complementar', amount: 1300, kind: 'income', source: 'transaction', meta: 'Lançamento · 15 set.', status: 'Realizada' },
  ],
  20: [{ title: 'Combustível', amount: 290, kind: 'expense', source: 'transaction', meta: 'Lançamento · 20 set.', status: 'Realizada' }],
  23: [{ title: 'Fatura Cartão viagens', amount: 580, kind: 'expense', source: 'invoice', meta: 'Vencimento de fatura', status: 'Liquidada' }],
  28: [{ title: 'Consulta médica', amount: 250, kind: 'expense', source: 'transaction', meta: 'Lançamento · 28 set.', status: 'Prevista' }],
  30: [{ title: 'Jantar em família', amount: 160, kind: 'expense', source: 'transaction', meta: 'Lançamento · 30 set.', status: 'Realizada' }],
};

const weekdays = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
const days = Array.from({ length: 30 }, (_, index) => index + 1);
const selectedDay = 15;

function EventMarker({ event }: { event: CalendarEvent }) {
  return <i className={`calendar-preview-marker ${event.kind} source-${event.source}`} aria-hidden="true" />;
}

export function CalendarPreview() {
  const selectedEvents = eventsByDay[selectedDay];
  return <main className="calendar-preview" aria-labelledby="calendar-preview-title">
    <header className="calendar-preview-heading">
      <div className="calendar-preview-heading-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="16" rx="1"/><path d="M7 3v4M17 3v4M3 10h18M7 14h.01M12 14h.01M17 14h.01M7 17h.01M12 17h.01"/></svg></div>
      <div><p>FLUXO NO TEMPO</p><h1 id="calendar-preview-title">Calendário de movimentações</h1><span>Veja compras, recorrências e faturas na data certa.</span></div>
      <div className="calendar-preview-navigation"><button disabled aria-label="Mês anterior"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2"><path d="m12 4-6 6 6 6"/></svg></button><strong>Setembro de 2026</strong><button disabled aria-label="Próximo mês"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2"><path d="m8 4 6 6-6 6"/></svg></button></div>
    </header>

    <section className="calendar-preview-month" aria-label="Calendário de setembro de 2026">
      <div className="calendar-preview-legend"><span><i className="income"/>Entrada</span><span><i className="expense"/>Saída</span><span><i className="invoice"/>Fatura</span><span><i className="recurrence"/>Recorrência</span></div>
      <div className="calendar-preview-weekdays">{weekdays.map((weekday) => <span key={weekday}>{weekday}</span>)}</div>
      <div className="calendar-preview-grid">
        <span className="empty" aria-hidden="true" />
        {days.map((day) => {
          const events = eventsByDay[day] || [];
          const eventNames = events.map((event) => event.title).join(', ');
          return <button type="button" disabled key={day} className={`calendar-preview-day ${day === selectedDay ? 'selected' : ''}`} aria-label={`${day} de setembro de 2026, ${events.length} evento(s)${eventNames ? `: ${eventNames}` : ''}`}>
            <strong>{day}</strong>
            <span className="calendar-preview-markers">{events.slice(0, 3).map((event, index) => <EventMarker key={`${event.title}-${index}`} event={event}/>)}</span>
            {events.length > 3 && <small>+{events.length - 3}</small>}
          </button>;
        })}
        {Array.from({ length: 4 }, (_, index) => <span className="empty" aria-hidden="true" key={`end-${index}`} />)}
      </div>
      <p className="calendar-preview-caption">Os marcadores indicam o tipo de evento; selecione um dia na tela real para ver os detalhes.</p>
    </section>

    <section className="calendar-preview-details" aria-labelledby="calendar-preview-details-title">
      <header><div><p>DETALHE DO DIA</p><h2 id="calendar-preview-details-title">Terça-feira, 15 de setembro</h2></div><span>{selectedEvents.length} eventos</span></header>
      <ul>{selectedEvents.map((event) => <li key={event.title}>
        <EventMarker event={event}/>
        <div className="calendar-preview-event-copy"><strong>{event.title}</strong><span>{event.meta}</span></div>
        <span className={`calendar-preview-status ${event.status.toLowerCase().replaceAll(' ', '-')}`}>{event.status}</span>
        <strong className={event.kind}>{event.kind === 'income' ? '+' : '−'}{money.format(event.amount)}</strong>
      </li>)}</ul>
    </section>
    <p className="calendar-preview-note">Dados fictícios. Navegação entre meses e seleção de dias estão desativadas nesta prévia.</p>
  </main>;
}
