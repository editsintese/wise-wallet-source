import { notFound } from 'next/navigation';
import { RecurrencesPreview } from '../recurrences-preview';
import { PreviewShell } from '../preview-shell';

export default function RecurrencesPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();
  return <PreviewShell active="Recorrências"><RecurrencesPreview /></PreviewShell>;
}
