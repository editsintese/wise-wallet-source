import { notFound } from 'next/navigation';
import { AccountsPreview } from '../accounts-preview';

export default function AccountsPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();
  return <AccountsPreview />;
}
