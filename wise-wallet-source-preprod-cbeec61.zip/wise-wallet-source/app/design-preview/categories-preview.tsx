const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

const categories = [
  { name: 'Alimentação', type: 'Opção inicial' }, { name: 'Casa', type: 'Opção inicial' },
  { name: 'Compras', type: 'Opção inicial' }, { name: 'Educação', type: 'Personalizado' },
  { name: 'Outros', type: 'Opção inicial' }, { name: 'Pets', type: 'Opção inicial' },
  { name: 'Receita', type: 'Opção inicial' }, { name: 'Saúde', type: 'Opção inicial' },
  { name: 'Sem categoria', type: 'Opção inicial' }, { name: 'Transporte', type: 'Opção inicial' },
  { name: 'Viagens', type: 'Arquivado' },
];

const responsibles = [
  { name: 'Família', type: 'Opção inicial' }, { name: 'Pessoa 2', type: 'Opção inicial' },
  { name: 'Pessoa 1', type: 'Opção inicial' }, { name: 'Filhos', type: 'Personalizado' },
];

const budgets = [
  { name: 'Alimentação', limit: 1500, spent: 1240, rows: [{ name: 'Mercado', amount: 820 }, { name: 'Feira', amount: 260 }, { name: 'Refeições', amount: 160 }] },
  { name: 'Casa', limit: 2000, spent: 1670, rows: [{ name: 'Aluguel', amount: 1550 }, { name: 'Internet', amount: 120 }] },
  { name: 'Educação', limit: 600, spent: 450, rows: [{ name: 'Mensalidade escolar', amount: 450 }] },
  { name: 'Pets', limit: 350, spent: 410, rows: [{ name: 'Veterinário', amount: 410 }] },
];

function ReferencePanel({ title, description, kind, items }: { title: string; description: string; kind: 'category' | 'owner'; items: typeof categories }) {
  const activeCount = items.filter((item) => item.type !== 'Arquivado').length;
  return <section className={`categories-preview-reference ${kind}`}>
    <header><div><h2>{title}</h2><p>{description}</p></div><span>{activeCount} ativas</span></header>
    <form className="categories-preview-add"><label><span>Novo nome</span><input disabled value={kind === 'category' ? 'Ex.: Educação' : 'Ex.: Filho'} readOnly /></label><button type="button" disabled>Adicionar</button></form>
    <ul>{items.map((item) => <li key={item.name} className={item.type === 'Arquivado' ? 'archived' : ''}>
      <i className="categories-preview-dot" aria-hidden="true" />
      <div className="categories-preview-reference-copy">
        <strong>{item.name}</strong>
        <span className={`categories-preview-chip ${item.type === 'Arquivado' ? 'archived' : item.type === 'Personalizado' ? 'custom' : ''}`}>{item.type}</span>
      </div>
      <div className="categories-preview-reference-actions"><button disabled>Editar</button><button disabled>{item.type === 'Arquivado' ? 'Restaurar' : 'Arquivar'}</button></div>
    </li>)}</ul>
  </section>;
}

export function CategoriesPreview() {
  return <main className="categories-preview" aria-labelledby="categories-preview-title">
    <header className="categories-preview-heading">
      <div className="categories-preview-heading-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M4 5h16M4 12h16M4 19h16"/><circle cx="8" cy="5" r="2" fill="currentColor"/><circle cx="15" cy="12" r="2" fill="currentColor"/><circle cx="10" cy="19" r="2" fill="currentColor"/></svg></div>
      <div><p>CATEGORIAS E PLANEJAMENTO</p><h1 id="categories-preview-title">Organize a vida financeira</h1><span>Gerencie categorias, responsáveis e limites mensais num só lugar.</span></div>
    </header>

    <section className="categories-preview-reference-grid" aria-label="Cadastros de categorias e responsáveis">
      <ReferencePanel title="Categorias" description="Agrupam receitas e despesas nos filtros e relatórios." kind="category" items={categories} />
      <ReferencePanel title="Responsáveis" description="Identificam quem realizou ou acompanha cada lançamento." kind="owner" items={responsibles} />
    </section>

    <section className="categories-preview-budgets" aria-labelledby="categories-preview-budget-title">
      <header><div><p>ORÇAMENTOS MENSAIS</p><h2 id="categories-preview-budget-title">Orçamentos por categoria</h2><span>Limites mensais por subcategoria, separados das recorrências.</span></div><label>Mês<input type="month" disabled value="2026-09" readOnly /></label></header>
      <div className="categories-preview-budget-grid">{budgets.map((budget) => {
        const percent = Math.round(budget.spent / budget.limit * 100);
        const over = budget.spent > budget.limit;
        const detail = over ? `${percent}% utilizado; ${money.format(budget.spent - budget.limit)} acima do limite` : `${percent}% utilizado; ${money.format(budget.limit - budget.spent)} restante`;
        return <article className={`categories-preview-budget ${over ? 'over' : ''}`} key={budget.name}>
          <div className="categories-preview-budget-title"><div><h3>{budget.name}</h3><span>{budget.rows.length} {budget.rows.length === 1 ? 'subcategoria' : 'subcategorias'}</span></div><strong>{money.format(budget.limit)}</strong></div>
          <div className="categories-preview-progress" role="progressbar" aria-label={`Uso do orçamento de ${budget.name}`} aria-valuemin={0} aria-valuemax={budget.limit} aria-valuenow={Math.min(budget.limit, budget.spent)} aria-valuetext={detail}><span style={{ width: `${Math.min(100, percent)}%` }} /></div>
          <div className="categories-preview-budget-meta"><span>{money.format(budget.spent)} usado</span><strong>{over ? `${money.format(budget.spent - budget.limit)} acima` : `${money.format(budget.limit - budget.spent)} restante`}</strong></div>
          <ul>{budget.rows.map((row) => <li key={row.name}><span>{row.name}</span><strong>{money.format(row.amount)}</strong><button disabled aria-label={`Editar subcategoria ${row.name}`}>Editar</button></li>)}</ul>
          <button className="categories-preview-add-subcategory" disabled>+ Adicionar subcategoria</button>
        </article>;
      })}</div>
    </section>
    <p className="categories-preview-note">Dados fictícios. Controles de cadastro e orçamento estão desativados nesta prévia.</p>
  </main>;
}
