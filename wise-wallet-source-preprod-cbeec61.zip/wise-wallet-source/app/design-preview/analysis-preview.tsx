const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const chartColors = [
  'var(--preview-series-blue)',
  'var(--preview-series-purple)',
  'var(--preview-series-gold)',
  'var(--preview-series-teal)',
  'var(--preview-series-coral)',
  'var(--preview-series-green)',
];

const monthly = [
  { month: 'Abr', year: '2026', income: 4800, expense: 3900 },
  { month: 'Mai', year: '2026', income: 4700, expense: 4150 },
  { month: 'Jun', year: '2026', income: 5200, expense: 3600 },
  { month: 'Jul', year: '2026', income: 4900, expense: 3980 },
  { month: 'Ago', year: '2026', income: 4850, expense: 4010 },
  { month: 'Set', year: '2026', income: 4800, expense: 2820 },
];
const categories = [
  { name: 'Alimentação', value: 7200 }, { name: 'Casa', value: 6300 }, { name: 'Transporte', value: 3450 },
  { name: 'Saúde', value: 2510 }, { name: 'Lazer', value: 1800 }, { name: 'Outros', value: 1200 },
];
const owners = [{ name: 'Pessoa 1', value: 11700 }, { name: 'Pessoa 2', value: 8760 }, { name: 'Família', value: 2000 }];
const totalIncome = 29250;
const totalExpense = 22460;
const totalResult = totalIncome - totalExpense;

function RankingPanel({ title, eyebrow, items }: { title: string; eyebrow: string; items: Array<{ name: string; value: number }> }) {
  const max = items[0]?.value || 1;
  return <section className="analysis-preview-panel" aria-label={title}>
    <header><div><span>{eyebrow}</span><h3>{title}</h3></div><span className="analysis-preview-count">{items.length} itens</span></header>
    <ol>{items.map((item, index) => <li key={item.name}>
      <div className="analysis-preview-rank-line"><span><i style={{ background: chartColors[index % chartColors.length] }} aria-hidden="true" />{item.name}</span><strong>{money.format(item.value)}</strong></div>
      <div className="analysis-preview-rank-bar" role="img" aria-label={`${item.name}: ${money.format(item.value)}`}><span style={{ width: `${Math.max(4, item.value / max * 100)}%`, background: chartColors[index % chartColors.length] }} /></div>
    </li>)}</ol>
  </section>;
}

function DonutPanel({ title, eyebrow, items }: { title: string; eyebrow: string; items: Array<{ name: string; value: number }> }) {
  const total = items.reduce((sum, item) => sum + item.value, 0);
  let cursor = 0;
  const slices = items.map((item, index) => {
    const start = cursor;
    cursor += total ? item.value / total * 100 : 0;
    return `${chartColors[index % chartColors.length]} ${start}% ${cursor}%`;
  });
  return <section className="analysis-preview-panel analysis-preview-donut" aria-label={title}>
    <header><div><span>{eyebrow}</span><h3>{title}</h3></div></header>
    {items.length ? <div className="analysis-preview-donut-body">
      <div className="analysis-preview-donut-graphic" aria-hidden="true" style={{ background: `conic-gradient(${slices.join(', ')})` }}><span><strong>{money.format(total)}</strong><small>Total</small></span></div>
      <ul>{items.map((item, index) => <li key={item.name}><i style={{ background: chartColors[index % chartColors.length] }} aria-hidden="true"/><span>{item.name}</span><strong>{total ? Math.round(item.value / total * 100) : 0}%</strong><small>{money.format(item.value)}</small></li>)}</ul>
    </div> : <p>Sem despesas para analisar.</p>}
  </section>;
}

export function AnalysisPreview() {
  const chartMax = Math.max(...monthly.flatMap((row) => [row.income, row.expense]));
  return <main className="analysis-preview" aria-labelledby="analysis-preview-title">
    <header className="analysis-preview-heading">
      <div className="analysis-preview-heading-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M4 19V5M4 19h17"/><rect x="7" y="12" width="3" height="4"/><rect x="12" y="9" width="3" height="7"/><rect x="17" y="6" width="3" height="10"/></svg></div>
      <div className="analysis-preview-heading-copy"><h1 id="analysis-preview-title">Análises</h1><p>Leitura por competência da fatura, no período selecionado.</p></div>
      <label className="analysis-preview-period">Período<select disabled defaultValue="6"><option value="6">Últimos 6 meses</option></select></label>
    </header>

    <section className="analysis-preview-filters" aria-label="Filtros da prévia">
      <label><span>Movimentação</span><select disabled defaultValue="all"><option value="all">Entradas e saídas</option></select></label>
      <label><span>Categoria</span><select disabled defaultValue="all"><option value="all">Todas categorias</option></select></label>
      <label><span>Responsável</span><select disabled defaultValue="all"><option value="all">Todos responsáveis</option></select></label>
    </section>

    <section className="analysis-preview-summary" aria-label="Totais do período de abril a setembro de 2026">
      <article><span>Entradas no período</span><strong className="income">{money.format(totalIncome)}</strong></article>
      <article><span>Saídas no período</span><strong className="expense">{money.format(totalExpense)}</strong></article>
      <article className="highlight"><span>Resultado</span><strong className="income">+{money.format(totalResult)}</strong></article>
    </section>

    <section className="analysis-preview-panel analysis-preview-flow" aria-labelledby="analysis-preview-flow-title">
      <header><div><span>FLUXO MENSAL</span><h2 id="analysis-preview-flow-title">Entradas x saídas</h2></div><div className="analysis-preview-legend"><span><i className="income"/>Entradas</span><span><i className="expense"/>Saídas</span></div></header>
      <div className="analysis-preview-chart" role="list" aria-label="Comparativo mensal entre entradas e saídas">
        {monthly.map((row) => <div className="analysis-preview-month" role="listitem" aria-label={`${row.month} ${row.year}: entradas ${money.format(row.income)}, saídas ${money.format(row.expense)}`} key={row.month}>
          <div className="analysis-preview-bars" aria-hidden="true"><span className="income" style={{ height: `${row.income / chartMax * 100}%` }}/><span className="expense" style={{ height: `${row.expense / chartMax * 100}%` }}/></div>
          <span>{row.month}</span>
        </div>)}
      </div>
      <p className="analysis-preview-chart-caption">Abril a setembro de 2026 · valores por competência.</p>
    </section>

    <div className="analysis-preview-grid">
      <RankingPanel title="Por categoria" eyebrow="DESPESAS" items={categories}/>
      <RankingPanel title="Por responsável" eyebrow="DISTRIBUIÇÃO" items={owners}/>
    </div>
    <div className="analysis-preview-grid">
      <DonutPanel title="Despesas por categoria" eyebrow="CATEGORIAS" items={categories}/>
      <DonutPanel title="Despesas por responsável" eyebrow="RESPONSÁVEIS" items={owners}/>
    </div>
    <section className="analysis-preview-alert"><strong>Fluxo positivo</strong><span>As entradas superam as saídas no período filtrado. Maior categoria de despesa: Alimentação.</span></section>
    <p className="analysis-preview-note">Números fictícios para referência visual. Filtros e análises não acessam nem alteram dados financeiros reais.</p>
  </main>;
}
