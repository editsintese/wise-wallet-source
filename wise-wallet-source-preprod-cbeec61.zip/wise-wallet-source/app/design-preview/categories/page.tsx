import { notFound } from 'next/navigation';
import { CategoriesPreview } from '../categories-preview';
import { PreviewShell } from '../preview-shell';

export default function CategoriesPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();
  return <PreviewShell active="Categorias"><CategoriesPreview /></PreviewShell>;
}
