import type { BulkItem } from '../bulk-transactions';

export const previewAccounts = [
  { id: 'preview-main', name: 'Conta do dia a dia', type: 'Corrente', openingBalance: 3275.5 },
  { id: 'preview-savings', name: 'Reserva da família', type: 'Poupança', openingBalance: 6800 },
];

export const previewCards = [
  { id: 'preview-card', name: 'Cartão cotidiano', closingDay: 25, dueDay: 5, accountId: 'preview-main' },
  { id: 'preview-travel', name: 'Cartão viagens', closingDay: 15, dueDay: 20, accountId: 'preview-main' },
];

export const previewTransactions: BulkItem[] = [
  { id: 'preview-grocery', description: 'Mercado da semana', amount: 286.4, kind: 'expense', status: 'planned', rawDate: '2026-10-05', purchaseDate: '2026-09-12', cardId: 'preview-card', accountId: 'preview-main', category: 'Alimentação', owner: 'Família' },
  { id: 'preview-travel-purchase', description: 'Reserva da viagem', amount: 580, kind: 'expense', status: 'planned', rawDate: '2026-09-20', purchaseDate: '2026-09-20', cardId: 'preview-travel', accountId: 'preview-main', category: 'Viagens', owner: 'Pessoa 1', installmentNumber: 2, installmentCount: 6, installmentGroupId: 'preview-trip' },
  { id: 'preview-health', description: 'Consulta médica', amount: 180, kind: 'expense', status: 'planned', rawDate: '2026-09-18', accountId: 'preview-main', category: 'Saúde', owner: 'Pessoa 2' },
  { id: 'preview-income', description: 'Renda mensal', amount: 4200, kind: 'income', status: 'realized', rawDate: '2026-09-05', paidAt: '2026-09-05', accountId: 'preview-main', category: 'Renda', owner: 'Pessoa 1' },
];

export const previewRecurrences = [
  { id: 'preview-internet', description: 'Internet da casa', amount: 120, kind: 'expense' as const, startDate: '2026-01-01', dueDay: 28, accountId: 'preview-main', category: 'Internet', active: true },
  { id: 'preview-home-insurance', description: 'Seguro residencial', amount: 85, kind: 'expense' as const, startDate: '2026-01-01', dueDay: 30, accountId: 'preview-main', category: 'Segurança', active: true },
];

export const previewInvestments = [
  { id: 'preview-investment', name: 'Reserva de emergência', institution: 'Banco exemplo', type: 'CDB', currentValue: 6800, referenceDate: '2026-09-01' },
];
