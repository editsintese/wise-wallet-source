function InvestmentIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M4 19V5M4 19h17"/><path d="m7 15 3-3 3 2 5-7"/><path d="M15 7h3v3"/>
  </svg>;
}

const positions = [
  { name: 'CDB liquidez diária', institution: 'Banco Sol', type: 'CDB', current: 'R$ 6.420,00', reference: '01 set 2026' },
  { name: 'Tesouro Selic 2029', institution: 'Tesouro Direto', type: 'Tesouro Direto', current: 'R$ 3.620,50', reference: '01 set 2026' },
  { name: 'Fundo renda fixa', institution: 'Banco Sol', type: 'Fundo', current: 'R$ 1.760,00', reference: '30 ago 2026' },
];

export function InvestmentsPreview() {
  return <main className="investments-preview" aria-labelledby="investments-preview-title">
    <header className="investments-preview-heading">
      <div className="investments-preview-heading-icon"><InvestmentIcon /></div>
      <div className="investments-preview-heading-copy"><h1 id="investments-preview-title">Investimentos</h1><p>Acompanhe aportes, patrimônio e suas posições.</p></div>
      <button type="button" disabled aria-label="Adicionar posição indisponível na prévia">+ Adicionar posição</button>
    </header>

    <section className="investments-preview-summary" aria-label="Resumo dos investimentos">
      <article className="highlight"><span>Patrimônio investido</span><strong>R$ 11.800,50</strong></article>
      <article><span>Valor aportado</span><strong>R$ 11.300,00</strong></article>
      <article><span>Resultado</span><strong className="gain">+R$ 500,50</strong></article>
    </section>

    <section className="investments-preview-list" aria-labelledby="investments-preview-list-title">
      <header><div><h2 id="investments-preview-list-title">Carteira por instituição</h2><p>Posições atuais · atualizadas em setembro de 2026</p></div><span className="investments-preview-count">3 posições</span></header>
      <div className="investments-preview-rows">
        {positions.map((position) => <article className="investments-preview-row" key={position.name}>
          <div className="investments-preview-position">
            <span className="investments-preview-position-icon"><InvestmentIcon /></span>
            <div className="investments-preview-copy"><h3>{position.name}</h3><div className="investments-preview-tags"><span>{position.institution}</span><span>{position.type}</span></div><small>Atualizado em {position.reference}</small></div>
          </div>
          <strong className="investments-preview-value">{position.current}</strong>
          <div className="investments-preview-actions" aria-label={`Ações indisponíveis para ${position.name}`}>
            <button type="button" disabled>Atualizar</button><button type="button" disabled>Excluir</button>
          </div>
        </article>)}
      </div>
    </section>
    <p className="investments-preview-note">Valores fictícios para referência visual. As ações de aporte, resgate e atualização não estão disponíveis nesta prévia.</p>
  </main>;
}
