function RepeatIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9a7 7 0 0 1 11.9-2L20 12M4 12l2.5 5a7 7 0 0 0 11.9-2"/>
  </svg>;
}

const recurrences = [
  { description: 'Internet da casa', category: 'Casa', frequency: 'Todo mês', dueDay: '28', amount: '−R$ 120,00', kind: 'expense', owner: 'Família', source: 'Conta do dia a dia', status: 'Pendente neste mês', statusKind: 'pending' },
  { description: 'Seguro residencial', category: 'Proteção', frequency: 'Todo mês', dueDay: '30', amount: '−R$ 85,00', kind: 'expense', owner: 'Família', source: 'Conta do dia a dia', status: 'Pendente neste mês', statusKind: 'pending' },
  { description: 'Renda mensal', category: 'Renda', frequency: 'Todo mês', dueDay: '05', amount: '+R$ 4.200,00', kind: 'income', owner: 'Pessoa 1', source: 'Conta do dia a dia', status: 'Pago neste mês', statusKind: 'settled' },
  { description: 'Aula de música', category: 'Educação', frequency: 'Todo mês', dueDay: '15', amount: '−R$ 159,90', kind: 'expense', owner: 'Pessoa 2', source: 'Cartão cotidiano · fatura', status: 'Lançada na fatura', statusKind: 'invoice' },
];

export function RecurrencesPreview() {
  return <main className="recurrences-preview" aria-labelledby="recurrences-preview-title">
    <header className="recurrences-preview-heading">
      <div className="recurrences-preview-heading-icon"><RepeatIcon /></div>
      <div className="recurrences-preview-heading-copy"><h1 id="recurrences-preview-title">Recorrências</h1><p>Entradas e despesas que se repetem ao longo do ano.</p></div>
      <div className="recurrences-preview-actions">
        <label>Mês<input type="month" value="2026-09" readOnly aria-label="Mês da prévia" /></label>
        <button type="button" disabled aria-label="Criar recorrência indisponível na prévia">+ Nova recorrência</button>
      </div>
    </header>

    <section className="recurrences-preview-summary" aria-label="Resumo de setembro de 2026">
      <div><span>Entradas previstas</span><strong className="income">+R$ 4.200,00</strong></div>
      <div><span>Despesas previstas</span><strong className="expense">−R$ 364,90</strong></div>
      <div><span>Próximos vencimentos</span><strong>28 e 30 set</strong></div>
    </section>

    <section className="recurrences-preview-list" aria-labelledby="recurrences-preview-list-title">
      <header><div><h2 id="recurrences-preview-list-title">Compromissos do mês</h2><p>Setembro de 2026 · 4 recorrências ativas</p></div><span className="recurrences-preview-count">2 pendentes</span></header>
      <div className="recurrences-preview-grid">
        {recurrences.map((item) => <article className="recurrences-preview-item" key={item.description}>
          <div className="recurrences-preview-date" aria-label={`Vencimento dia ${item.dueDay} de setembro`}><strong>{item.dueDay}</strong><span>SET</span></div>
          <div className="recurrences-preview-details">
            <div className="recurrences-preview-title"><div><h3>{item.description}</h3><span>{item.category} · {item.frequency}</span></div><strong className={item.kind}>{item.amount}</strong></div>
            <div className="recurrences-preview-meta"><span>{item.owner}</span><span>{item.source}</span></div>
            <span className={`recurrences-preview-status ${item.statusKind}`}>{item.status}</span>
          </div>
        </article>)}
      </div>
    </section>
    <p className="recurrences-preview-note">Dados fictícios para referência visual. Os controles de criação e baixa ficam inativos nesta prévia.</p>
  </main>;
}
