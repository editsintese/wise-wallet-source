'use client';

import { BulkTransactions } from '../bulk-transactions';
import { PreviewShell } from './preview-shell';
import { previewAccounts, previewCards, previewTransactions } from './preview-data';

export function TransactionsPreview() {
  return <PreviewShell active="Lançamentos">
    <main aria-labelledby="design-preview-page-title">
      <h1 className="design-preview-visually-hidden" id="design-preview-page-title">Lançamentos</h1>
      <BulkTransactions
        items={previewTransactions}
        accounts={previewAccounts}
        cards={previewCards}
        userId="visual-demo"
        stateSection="design-preview-transactions"
        readOnly
        onBatch={() => undefined}
        onEdit={() => undefined}
      />
    </main>
  </PreviewShell>;
}
