import { notFound } from 'next/navigation';
import { CardsPreview } from '../cards-preview';
import { PreviewShell } from '../preview-shell';

export default function CardsPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();
  return <PreviewShell active="Cartões"><CardsPreview /></PreviewShell>;
}
