import type { ReactNode } from 'react';

const destinations = [
  { label: 'Visão geral', href: '/design-preview' },
  { label: 'Lançamentos', href: '/design-preview/transactions' },
  { label: 'Calendário', href: '/design-preview/calendar' },
  { label: 'Contas', href: '/design-preview/accounts' },
  { label: 'Cartões', href: '/design-preview/cards' },
  { label: 'Recorrências', href: '/design-preview/recurrences' },
  { label: 'Planejamento', href: '/design-preview/planning' },
  { label: 'Investimentos', href: '/design-preview/investments' },
  { label: 'Análises', href: '/design-preview/analysis' },
  { label: 'Relatórios', href: '/design-preview/reports' },
  { label: 'Categorias', href: '/design-preview/categories' },
  { label: 'Importação', href: '/design-preview/importacao' },
  { label: 'Mais' },
];

const additionalDestinations = [
  { label: 'Recorrências', href: '/design-preview/recurrences' },
  { label: 'Calendário', href: '/design-preview/calendar' },
  { label: 'Planejamento', href: '/design-preview/planning' },
  { label: 'Investimentos', href: '/design-preview/investments' },
  { label: 'Análises', href: '/design-preview/analysis' },
  { label: 'Relatórios', href: '/design-preview/reports' },
  { label: 'Categorias', href: '/design-preview/categories' },
  { label: 'Importação', href: '/design-preview/importacao' },
];

function PreviewIcon({ name }: { name: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {name === 'Visão geral' && <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></>}
    {name === 'Importação' && <><path d="M12 3v11M8 10l4 4 4-4"/><path d="M5 15v5h14v-5"/></>}
    {name === 'Lançamentos' && <><path d="M7 4h10v16H7z"/><path d="M9.5 8h5M9.5 12h5M9.5 16h3"/></>}
    {name === 'Calendário' && <><rect x="3" y="5" width="18" height="16" rx="1"/><path d="M7 3v4M17 3v4M3 10h18M7 14h.01M12 14h.01M17 14h.01M7 17h.01M12 17h.01"/></>}
    {name === 'Contas' && <><path d="m3 9 9-6 9 6"/><path d="M5 10h14M6 19h12M8 10v8M12 10v8M16 10v8M4 21h16"/></>}
    {name === 'Cartões' && <><rect x="3" y="5" width="18" height="14" rx="1"/><path d="M3 9h18M7 15h4"/></>}
    {name === 'Recorrências' && <><path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9a7 7 0 0 1 11.9-2L20 12M4 12l2.5 5a7 7 0 0 0 11.9-2"/></>}
    {name === 'Planejamento' && <><path d="M4 19V5M4 19h17"/><path d="m7 15 4-4 3 2 5-6"/><path d="M16 7h3v3"/></>}
    {name === 'Investimentos' && <><path d="M4 19V5M4 19h17"/><path d="m7 15 3-3 3 2 5-7"/><path d="M15 7h3v3"/></>}
    {name === 'Análises' && <><path d="M4 19V5M4 19h17"/><rect x="7" y="12" width="3" height="4"/><rect x="12" y="9" width="3" height="7"/><rect x="17" y="6" width="3" height="10"/></>}
    {name === 'Relatórios' && <><path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 12h7M9 16h7"/></>}
    {name === 'Categorias' && <><path d="M4 5h16M4 12h16M4 19h16"/><circle cx="8" cy="5" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="10" cy="19" r="2"/></>}
    {name === 'Mais' && <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>}
  </svg>;
}

export function PreviewShell({ active, children }: { active: string; children: ReactNode }) {
  return <div className="design-preview-shell">
    <aside className="design-preview-sidebar" aria-label="Navegação da prévia">
      <div className="design-preview-brand"><span aria-hidden="true"><svg viewBox="0 0 44 44"><path d="M4 20 22 5l18 15v19H4z" fill="var(--color-text)"/><path d="M14 24h16v15H14z" fill="var(--color-brand)"/><path d="M4 20 22 5l18 15" fill="none" stroke="var(--color-text)" strokeWidth="3"/></svg></span><div><strong>Wise Wallet</strong><small>FINANÇAS EM FAMÍLIA<br/>VIDA COM MAIS PLANO</small></div></div>
      <nav className="design-preview-nav">{destinations.map((item) => item.href ? <a key={item.label} href={item.href} className={item.label === active ? 'active' : ''} aria-current={item.label === active ? 'page' : undefined}><PreviewIcon name={item.label}/><span>{item.label}</span></a> : <span key={item.label} className="preview-nav-unavailable"><PreviewIcon name={item.label}/><span>{item.label}</span></span>)}</nav>
      <div className="design-preview-tagline"><strong>Nossa casa<br/>mais tranquila</strong><span>PLANEJAR<br/>COMPARTILHAR<br/>CONQUISTAR</span></div>
    </aside>
    <div className="design-preview-workspace" tabIndex={0}>
      <header className="design-preview-topbar"><span className="sr-only">Prévia visual com dados fictícios</span><div><button type="button" disabled>Família Oliveira⌄</button><b aria-label="Perfil exemplo">CO</b></div></header>
      <div className={'design-preview-content' + (active === 'Lançamentos' ? ' preview-transactions' : active === 'Calendário' ? ' preview-calendar' : active === 'Contas' ? ' preview-accounts' : active === 'Cartões' ? ' preview-cards' : active === 'Recorrências' ? ' preview-recurrences' : active === 'Planejamento' ? ' preview-planning' : active === 'Investimentos' ? ' preview-investments' : active === 'Análises' ? ' preview-analysis' : active === 'Relatórios' ? ' preview-reports' : active === 'Categorias' ? ' preview-categories' : '')}>{children}</div>
      <nav className="design-preview-mobile-nav" aria-label="Navegação entre prévias">
        <a href="/design-preview" className={active === 'Visão geral' ? 'active' : ''} aria-current={active === 'Visão geral' ? 'page' : undefined}><PreviewIcon name="Visão geral"/><span>Visão geral</span></a>
        <a href="/design-preview/transactions" aria-label="Lançamentos" className={active === 'Lançamentos' ? 'active' : ''} aria-current={active === 'Lançamentos' ? 'page' : undefined}><PreviewIcon name="Lançamentos"/><span>Lançam.</span></a>
        <a href="/design-preview/accounts" className={active === 'Contas' ? 'active' : ''} aria-current={active === 'Contas' ? 'page' : undefined}><PreviewIcon name="Contas"/><span>Contas</span></a>
        <a href="/design-preview/cards" className={active === 'Cartões' ? 'active' : ''} aria-current={active === 'Cartões' ? 'page' : undefined}><PreviewIcon name="Cartões"/><span>Cartões</span></a>
        <details className="design-preview-mobile-more">
          <summary className={additionalDestinations.some((item) => item.label === active) ? 'active' : ''} aria-label="Abrir outras telas da prévia"><PreviewIcon name="Mais"/><span>Mais</span></summary>
          <div className="design-preview-mobile-more-links">
            {additionalDestinations.map((item) => <a key={item.label} href={item.href} aria-current={item.label === active ? 'page' : undefined}>{item.label}</a>)}
          </div>
        </details>
      </nav>
    </div>
  </div>;
}
