import { notFound } from 'next/navigation';
import { CalendarPreview } from '../calendar-preview';
import { PreviewShell } from '../preview-shell';

export default function CalendarPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();
  return <PreviewShell active="Calendário"><CalendarPreview /></PreviewShell>;
}
