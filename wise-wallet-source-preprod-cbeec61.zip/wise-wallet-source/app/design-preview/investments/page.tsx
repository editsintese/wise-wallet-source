import { notFound } from 'next/navigation';
import { InvestmentsPreview } from '../investments-preview';
import { PreviewShell } from '../preview-shell';

export default function InvestmentsPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();
  return <PreviewShell active="Investimentos"><InvestmentsPreview /></PreviewShell>;
}
