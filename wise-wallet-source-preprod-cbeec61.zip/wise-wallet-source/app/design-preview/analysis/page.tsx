import { notFound } from 'next/navigation';
import { AnalysisPreview } from '../analysis-preview';
import { PreviewShell } from '../preview-shell';

export default function AnalysisPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();
  return <PreviewShell active="Análises"><AnalysisPreview /></PreviewShell>;
}
