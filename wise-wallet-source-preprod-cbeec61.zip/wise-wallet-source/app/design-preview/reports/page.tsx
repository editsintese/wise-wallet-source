import { notFound } from 'next/navigation';
import { ReportsPreview } from '../reports-preview';
import { PreviewShell } from '../preview-shell';

export default function ReportsPreviewPage() {
  if (process.env.NODE_ENV !== 'development') notFound();
  return <PreviewShell active="Relatórios"><ReportsPreview /></PreviewShell>;
}
