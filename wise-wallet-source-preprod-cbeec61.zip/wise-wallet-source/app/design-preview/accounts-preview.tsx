'use client';

import { AccountsScreenV2 } from '../accounts-screen';
import { PreviewShell } from './preview-shell';
import { previewAccounts } from './preview-data';

const accountBalances = new Map([
  ['preview-main', 3275.5],
  ['preview-savings', 6800],
]);

const projectedBalances = new Map([
  ['preview-main', 3070.5],
  ['preview-savings', 6800],
]);

export function AccountsPreview() {
  return <PreviewShell active="Contas">
    <main aria-labelledby="design-preview-page-title">
      <h1 className="design-preview-visually-hidden" id="design-preview-page-title">Contas</h1>
      <AccountsScreenV2
        accounts={previewAccounts}
        balances={accountBalances}
        projectedBalances={projectedBalances}
        onNew={() => undefined}
        onUpdate={async () => undefined}
        onDelete={() => undefined}
        onTransfer={async () => undefined}
        readOnly
      />
    </main>
  </PreviewShell>;
}
