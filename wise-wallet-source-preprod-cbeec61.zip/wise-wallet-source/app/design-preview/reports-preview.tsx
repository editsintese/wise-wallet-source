const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

const categories = [
  { name: 'Casa', amount: 1670, color: 'var(--preview-series-blue)' },
  { name: 'Alimentação', amount: 1240, color: 'var(--preview-series-purple)' },
  { name: 'Educação', amount: 450, color: 'var(--preview-series-gold)' },
  { name: 'Transporte', amount: 290, color: 'var(--preview-series-teal)' },
  { name: 'Saúde', amount: 250, color: 'var(--preview-series-coral)' },
];

const daily = [
  { day: '02', income: 3500, expense: 820 }, { day: '05', income: 0, expense: 1550 },
  { day: '08', income: 0, expense: 120 }, { day: '10', income: 1300, expense: 0 },
  { day: '12', income: 0, expense: 450 }, { day: '15', income: 0, expense: 290 },
  { day: '19', income: 0, expense: 250 }, { day: '23', income: 0, expense: 160 },
  { day: '27', income: 0, expense: 260 },
];

const transactions = [
  { date: '27 set. 2026', title: 'Feira de domingo', category: 'Alimentação', status: 'Realizada', amount: -260 },
  { date: '23 set. 2026', title: 'Jantar em família', category: 'Alimentação', status: 'Realizada', amount: -160 },
  { date: '19 set. 2026', title: 'Farmácia', category: 'Saúde', status: 'Realizada', amount: -250 },
  { date: '15 set. 2026', title: 'Combustível', category: 'Transporte', status: 'Realizada', amount: -290 },
  { date: '12 set. 2026', title: 'Mensalidade escolar', category: 'Educação', status: 'Realizada', amount: -450 },
  { date: '10 set. 2026', title: 'Renda complementar', category: 'Renda', status: 'Realizada', amount: 1300 },
  { date: '08 set. 2026', title: 'Internet residencial', category: 'Casa', status: 'Realizada', amount: -120 },
  { date: '05 set. 2026', title: 'Aluguel', category: 'Casa', status: 'Realizada', amount: -1550 },
  { date: '02 set. 2026', title: 'Salário', category: 'Renda', status: 'Realizada', amount: 3500 },
];

function TrendChart() {
  const maximum = Math.max(...daily.flatMap((item) => [item.income, item.expense]));
  return <div className="reports-preview-chart" role="img" aria-label="Movimentações diárias de setembro: duas entradas e sete dias com despesas">
    {daily.map((item) => <div className="reports-preview-day" key={item.day}>
      <div className="reports-preview-bars">
        <i className="income" style={{ height: `${Math.max(4, item.income / maximum * 100)}%` }} />
        <i className="expense" style={{ height: `${Math.max(4, item.expense / maximum * 100)}%` }} />
      </div><span>{item.day}</span>
    </div>)}
  </div>;
}

export function ReportsPreview() {
  return <main className="reports-preview" aria-labelledby="reports-preview-title">
    <header className="reports-preview-heading">
      <div className="reports-preview-heading-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 12h7M9 16h7"/></svg></div>
      <div className="reports-preview-heading-copy"><p className="reports-preview-eyebrow">RELATÓRIO FINANCEIRO</p><h1 id="reports-preview-title">Resumo do período</h1><p>Compare receitas, despesas e lançamentos com clareza.</p></div>
      <div className="reports-preview-actions"><button disabled>Exportar CSV</button><button disabled>Exportar PDF</button></div>
    </header>

    <section className="reports-preview-filters" aria-label="Filtros de exemplo, desativados">
      <div className="reports-preview-filter-title"><div><span>PERÍODO ANALISADO</span><strong>01 a 30 de setembro de 2026</strong></div><button type="button" disabled>Filtros do relatório <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="m3 6 5 5 5-5"/></svg></button></div>
      <div className="reports-preview-filter-grid">
        <label><span>De</span><div className="reports-preview-field-value">01/09/2026</div></label>
        <label><span>Até</span><div className="reports-preview-field-value">30/09/2026</div></label>
        <label><span>Situação</span><div className="reports-preview-field-value">Realizadas e previstas</div></label>
        <label><span>Categoria</span><div className="reports-preview-field-value">Todas as categorias</div></label>
        <label><span>Responsável</span><div className="reports-preview-field-value">Todos os responsáveis</div></label>
        <label><span>Ordenar</span><div className="reports-preview-field-value">Mais recentes</div></label>
        <div className="reports-preview-search"><span>Busca</span><div>Nome, categoria ou responsável</div></div>
        <label className="reports-preview-checkbox"><input type="checkbox" disabled /><span>Incluir análise no PDF</span></label>
      </div>
      <p className="reports-preview-help">As datas consideram a competência dos lançamentos.</p>
    </section>

    <section className="reports-preview-summary" aria-label="Totais do período">
      <article><span>Receitas</span><strong className="income">+{money.format(4800)}</strong></article>
      <article><span>Despesas</span><strong className="expense">−{money.format(3900)}</strong></article>
      <article className="result"><span>Resultado do período</span><strong className="income">+{money.format(900)}</strong></article>
    </section>

    <section className="reports-preview-insights" aria-label="Leituras do período">
      <article className="reports-preview-panel reports-preview-categories">
        <header><div><span>DESPESAS</span><h2>Para onde foi o dinheiro</h2></div><b>5 categorias</b></header>
        <ol>{categories.map((item) => <li key={item.name}><div><span><i style={{ background: item.color }} />{item.name}</span><strong>{money.format(item.amount)}</strong></div><div className="reports-preview-track"><i style={{ width: `${item.amount / 3900 * 100}%`, background: item.color }} /></div></li>)}</ol>
      </article>
      <article className="reports-preview-panel reports-preview-daily">
        <header><div><span>SETEMBRO 2026</span><h2>Dias com movimentação</h2></div><div className="reports-preview-legend"><span><i className="income"/>Entradas</span><span><i className="expense"/>Saídas</span></div></header>
        <TrendChart />
        <p>Entradas e saídas por dia no período.</p>
      </article>
      <article className="reports-preview-panel reports-preview-monthly">
        <header><div><span>RESULTADO</span><h2>Balanço mensal</h2></div></header>
        <div className="reports-preview-month-row"><span>Setembro de 2026</span><strong className="income">+{money.format(900)}</strong></div>
        <p>Receitas menos despesas em cada mês.</p>
      </article>
    </section>

    <section className="reports-preview-transactions">
      <header><div><p className="reports-preview-eyebrow">LANÇAMENTOS DO PERÍODO</p><h2>9 resultados</h2></div><span>Mais recentes primeiro</span></header>
      <div className="reports-preview-transaction-list">{transactions.map((item) => <article key={`${item.date}-${item.title}`}>
        <div className="reports-preview-transaction-copy"><strong>{item.title}</strong><span>{item.category} · {item.date}</span></div>
        <span className="reports-preview-status">{item.status}</span>
        <strong className={item.amount < 0 ? 'expense' : 'income'}>{item.amount < 0 ? '−' : '+'}{money.format(Math.abs(item.amount))}</strong>
        <button disabled aria-label={`Editar ${item.title}`}>Editar</button>
      </article>)}</div>
    </section>
    <p className="reports-preview-note">Dados fictícios para referência visual. Filtros, exportações e edição estão desativados nesta prévia.</p>
  </main>;
}
