'use client';

import { useEffect, useMemo, useState } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { firestore } from './lib/firebase';
import {PlanningView} from './maybe-ui/planning-view';
import { MoneyValue } from './design-system/money-value';
import { CurrencyInput } from './design-system/currency-input';
import { partialCashForecast, simulatePurchase } from './planning-domain';
import { parseMoneyInput } from './web-finance';

type Transaction = { amount: number; kind: 'income' | 'expense'; status: string; transactionDate: string; archived?: boolean; historicalOnly?: boolean; cardId?: string };
type Goal = { id: string; name: string; target: number; current: number };

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' });
const monthOf = (offset: number) => { const date = new Date(today().slice(0,7) + '-01T12:00:00'); date.setMonth(date.getMonth() + offset); return date.toLocaleDateString('en-CA').slice(0, 7); };
const addMonths = (month: string, offset: number) => { const date = new Date(month + '-01T12:00:00'); date.setMonth(date.getMonth() + offset); return date.toLocaleDateString('en-CA').slice(0, 7); };
const monthLabel = (month: string) => new Date(month + '-01T12:00:00').toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

export function PlanningScreen({currentCash}:{currentCash:number}){
 const [transactions,setTransactions]=useState<Transaction[]>([]);
 const [goals,setGoals]=useState<Goal[]>([]);
  useEffect(() => {
    if (!firestore) return;
    const root = ['households', 'family-wallet'] as const;
    const stopTransactions = onSnapshot(collection(firestore, ...root, 'transactions'), (snapshot) => setTransactions(snapshot.docs.map((entry) => { const data = entry.data(); return { amount: Number(data.amountCents) / 100 || Number(data.amount) || 0, kind: data.kind === 'income' || data.type === 'income' ? 'income' : 'expense', status: String(data.status || 'planned'), transactionDate: String(data.transactionDate || data.competenceDate || data.dueDate || data.purchaseDate || ''), archived: data.archivedAt != null || data.archived === true, historicalOnly: data.historicalOnly === true, cardId: String(data.cardId || '') };  })));

    const stopGoals = onSnapshot(collection(firestore, ...root, 'goals'), (snapshot) => setGoals(snapshot.docs.map((entry) => ({ id: entry.id, ...(entry.data() as Omit<Goal, 'id'>) }))));
    return () => { stopTransactions(); stopGoals(); };
  }, []);

 return <PlanningView currentCash={currentCash} transactions={transactions} goals={goals}/>;
}
