import {MaybeDialog} from './maybe-ui/dialog';
import {MaybeButton} from './maybe-ui/primitives';
import {RecordRow} from './maybe-ui/record-row';
import type {planManualInstallmentCancellation} from './manual-installment-cancel';
const money=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
export function ManualCancellationDialog({description,amount,reason,group,saving,error,onClose,onConfirm}:{description:string;amount:number;reason:string;group?:ReturnType<typeof planManualInstallmentCancellation>;saving:boolean;error?:string;onClose:()=>void;onConfirm:()=>void}){
 return <MaybeDialog title={group?'Cancelar parcelamento':'Cancelar lançamento'} onClose={()=>{if(!saving)onClose()}} footer={<><MaybeButton disabled={saving} onClick={onClose}>Voltar sem cancelar</MaybeButton><MaybeButton variant="danger" disabled={saving||Boolean(group?.blocked)} onClick={onConfirm}>{saving?'Cancelando…':group?'Cancelar todas as parcelas':'Confirmar cancelamento'}</MaybeButton></>}>
  <p><strong>{description}</strong> · {money.format(group?group.totalCents/100:amount)}</p>
  <p className="form-help">{group?'Todas as parcelas previstas serão canceladas juntas. Nenhum saldo será movimentado. Se houver parcela paga ou alteração concorrente, a operação inteira será recusada.':'O efeito realizado será revertido no saldo da conta. Esta ação não transfere dinheiro pelo banco.'} Os registros e o motivo serão preservados.</p>
  {group&&<section aria-label="Parcelas do cancelamento">{group.rows.map(row=><RecordRow key={row.id} title={`Parcela ${row.installmentNumber} de ${row.installmentCount}`} meta={`${row.rawDate.split('-').reverse().join('/')} · ${row.status==='planned'?'Prevista':row.status==='realized'?'Realizada':'Cancelada'}`} value={money.format(row.amount)}/>)}</section>}
  {group?.blocked&&<p role="alert">{group.blocked}</p>}<p>Motivo: {reason}</p>{error&&<p role="alert">{error}</p>}
 </MaybeDialog>;
}
