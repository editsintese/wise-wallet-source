type BudgetRow = { id: string; name?: string; categoryName?: string; subcategoria?: string; subcategory?: string; tipo?: string; valor_previsto?: number; valorPrevisto?: number; expectedAmount?: number };
type BudgetTransaction = { amount: number; kind: 'income' | 'expense'; category?: string; subcategory?: string; rawDate?: string; transactionDate?: string; archived?: boolean; cardPayment?: boolean; isCardPayment?: boolean };

export type CategoryGroup = { id: string; name: string; rows: BudgetRow[]; subcategories: string[]; monthlyLimit: number };

export function groupBudgetCategories(rows: BudgetRow[]): CategoryGroup[] {
  const groups = new Map<string, CategoryGroup>();
  for (const row of rows) {
    const name = String(row.name || row.categoryName || '').trim() || String(row.subcategoria || row.subcategory || '').trim() || 'Sem categoria';
    const key = name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR');
    const current = groups.get(key) || { id: key || row.id, name, rows: [], subcategories: [], monthlyLimit: 0 };
    current.rows.push(row);
    const subcategory = String(row.subcategoria || row.subcategory || '').trim();
    if (subcategory && !current.subcategories.includes(subcategory)) current.subcategories.push(subcategory);
    const amount = row.valor_previsto ?? row.valorPrevisto ?? row.expectedAmount;
    if (Number.isFinite(Number(amount))) current.monthlyLimit += Number(amount);
    groups.set(key, current);
  }
  return [...groups.values()].sort((left, right) => left.name.localeCompare(right.name, 'pt-BR'));
}

export function calculateBudgetUsage(transactions: BudgetTransaction[], budget: { name: string; monthlyLimit: number }, month: string) {
  const spent = transactions.filter((item) => !item.archived && !item.cardPayment && !item.isCardPayment && item.kind === 'expense' && String(item.rawDate || item.transactionDate || '').startsWith(month) && String(item.category || '').trim() === budget.name).reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const remaining = budget.monthlyLimit - spent;
  const percent = budget.monthlyLimit > 0 ? spent / budget.monthlyLimit * 100 : 0;
  return { spent, remaining, percent, over: remaining < 0 };
}
