type CardBankFields = {
  limit?: unknown;
  availableFromBank?: unknown;
  usedFromBank?: unknown;
  currentInvoiceFromBank?: unknown;
  bankCheckedAt?: unknown;
  invoiceCheckedAt?: unknown;
};

export type CardBankSnapshot = { amountCents: number; checkedAt: string };

function validDate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function amountCents(value: unknown): number | null {
  if (value == null || typeof value === 'boolean') return null;
  const amount = Number(value);
  if (!Number.isFinite(amount)) return null;
  const cents = Math.round(amount * 100);
  return Number.isSafeInteger(cents) && Math.abs(amount - cents / 100) <= 1e-7 ? cents : null;
}

export function cardBankUsageSnapshot(card: CardBankFields): CardBankSnapshot | null {
  if (!validDate(card.bankCheckedAt)) return null;
  const limit = amountCents(card.limit);
  const available = amountCents(card.availableFromBank);
  // Match the card's available-credit calculation when both bank fields exist.
  const used = available != null
    ? limit == null ? null : limit - available
    : amountCents(card.usedFromBank);
  return used == null || used < 0 ? null : { amountCents: used, checkedAt: card.bankCheckedAt };
}

export function cardBankInvoiceSnapshot(card: CardBankFields): CardBankSnapshot | null {
  if (!validDate(card.invoiceCheckedAt)) return null;
  const amount = amountCents(card.currentInvoiceFromBank);
  return amount == null || amount < 0 ? null : { amountCents: amount, checkedAt: card.invoiceCheckedAt };
}
