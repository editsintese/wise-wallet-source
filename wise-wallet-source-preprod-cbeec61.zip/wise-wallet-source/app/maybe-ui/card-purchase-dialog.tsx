'use client';
import {useState,useEffect,useRef,type FormEvent} from 'react';
import {MaybeDialog} from './dialog';
import {MaybeButton,MaybeField,MaybeDisclosure} from './primitives';
import {CurrencyInput,formatCurrencyInput} from '../design-system/currency-input';
import {cardPurchasePreview} from '../card-purchase-preview';
import {normalizeReferenceName} from '../reference-data';
type Card={name:string;closingDay:number;dueDay:number};
type BudgetRow={id:string;name?:string;categoryName?:string;subcategoria?:string;subcategory?:string};
const today=()=>new Date().toLocaleDateString('en-CA',{timeZone:'America/Sao_Paulo'});
const money=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
const formatDate=(date:string)=>new Date(`${date}T12:00:00`).toLocaleDateString('pt-BR',{day:'2-digit',month:'short'});
const parseAmount=(value:unknown)=>{const raw=String(value||'').replace(/[^0-9,.-]/g,'');return Number(raw.includes(',')?raw.replace(/\./g,'').replace(',','.'):raw)||0};
const invoiceDateForPurchase = (card: Card, purchaseDate: string) => {
  if (!card.closingDay || !card.dueDay || !/^\d{4}-\d{2}-\d{2}$/.test(purchaseDate)) return purchaseDate;
  const purchase = new Date(`${purchaseDate}T12:00:00`);
  if (Number.isNaN(purchase.getTime())) return purchaseDate;
  const monthsForward = purchase.getDate() > card.closingDay ? 2 : 1;
  const invoiceMonth = new Date(purchase.getFullYear(), purchase.getMonth() + monthsForward, 1);
  const lastDay = new Date(invoiceMonth.getFullYear(), invoiceMonth.getMonth() + 1, 0).getDate();
  return `${invoiceMonth.getFullYear()}-${String(invoiceMonth.getMonth() + 1).padStart(2, '0')}-${String(Math.min(card.dueDay, lastDay)).padStart(2, '0')}`;
};
export function CardPurchaseDialog({ card, budgetRows, categoryOptions, saving, onClose, onSubmit, onCreateCategory, onCreateSubcategory, title='Nova compra no cartão', submitLabel='Salvar compra', helperText }: { card: Card; budgetRows: BudgetRow[]; categoryOptions: string[]; saving: boolean; onClose: () => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void; onCreateCategory?: (name:string)=>Promise<string>; onCreateSubcategory?: (category:string,name:string)=>Promise<string>; title?:string; submitLabel?:string; helperText?:string }) {
  const [purchaseKind, setPurchaseKind] = useState('expense');
  const [purchaseDate, setPurchaseDate] = useState(today);
  const [invoiceDate, setInvoiceDate] = useState(() => invoiceDateForPurchase(card, today()));
  const [count, setCount] = useState('1');
  const [amountValue, setAmountValue] = useState('0,00');
  const [installmentValue, setInstallmentValue] = useState('0,00');
  const [category, setCategory] = useState(() => categoryOptions.includes('Compras') ? 'Compras' : categoryOptions[0] || 'Sem categoria');
  const [subcategory, setSubcategory] = useState('');
  const [localCategories, setLocalCategories] = useState<string[]>([]);
  const [localSubcategories, setLocalSubcategories] = useState<{ category: string; name: string }[]>([]);
  const [savingReference, setSavingReference] = useState(false);
  const [entryKind, setEntryKind] = useState<'category' | 'subcategory' | null>(null);
  const [entryValue, setEntryValue] = useState('');
  const [entryMessage, setEntryMessage] = useState('');
  const allCategoryOptions = [...new Set([...categoryOptions, ...localCategories])].sort((a, b) => a.localeCompare(b, 'pt-BR'));
  const subcategoryOptions = [...new Set([...budgetRows.filter((row) => normalizeReferenceName(String(row.name || row.categoryName || '')) === normalizeReferenceName(category)).map((row) => String(row.subcategoria || row.subcategory || '').trim()).filter(Boolean), ...localSubcategories.filter((item) => normalizeReferenceName(item.category) === normalizeReferenceName(category)).map((item) => item.name)])].sort((a, b) => a.localeCompare(b, 'pt-BR'));
  const newCategoryOption = '__new_category__';
  const newSubcategoryOption = '__new_subcategory__';
  async function saveReferenceEntry() {
    const entered = entryValue.trim().replace(/\s+/g, ' ');
    if (entered.length < 2 || entered.length > 50) { setEntryMessage('Use um nome entre 2 e 50 caracteres.'); return; }
    const choices = entryKind === 'category' ? allCategoryOptions : subcategoryOptions;
    const existing = choices.find((item) => normalizeReferenceName(item) === normalizeReferenceName(entered));
    if (existing) {
      if (entryKind === 'category') { setCategory(existing); setSubcategory(''); }
      else setSubcategory(existing);
      setEntryKind(null); setEntryValue(''); setEntryMessage(''); return;
    }
    setSavingReference(true); setEntryMessage('');
    try {
      if (entryKind === 'category') {
        if(!onCreateCategory)throw new Error('Category creation unavailable');
        const created = await onCreateCategory(entered);
        setLocalCategories((current) => [...current, created]); setCategory(created); setSubcategory('');
      } else if (entryKind === 'subcategory') {
        if(!onCreateSubcategory)throw new Error('Subcategory creation unavailable');
        const created = await onCreateSubcategory(category, entered);
        setLocalSubcategories((current) => [...current, { category, name: created }]); setSubcategory(created);
      }
      setEntryKind(null); setEntryValue('');
    } catch { setEntryMessage('Não foi possível salvar. Use um nome entre 2 e 50 caracteres e tente novamente.'); }
    finally { setSavingReference(false); }
  }
  async function changeCategory(value: string) {
    if (value !== newCategoryOption) { setCategory(value); setSubcategory(''); return; }
    setEntryKind('category'); setEntryValue(''); setEntryMessage('');
  }
  async function changeSubcategory(value: string) {
    if (value !== newSubcategoryOption) { setSubcategory(value); return; }
    setEntryKind('subcategory'); setEntryValue(''); setEntryMessage('');
  }
  const preview = cardPurchasePreview(Math.round(parseAmount(amountValue) * 100), Number(count), invoiceDate);
  const calculateTotal = () => setAmountValue(formatCurrencyInput(String(Math.round(parseAmount(installmentValue) * Math.max(2, Number(count) || 2) * 100))));
  return <MaybeDialog id="card-modal-title" title={title} className="mb-purchase-dialog" onClose={onClose}><form className="mb-purchase-form" onSubmit={(event)=>{if(savingReference||entryKind){event.preventDefault();return;}onSubmit(event);}}>
    <div className="mb-type-tabs" role="group" aria-label="Tipo da movimentação"><button type="button" aria-pressed={purchaseKind==='expense'} onClick={()=>setPurchaseKind('expense')}>Despesa</button><button type="button" aria-pressed={purchaseKind==='income'} onClick={()=>setPurchaseKind('income')}>Estorno / receita</button></div>
    <input type="hidden" name="kind" value={purchaseKind}/>
    <p className="mb-card-context">{card.name}</p>{helperText && <p className="form-help">{helperText}</p>}
    <section className="mb-form-section">
      <MaybeField label="Descrição"><input name="description" required placeholder="Em que você gastou?"/></MaybeField>
      <MaybeField label="Valor total"><CurrencyInput name="amount" required value={amountValue} onValueChange={setAmountValue} aria-label="Valor total"/></MaybeField>
      <MaybeField label="Parcelas"><input name="count" type="number" min="1" max="120" value={count} onChange={event=>setCount(event.target.value)}/></MaybeField>
      <MaybeField label="Vencimento da primeira fatura"><input name="date" type="date" required value={invoiceDate} onChange={event=>setInvoiceDate(event.target.value)}/></MaybeField>
    </section>
    <MaybeDisclosure title="Detalhes da compra">
      <MaybeField label="Categoria"><select name="category" value={category} onChange={event=>void changeCategory(event.target.value)}>{allCategoryOptions.map(item=><option key={item} value={item}>{item}</option>)}{onCreateCategory && <option value={newCategoryOption}>+ Nova categoria</option>}</select></MaybeField>
      <MaybeField label="Subcategoria"><select name="subcategory" value={subcategory} onChange={event=>void changeSubcategory(event.target.value)}><option value="">Sem subcategoria</option>{subcategoryOptions.map(item=><option key={item} value={item}>{item}</option>)}{onCreateSubcategory && <option value={newSubcategoryOption}>+ Nova subcategoria</option>}</select></MaybeField>
      {entryKind && <ReferenceInlineEditor kind={entryKind} value={entryValue} message={entryMessage} saving={savingReference} onChange={setEntryValue} onCancel={()=>setEntryKind(null)} onSave={()=>void saveReferenceEntry()}/>}
      <MaybeField label="Responsável"><select name="owner"><option>Família</option><option>Pessoa 1</option><option>Pessoa 2</option></select></MaybeField>
      <MaybeField label="Situação"><select name="status"><option value="realized">Já aconteceu</option><option value="planned">Prevista</option></select></MaybeField>
      <MaybeField label="Data da compra"><input name="purchaseDate" type="date" required value={purchaseDate} onChange={event=>{setPurchaseDate(event.target.value);setInvoiceDate(invoiceDateForPurchase(card,event.target.value));}}/></MaybeField>
      {Number(count)>1 && <div className="mb-installment-calculator"><MaybeField label="Valor da parcela"><CurrencyInput value={installmentValue} onValueChange={setInstallmentValue} aria-label="Valor da parcela"/></MaybeField><p>Informe uma parcela para calcular o total da compra.</p><MaybeButton onClick={calculateTotal}>Calcular total</MaybeButton></div>}
    </MaybeDisclosure>
    <section className="mb-purchase-review purchase-preview" aria-labelledby="purchase-preview-title"><h4 id="purchase-preview-title">Distribuição nas faturas</h4><p>O orçamento considera cada parcela. O saldo da conta só muda no pagamento.</p>{preview.length>0 ? <ol>{preview.map(row=><li key={row.number}><div><strong>Parcela {row.number} de {preview.length}</strong><small>Fatura em {formatDate(row.date)} de {row.date.slice(0,4)}</small></div><b>{money.format(row.amountCents/100)}</b></li>)}</ol> : <p>Informe valor, parcelas e data válidos para conferir a distribuição.</p>}</section>
    <MaybeButton variant="primary" type="submit" disabled={saving||savingReference||Boolean(entryKind)||!preview.length}>{saving?'Salvando…':submitLabel}</MaybeButton>
  </form></MaybeDialog>;

}
function ReferenceInlineEditor({ kind, value, message, saving, onChange, onCancel, onSave }: { kind: 'category' | 'subcategory'; value: string; message: string; saving: boolean; onChange: (value: string) => void; onCancel: () => void; onSave: () => void }) {
  const label = kind === 'category' ? 'categoria' : 'subcategoria';
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { inputRef.current?.focus(); }, []);
  return <section aria-label={`Adicionar ${label}`} className="reference-inline-editor"><strong>Nova {label}</strong><label>Nome<input maxLength={50} minLength={2} ref={inputRef} required value={value} onChange={(event) => onChange(event.target.value)} /></label>{message && <p role="alert">{message}</p>}<div><button className="secondary-button" disabled={saving} type="button" onClick={onCancel}>Cancelar</button><button className="primary-button" disabled={saving} type="button" onClick={onSave}>{saving ? 'Salvando…' : `Adicionar ${label}`}</button></div></section>;
}
