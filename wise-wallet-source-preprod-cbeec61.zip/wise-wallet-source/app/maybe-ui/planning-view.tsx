'use client';
import {RecordRow} from './record-row';
import {goalFeedback,purchaseFeedback} from '../planning-feedback';
import {useMemo,useState} from 'react';
import {MaybeField} from './primitives';
import {CurrencyInput} from '../design-system/currency-input';
import {MoneyValue} from '../design-system/money-value';
import {partialCashForecast,simulatePurchase,type PlanningTransaction} from '../planning-domain';
import {parseMoneyInput} from '../web-finance';
const money=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
const today=()=>new Date().toLocaleDateString('en-CA',{timeZone:'America/Sao_Paulo'});
const monthOf=(offset:number)=>{const d=new Date(today().slice(0,7)+'-01T12:00:00');d.setMonth(d.getMonth()+offset);return d.toLocaleDateString('en-CA').slice(0,7)};
const label=(month:string)=>new Date(month+'-01T12:00:00').toLocaleDateString('pt-BR',{month:'long',year:'numeric'});
export function PlanningView({currentCash,transactions,goals}:{currentCash:number;transactions:PlanningTransaction[];goals:{id:string;name:string;target:number;current:number}[]}){
 const [selectedMonth,setSelectedMonth]=useState(monthOf(0));
 const [purchase,setPurchase]=useState({amount:'0,00',installments:'1',start:today()});
 const forecast=useMemo(()=>partialCashForecast(currentCash,transactions,Array.from({length:6},(_,i)=>monthOf(i))),[currentCash,transactions]);
 const selected=forecast.find(row=>row.month===selectedMonth),lowest=Math.min(...forecast.map(row=>row.balance));
 const simulation=useMemo(()=>{let amount=0;try{amount=parseMoneyInput(purchase.amount)}catch{}const count=Number(purchase.installments),start=purchase.start.slice(0,7);return {amount,count,rows:start>=monthOf(0)&&start<=monthOf(5)?simulatePurchase(forecast,Math.round(amount*100),count,start):null}},[forecast,purchase]);
 const feedback=simulation.rows?purchaseFeedback(simulation.rows,simulation.count):null;
 return <section className="mb-transactions planning-preview"><header className="mb-page-heading"><div><h2>Planejamento</h2><p className="form-help">Explore projeções e simule uma compra, sem criar lançamentos.</p></div><MaybeField label="Mês de referência"><input type="month" value={selectedMonth} onChange={e=>{if(e.target.value)setSelectedMonth(e.target.value)}}/></MaybeField></header>
 <dl className="mb-summary"><div><dt>Projeção parcial do mês</dt><dd>{selected?<MoneyValue value={selected.balance}/>: 'Fora do horizonte'}</dd></div><div><dt>Menor projeção em seis meses</dt><dd><MoneyValue value={lowest}/></dd></div><div><dt>Caixa atual de referência</dt><dd><MoneyValue value={currentCash}/></dd></div></dl>
 <p className="mb-list-note">Estimativa parcial: considera o caixa atual e lançamentos previstos sem cartão. Faturas, recorrências automáticas e outros movimentos futuros estão fora desta projeção. Ela não é o orçamento nem representa todo o dinheiro livre.</p>
 <section className="mb-table-container"><header className="mb-page-heading"><h3>Metas financeiras</h3></header>{goals.length?goals.map(goal=><div className="planning-goal" key={goal.id}><RecordRow title={goal.name} meta={`${money.format(goal.current)} de ${money.format(goal.target)}`} value={`${goal.target>0?Math.min(100,Math.round(goal.current/goal.target*100)):0}%`}/><div className="planning-feedback"><strong>{goalFeedback(goal.target,goal.current).title}</strong><p>{goalFeedback(goal.target,goal.current).recommendation}</p></div></div>):<p className="mb-empty">Nenhuma meta disponível neste recorte.</p>}</section>
 <section className="mb-table-container"><header className="mb-page-heading"><div><h3>Simular compra parcelada</h3><p className="form-help">Altere os campos para atualizar a projeção. Nenhum registro será criado.</p></div></header><div className="planning-simulation-fields"><MaybeField label="Valor total"><CurrencyInput value={purchase.amount} onValueChange={amount=>setPurchase({...purchase,amount})}/></MaybeField><MaybeField label="Parcelas"><input type="number" min="1" max="120" value={purchase.installments} onChange={e=>setPurchase({...purchase,installments:e.target.value})}/></MaybeField><MaybeField label="Vencimento da primeira parcela"><input type="date" value={purchase.start} min={monthOf(0)+'-01'} onChange={e=>setPurchase({...purchase,start:e.target.value})}/></MaybeField></div>
 <p className="form-help">O impacto acompanha a competência de cada parcela. O recorte mostra apenas os próximos seis meses; parcelas posteriores continuam sendo compromissos fora desta visualização.</p>
 {simulation.amount>0&&!simulation.rows&&<p role="alert">Informe de 1 a 120 parcelas e o primeiro vencimento dentro dos próximos seis meses.</p>}
 {simulation.amount>0&&simulation.rows&&<section aria-label="Projeção com a compra">{feedback&&<div className="planning-feedback" role="status"><h4>{feedback.title}</h4><p>{feedback.explanation}</p><p>Menor projeção em {label(feedback.month)}.</p><strong>Próximos passos</strong><ul>{feedback.recommendations.map(step=><li key={step}>{step}</li>)}</ul>{feedback.outside&&<p>{feedback.outside}</p>}<p>Este cálculo parcial não confirma que a compra cabe no orçamento.</p></div>}<div className="planning-forecast-head" aria-hidden="true"><span>Competência</span><span>Parcela</span><span>Projeção parcial</span></div>{simulation.rows.map(row=><div className="planning-forecast-row" key={row.month}><strong>{label(row.month)}</strong><span><small>Parcela</small><MoneyValue value={-row.purchaseAmount}/></span><span><small>Projeção parcial</small><MoneyValue value={row.balanceWithPurchase}/></span></div>)}</section>}
 </section></section>;
}
