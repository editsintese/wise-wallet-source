// Adapted from Maybe Finance DS::Buttonish and styled_form_builder/form-field.
// Source commit 77b5469832758d1cbee1a940f3012a1ae1c74cd3, AGPL-3.0.
import { cloneElement, type ButtonHTMLAttributes, type ReactElement, type ReactNode } from 'react';
export function MaybeButton({variant='outline',className='',type='button',...props}:ButtonHTMLAttributes<HTMLButtonElement>&{variant?:'primary'|'outline'|'ghost'|'danger';}) {
  return <button {...props} type={type} className={`mb-button mb-button-${variant} ${className}`} />;
}
export function MaybeField({label,children,className=""}:{label:string;children:ReactElement;className?:string}) {
  return <label className={`mb-field ${className}`}><span className="mb-field-label">{label}</span>{cloneElement(children as ReactElement<{'aria-label'?:string}>, {'aria-label':label})}</label>;
}
export function MaybeDisclosure({title,children}:{title:string;children:ReactNode}) {
  return <details className="mb-disclosure"><summary>{title}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></summary><div>{children}</div></details>;
}
