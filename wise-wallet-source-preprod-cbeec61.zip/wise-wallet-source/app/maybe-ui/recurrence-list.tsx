import {RecordRow} from './record-row';
import {MaybeButton,MaybeDisclosure} from './primitives';
import {buildRecurrenceRows,type RegisteredRecurrenceTransaction} from '../recurrence-rows';
import {recurrenceMonthAmount} from '../recurrence-domain';
import type {Recurrence} from '../monthly-overview';
export type RecurrenceListRecord=Recurrence & {owner?:string;accountId?:string;cardId?:string;active?:boolean;endDate?:string;frequency?:string;observations?:string};
const money=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
const monthLabel=(month:string)=>new Date(month+'-01T12:00:00').toLocaleDateString('pt-BR',{month:'long',year:'numeric'});
export function RecurrenceList({active,month,transactions,accounts,cards,payments,readOnly=false,onInspect,onToggleMonth,onEditOccurrence,onForecast,onEditRule,onArchive,onConfirmPlanned,recordedRules=active}:{active:RecurrenceListRecord[];recordedRules?:RecurrenceListRecord[];month:string;transactions:RegisteredRecurrenceTransaction[];accounts:{id:string;name:string}[];cards:{id:string;name:string}[];payments:{cardId:string;competence:string;amount:number;status?:string;reversed?:boolean}[];readOnly?:boolean;onInspect?:(item:RecurrenceListRecord)=>void;onToggleMonth?:(id:string,key:string)=>void;onEditOccurrence?:(id:string)=>void;onForecast?:(item:RecurrenceListRecord,month:string)=>void;onEditRule?:(item:RecurrenceListRecord)=>void;onArchive?:(id:string)=>Promise<void>;onConfirmPlanned?:(item:RecurrenceListRecord,key:string)=>void}){

 const rows=buildRecurrenceRows(active,recordedRules,transactions,month);
 const dates=[...new Set(rows.map(row=>row.occurrence.date))];
 return <section className="mb-table-container" aria-label={`Compromissos de ${monthLabel(month)}`} data-ui="clareza-recurrence-list">
  <div className="mb-selection-toolbar"><span>{new Set(rows.map(row=>row.item.id)).size} regra(s) · {rows.length} ocorrência(s)</span></div>
  
  <div className="mb-date-groups">{dates.map(date=><section className="mb-date-group" key={date}><h3>{new Date(date+'T12:00:00').toLocaleDateString('pt-BR',{day:'2-digit',month:'short',year:'numeric'})}<span>{rows.filter(row=>row.occurrence.date===date).length}</span></h3>{rows.filter(row=>row.occurrence.date===date).map(({item,occurrence,registered})=>{
   const key=occurrence.occurrenceKey,paid=Boolean(item.settledMonths?.includes(key)),amount=registered?registered.amount:recurrenceMonthAmount(item,key,transactions),linkedId=item.occurrenceTransactions?.[key];
   const cardLocked=Boolean(item.cardId&&payments.some(payment=>payment.cardId===item.cardId&&payment.competence===month&&!payment.reversed&&payment.status!=='reversed'&&payment.status!=='cancelled'&&payment.amount>0));
   const source=item.cardId?cards.find(card=>card.id===item.cardId)?.name||'Cartão não informado':accounts.find(account=>account.id===(registered?.accountId||item.accountId))?.name||'Conta não informada';
   const canEditPaid=paid&&Boolean(linkedId)&&transactions.some(transaction=>transaction.id===linkedId);
   const hasMoreActions=Boolean(canEditPaid||(!registered&&!paid&&!item.cardId&&onConfirmPlanned)||(!registered&&!paid&&!cardLocked&&!item.closedForFuture)||(!item.closedForFuture&&(onEditRule||onArchive)));
   return <div key={`${item.id}-${key}`}>
    <RecordRow title={registered?.description||item.description} meta={<>{registered?.category||item.category||'Sem categoria'} · {registered?'Registro vinculado':item.frequency==='weekly'?'Semanal':item.frequency==='yearly'?'Anual / meses selecionados':'Mensal'} · {item.cardId?'Conferir na fatura':paid?'Realizada':registered?'Compromisso registrado':'Prevista'}{registered&&item.active===false?' · Regra pausada':''}<br/>{source} · {registered?.owner||item.owner||'Família'}</>} value={amount===null?'Valor indisponível':`${amount===0?'':(registered?.kind||item.kind)==='income'?'+':'−'}${money.format(amount)}`} onOpen={readOnly&&onInspect?()=>onInspect(item):undefined}/>
    {!readOnly&&<div className="mb-recurrence-actions">
     {item.cardId?<p className="mb-recurrence-note">Liquidação pela fatura</p>:<MaybeButton className="mb-recurrence-primary" variant={paid?'outline':'primary'} disabled={!onToggleMonth} onClick={()=>onToggleMonth?.(item.id,key)}>{paid?'Desfazer pagamento':item.kind==='income'?'Registrar recebimento':'Registrar pagamento'}</MaybeButton>}
     {hasMoreActions&&<div className="mb-recurrence-more"><MaybeDisclosure title="Mais ações">
      {canEditPaid&&<MaybeButton variant="outline" disabled={!onEditOccurrence} onClick={()=>onEditOccurrence?.(linkedId!)}>Editar valor do mês</MaybeButton>}
      {!registered&&!paid&&!item.cardId&&onConfirmPlanned&&<MaybeButton variant="outline" onClick={()=>onConfirmPlanned(item,key)}>Confirmar compromisso previsto</MaybeButton>}
      {!registered&&!paid&&!cardLocked&&!item.closedForFuture&&<MaybeButton variant="outline" disabled={!onForecast} onClick={()=>onForecast?.(item,month)}>Editar previsão do mês</MaybeButton>}
      {cardLocked&&<p className="mb-recurrence-note">Previsão bloqueada pela fatura</p>}
      {item.closedForFuture?<p className="mb-recurrence-note">Histórico encerrado</p>:<>
       <MaybeButton variant="outline" disabled={!onEditRule} onClick={()=>onEditRule?.(item)}>Editar regra</MaybeButton>
       <MaybeButton variant="outline" className="danger" disabled={!onArchive} onClick={()=>void onArchive?.(item.id)}>Arquivar</MaybeButton>
      </>}
     </MaybeDisclosure></div>}
    </div>}
   </div>;
  })}</section>)}</div>{!rows.length&&<p className="mb-empty">Nenhuma ocorrência disponível para este mês.</p>}
 </section>;
}
