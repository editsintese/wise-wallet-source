'use client';
import {RecordRow} from './record-row';

import { useEffect, useMemo, useState } from 'react';
import {MaybeButton} from './primitives';
import {MaybeDialog} from './dialog';
import { TransactionView } from '../transaction-model';

import { buildCalendarEvents, CalendarTransaction, type CalendarEvent } from '../calendar-events';
import { RecurrenceRule } from '../recurrence-domain';

type Recurrence = RecurrenceRule;
type CardPayment = { cardId: string; competence: string; amount?:number; status?:string; reversed?: boolean };
type Card = { id: string; name: string; dueDay: number };

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' });
const addMonths = (month: string, offset: number) => { const date = new Date(`${month}-01T12:00:00`); date.setMonth(date.getMonth() + offset); return date.toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' }).slice(0, 7); };
const monthLabel = (month: string) => new Date(`${month}-01T12:00:00`).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
const dayLabel = (date: string) => new Date(`${date}T12:00:00`).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' });

const statusLabel=(value?:string)=>value==='planned'?'Prevista':value==='realized'?'Realizada':value||'Não informada';

export function CalendarView({ transactions, recurrences, cardPayments, cards }: { transactions: TransactionView[]; recurrences: Recurrence[]; cardPayments: CardPayment[]; cards:Card[] }) {
  const [month, setMonth] = useState(today().slice(0, 7));
  const [selectedDay, setSelectedDay] = useState(today());
  const [detail,setDetail]=useState<CalendarEvent|null>(null);
  useEffect(() => { if (!selectedDay.startsWith(month)) setSelectedDay(`${month}-01`); }, [month, selectedDay]);

  const events = useMemo(() => buildCalendarEvents({ month, transactions: transactions as CalendarTransaction[], recurrences, cards, cardPayments }), [cardPayments, cards, month, recurrences, transactions]);

  const eventsByDay = useMemo(() => new Map(Array.from({ length: 31 }, (_, index) => `${month}-${String(index + 1).padStart(2, '0')}`).map((date) => [date, events.filter((item) => item.date === date)])), [events, month]);
  const daysInMonth = new Date(`${addMonths(month, 1)}-01T12:00:00`); daysInMonth.setDate(0);
  const firstWeekday = (new Date(`${month}-01T12:00:00`).getDay() + 6) % 7;
  const selectedEvents = eventsByDay.get(selectedDay) || [];

  return <section className="calendar-page">
    <div className="calendar-heading">
      <span aria-hidden="true" className="calendar-heading-icon"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.8"><rect x="3.5" y="5" width="17" height="16" rx="1" /><path d="M7.5 3v4M16.5 3v4M3.5 9h17M7.5 12.5h3M7.5 16h3" /></svg></span>
      <div className="calendar-heading-copy"><h2>Calendário</h2><span>Veja compras, recorrências e faturas na data certa.</span></div>
      <div className="calendar-navigation"><MaybeButton aria-label="Mês anterior" type="button" onClick={() => setMonth(addMonths(month, -1))}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><path d="m14 6-6 6 6 6"/></svg></MaybeButton><strong aria-live="polite">{monthLabel(month)}</strong><MaybeButton aria-label="Próximo mês" type="button" onClick={() => setMonth(addMonths(month, 1))}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><path d="m10 6 6 6-6 6"/></svg></MaybeButton><MaybeButton onClick={()=>{setMonth(today().slice(0,7));setSelectedDay(today())}}>Hoje</MaybeButton></div>
    </div>
    <p className="form-help">Compras, parcelas, recorrências e faturas são referências de agenda. Seus valores não devem ser somados como um saldo; a fatura pode incluir compras já exibidas.</p>
    <section className="panel calendar-grid-panel">
      <div className="calendar-legend"><span><i className="income" aria-hidden="true" /> Entrada</span><span><i className="expense" aria-hidden="true" /> Saída</span><span><i className="source-invoice" aria-hidden="true" /> Fatura</span><span><i className="source-recurrence expense" aria-hidden="true" /> Recorrência</span></div>
      <div className="calendar-weekdays">{['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'].map((day) => <span key={day}>{day}</span>)}</div>
      <div className="calendar-grid">{Array.from({ length: firstWeekday }, (_, index) => <span className="calendar-empty" key={`empty-${index}`} />)}{Array.from({ length: daysInMonth.getDate() }, (_, index) => { const date = `${month}-${String(index + 1).padStart(2, '0')}`; const items = eventsByDay.get(date) || []; const recurrenceCount = items.filter((item) => item.source === 'recurrence').length; const invoiceCount = items.filter((item) => item.source === 'invoice').length; const label = `${index + 1} de ${monthLabel(month)}, ${items.length} evento(s)${recurrenceCount ? `, ${recurrenceCount} recorrência(s)` : ''}${invoiceCount ? `, ${invoiceCount} fatura(s)` : ''}`; return <button className={`calendar-day ${date === selectedDay ? 'selected' : ''} ${date === today() ? 'today' : ''}`} type="button" key={date} onClick={() => setSelectedDay(date)} aria-label={label} aria-pressed={date === selectedDay} aria-current={date === today() ? 'date' : undefined}><strong>{index + 1}</strong><span aria-hidden="true" className="calendar-markers">{items.slice(0, 3).map((item) => <i key={item.id} className={`${item.kind} source-${item.source}`} />)}</span>{items.length > 3 && <small aria-hidden="true">+{items.length - 3}</small>}</button>; })}</div>
    </section>
    <section aria-live="polite" className="panel calendar-day-details"><div className="panel-heading"><div><h3>{dayLabel(selectedDay)}</h3></div><span>{selectedEvents.length} evento(s)</span></div>{selectedEvents.length ? <div className="calendar-event-list">{selectedEvents.map((event) => <RecordRow key={event.id} title={event.description} meta={`${event.source==='invoice'?'Fatura':event.source==='recurrence'?'Recorrência':'Lançamento'} · ${statusLabel(event.status)}`} value={<span className={event.kind}>{event.kind==='expense'?'−':'+'}{money.format(event.amount)}</span>} onOpen={()=>setDetail(event)}/>)}</div> : <p className="empty-state">Nenhuma movimentação ou compromisso neste dia.</p>}</section>
    {detail&&<MaybeDialog title="Compromisso do calendário" onClose={()=>setDetail(null)} footer={<MaybeButton variant="primary" onClick={()=>setDetail(null)}>Voltar ao calendário</MaybeButton>}><div className="transaction-detail"><h4>{detail.description}</h4><strong className={detail.kind}>{detail.kind==='expense'?'−':'+'}{money.format(detail.amount)}</strong><dl><div><dt>Data na agenda</dt><dd>{dayLabel(detail.date)}</dd></div><div><dt>Situação</dt><dd>{statusLabel(detail.status)}</dd></div><div><dt>Origem</dt><dd>{detail.source==='invoice'?'Fatura':detail.source==='recurrence'?'Recorrência':'Lançamento'}</dd></div>{detail.item?.installmentCount&&<div><dt>Parcela</dt><dd>{detail.item.installmentNumber} de {detail.item.installmentCount}</dd></div>}</dl><p className="form-help">A agenda não comprova quitação individual de parcelas. Confira pagamentos e agendamentos na fatura.</p></div></MaybeDialog>}
  </section>;
}
