'use client';
import {useState,type FormEvent} from 'react';
import {MaybeDialog} from './dialog';
import {MaybeButton,MaybeField} from './primitives';
import {CurrencyInput,formatCurrencyAmount} from '../design-system/currency-input';
import type {InvestmentPosition} from './investment-overview';
export type InvestmentAmendmentContext={item:InvestmentPosition & {version:number};operation:'create'|'valuation'|'contribution'|'withdrawal';basis:InvestmentPosition|null;amountCents:number|null;accountId:string|null;accountName:string};
const money=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
const labels={create:'Aporte inicial',valuation:'Atualização de valor',contribution:'Aporte',withdrawal:'Resgate'};
const cents=(value:string)=>Number(value.replace(/\D/g,''));
export function InvestmentAmendmentForm({context,saving,error,onClose,onSubmit}:{context:InvestmentAmendmentContext;saving:boolean;error:string;onClose:()=>void;onSubmit:(event:FormEvent<HTMLFormElement>)=>void}){
 const [action,setAction]=useState('correct'),[amount,setAmount]=useState(formatCurrencyAmount((context.amountCents||0)/100)),[current,setCurrent]=useState(formatCurrencyAmount(context.item.currentValue));
 const financial=context.operation!=='valuation',amountCents=cents(amount),before=Math.round((context.basis?.currentValue||0)*100);
 const next=action==='reverse'?before:context.operation==='create'||context.operation==='valuation'?cents(current):context.operation==='contribution'?before+amountCents:before-amountCents;
 const delta=!financial?0:(context.operation==='withdrawal'?1:-1)*((action==='reverse'?0:amountCents)-(context.amountCents||0));
 const valid=Number.isSafeInteger(next)&&next>=0&&Number.isSafeInteger(delta)&&(!financial||action==='reverse'||Number.isSafeInteger(amountCents)&&amountCents>0);
 return <MaybeDialog title="Revisar última operação" onClose={onClose}><form onSubmit={onSubmit}>
  <p><strong>{context.item.name}</strong><br/>{labels[context.operation]} · {new Date(context.item.referenceDate+'T12:00:00').toLocaleDateString('pt-BR')}</p>
  <MaybeField label="O que deseja fazer?"><select name="amendmentAction" value={action} disabled={saving} onChange={e=>setAction(e.target.value)}><option value="correct">Corrigir os valores registrados</option><option value="reverse">Anular o registro da operação</option></select></MaybeField>
  {action==='correct'&&financial&&<MaybeField label="Valor correto da operação"><CurrencyInput name="amountCentsInput" value={amount} onValueChange={setAmount} required disabled={saving}/></MaybeField>}
  {action==='correct'&&(context.operation==='create'||context.operation==='valuation')&&<MaybeField label="Valor atual correto da posição"><CurrencyInput name="currentCentsInput" value={current} onValueChange={setCurrent} required disabled={saving}/></MaybeField>}
  <dl className="mb-summary"><div><dt>Posição antes</dt><dd>{money.format(context.item.currentValue)}</dd></div><div><dt>Posição após</dt><dd>{valid?money.format(next/100):'Confira os valores'}</dd></div><div><dt>Ajuste na conta</dt><dd>{valid?money.format(delta/100):'—'}</dd></div></dl>
  {financial&&<p className="form-help">Conta original: {context.accountName}. A conta e a data da operação serão mantidas.</p>}
  <p className="form-help">{action==='reverse'?'A posição voltará ao estado anterior à operação. Anular o aporte inicial arquiva a posição zerada.':'Os valores anteriores e o motivo serão preservados no histórico.'} Esta ação ajusta os registros do Wise e não faz transferências no banco.</p>
  <MaybeField label="Motivo da alteração"><textarea name="reason" required maxLength={160} disabled={saving}/></MaybeField>
  {!valid&&<p role="alert">O resgate não pode superar o valor anterior da posição. Confira os valores informados.</p>}
  {error&&<p role="alert">{error}</p>}
  <MaybeButton type="submit" variant={action==='reverse'?'danger':'primary'} disabled={saving||!valid}>{saving?'Registrando…':action==='reverse'?'Confirmar anulação':'Confirmar correção'}</MaybeButton>
 </form></MaybeDialog>;
}
