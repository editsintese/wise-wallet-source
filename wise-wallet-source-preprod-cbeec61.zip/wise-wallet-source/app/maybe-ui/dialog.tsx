'use client';
import {useEffect,useId,useRef,type ReactNode} from 'react';
import {createPortal} from 'react-dom';
import {MaybeButton} from './primitives';

/** One top-layer dialog for financial details, filters and forms. No financial side effects. */
export function MaybeDialog({title,children,onClose,closeLabel='Fechar janela',id,className='',footer}:{title:string;children:ReactNode;onClose:()=>void;closeLabel?:string;id?:string;className?:string;footer?:ReactNode}){
  const ref=useRef<HTMLDialogElement>(null),close=useRef(onClose),titleId=useId(),backdropStarted=useRef(false);close.current=onClose;
  useEffect(()=>{
    const dialog=ref.current;if(!dialog)return;
    const opener=document.activeElement instanceof HTMLElement?document.activeElement:null;
    const workspace=document.querySelector<HTMLElement>('.workspace');
    const bodyOverflow=document.body.style.overflow,workspaceOverflow=workspace?.style.overflowY||'';
    document.body.style.overflow='hidden';if(workspace)workspace.style.overflowY='hidden';
    const trap=(event:KeyboardEvent)=>{if(event.key!=='Tab')return;const controls=Array.from(dialog.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"],summary')).filter(el=>el.getClientRects().length>0);const first=controls[0],last=controls[controls.length-1];if(!first){event.preventDefault();dialog.focus();return}if(event.shiftKey&&(document.activeElement===first||!controls.includes(document.activeElement as HTMLElement))){event.preventDefault();last.focus()}else if(!event.shiftKey&&(document.activeElement===last||!controls.includes(document.activeElement as HTMLElement))){event.preventDefault();first.focus()}};
    dialog.addEventListener('keydown',trap);if(!dialog.open)dialog.showModal();dialog.querySelector<HTMLElement>('.mb-native-dialog-heading h3')?.focus({preventScroll:true});
    return()=>{dialog.removeEventListener('keydown',trap);dialog.close();document.body.style.overflow=bodyOverflow;if(workspace)workspace.style.overflowY=workspaceOverflow;if(opener?.isConnected)opener.focus({preventScroll:true})};
  },[]);
  if(typeof document==='undefined')return null;
  return createPortal(<dialog id={id} ref={ref} className={`mb-native-dialog ${className}`} aria-labelledby={titleId} onCancel={event=>{event.preventDefault();close.current()}} onPointerDown={event=>{const box=event.currentTarget.getBoundingClientRect();backdropStarted.current=event.target===event.currentTarget&&(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)}} onClick={event=>{if(event.target!==event.currentTarget||!backdropStarted.current)return;const box=event.currentTarget.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)close.current()}}>
    <header className="mb-native-dialog-heading"><h3 id={titleId} tabIndex={-1}>{title}</h3><MaybeButton variant="ghost" className="mb-icon-button" aria-label={closeLabel} onClick={()=>close.current()}><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg></MaybeButton></header>
    <div className="mb-native-dialog-body">{children}</div>{footer&&<footer className="mb-native-dialog-footer">{footer}</footer>}
  </dialog>,document.body);
}
