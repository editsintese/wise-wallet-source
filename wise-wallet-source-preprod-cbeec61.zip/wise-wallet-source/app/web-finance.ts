// Legacy web values remain in reais on disk; all calculations and input checks use cents.
export function parseMoneyInput(input: string): number {
  const value=input.trim().replace(/^R\$\s*/, '');
  const normalized=/^-?\d{1,3}(\.\d{3})+,\d{1,2}$/.test(value) ? value.replaceAll('.', '').replace(',', '.') : value.replace(',', '.');
  if (!/^-?\d+(\.\d{1,2})?$/.test(normalized)) throw new Error('Informe um valor válido com até duas casas decimais.');
  const negative=normalized.startsWith('-'),[whole,fraction='']=normalized.replace('-', '').split('.');
  const cents=Number(whole)*100+Number(fraction.padEnd(2,'0'));
  if (!Number.isSafeInteger(cents)) throw new Error('Valor acima do limite permitido.');
  return (negative ? -cents : cents)/100;
}

export function moneyCents(value: number): number {
  const cents=Math.round(value*100);
  if (!Number.isFinite(value) || !Number.isSafeInteger(cents)) throw new Error('Valor financeiro inválido.');
  return cents;
}

export function validCivilDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date=new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0,10)===value;
}

export function accountBalance(account: {id:string;openingBalance:number}, transactions: {accountId?:string;cardId?:string;status:string;kind:string;amount:number}[], payments: {accountId:string;amount:number;reversed?:boolean;balanceImpact?:boolean;status?:string}[], transfers:{accountId:string;amountCents:number;balanceImpact?:boolean}[]=[]): number {
  let total=moneyCents(account.openingBalance || 0);
  for (const item of transactions) if(item.accountId===account.id && !item.cardId && item.status==='realized') total+=(item.kind==='income'?1:-1)*moneyCents(item.amount);
  for (const payment of payments) if(payment.accountId===account.id && !payment.reversed && payment.status !== 'scheduled' && payment.status !== 'cancelled' && payment.balanceImpact !== false) total-=moneyCents(payment.amount);
  for(const transfer of transfers)if(transfer.accountId===account.id&&transfer.balanceImpact!==false){if(!Number.isSafeInteger(transfer.amountCents))throw new Error('Transferência precisa de conferência.');total+=transfer.amountCents;}
  if (!Number.isSafeInteger(total)) throw new Error('Saldo acima do limite permitido.');
  return total/100;
}
