export type FilterState = Record<string, string | number | boolean>;

const storageKey = (section: string) => `wise-wallet-filters-${section}`;
const queryKey = (section: string) => `ww-${section}`;

export const readFilterState = <T extends FilterState>(section: string, fallback: T): T => {
  if (typeof window === 'undefined') return fallback;
  const fromUrl = new URLSearchParams(window.location.search).get(queryKey(section));
  const fromStorage = window.sessionStorage.getItem(storageKey(section));
  for (const source of [fromUrl, fromStorage]) {
    if (!source) continue;
    try { return { ...fallback, ...(JSON.parse(source) as Partial<T>) }; } catch { /* ignore invalid saved state */ }
  }
  return fallback;
};

export const persistFilterState = (section: string, state: FilterState) => {
  if (typeof window === 'undefined') return;
  const serialized = JSON.stringify(state);
  window.sessionStorage.setItem(storageKey(section), serialized);
  const url = new URL(window.location.href);
  url.searchParams.set(queryKey(section), serialized);
  window.history.replaceState(null, '', `${url.pathname}${url.search}${url.hash}`);
};
