'use client';

import { useEffect, useMemo, useState } from 'react';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { firestore } from './lib/firebase';
import { buildAccountStatement, AccountStatement, StatementEntry, StatementInputRow, StatementLedgerEntry } from './statement-domain';
import { ResponsiveDialog } from './design-system/dialog';
import { moneyTone } from './design-system/money-tone';

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const signedMoney = (value: number) => `${value >= 0 ? '+' : '−'}${money.format(Math.abs(value))}`;
const dayLabel = (date: string) => new Date(`${date}T12:00:00`).toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });

export function AccountStatementDialog({ account, transactions, cardPayments, onClose }: {
  account: { id: string; name: string; version?: number; serverBalance?: number; openingBalance: number; openingDate?: string };
  transactions: StatementInputRow[];
  cardPayments: StatementInputRow[];
  onClose: () => void;
}) {
  const [ledger, setLedger] = useState<StatementLedgerEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  useEffect(() => {
    if (!firestore) return;
    let mounted = true;
    const load = async () => {
      try {
        const snapshot = await getDocs(query(collection(firestore!, 'households', 'family-wallet', 'ledgerEntries'), where('accountId', '==', account.id)));
        if (mounted) setLedger(snapshot.docs.map((entry) => ({ id: entry.id, ...(entry.data() as object) }) as StatementLedgerEntry));
      } catch { if (mounted) setLoadError(true); } finally { if (mounted) setLoading(false); }
    };
    void load();
    return () => { mounted = false; };
  }, [account.id]);

  const statement: AccountStatement = useMemo(() => buildAccountStatement({ account, ledger, transactions, cardPayments }), [account, ledger, transactions, cardPayments]);

  return <ResponsiveDialog open title={`Extrato · ${account.name}`} onClose={onClose}>
    <div className="statement-dialog">
      <div className="statement-flags">
        {statement.partial && <span className="chip planned-chip">Extrato parcial</span>}
        {statement.consistent ? <span className="chip realized-chip">Saldo consistente</span> : <span className="chip card-chip">Divergência de saldo</span>}
      </div>
      {statement.reasons.map((reason) => <p className="form-help statement-reason" key={reason} role="status">{reason}</p>)}
      <div className="statement-opening"><span>Saldo inicial{statement.openingKnown ? '' : ' (estimado)'}</span><b className={moneyTone(statement.openingCents ?? 0)}>{signedMoney((statement.openingCents ?? 0) / 100)}</b></div>
      {loading && <p className="form-help">Organizando lançamentos…</p>}
      {!loading && loadError && <p className="form-help">Não foi possível ler a razão contábil desta conta.</p>}
      {!loading && !statement.days.length && <p className="empty-state statement-empty">Nenhum lançamento encontrado para esta conta.</p>}
      <ol className="statement-days">
        {statement.days.map((day) => (
          <li key={day.date}>
            <header><span>{dayLabel(day.date)}</span>{day.runningKnown && <b className={moneyTone(day.runningCents ?? 0)}>{signedMoney((day.runningCents ?? 0) / 100)}</b>}</header>
            <ul>
              {day.entries.map((entry: StatementEntry) => (
                <li key={entry.id}><span><strong>{entry.label}</strong>{entry.detail && <small>{entry.detail}</small>}</span><b className={entry.amountCents >= 0 ? 'income' : 'expense'}>{entry.balanceImpact ? signedMoney(entry.amountCents / 100) : `${entry.amountCents >= 0 ? '+' : '−'}${money.format(Math.abs(entry.amountCents) / 100)}`}</b></li>
              ))}
            </ul>
          </li>
        ))}
      </ol>
      <footer className="statement-closing">
        <div><span>Saldo reconstruído</span><b className={moneyTone(statement.closingCents ?? 0)}>{statement.closingCents == null ? '—' : signedMoney(statement.closingCents / 100)}</b></div>
        {statement.storedCents != null && <div><span>Saldo armazenado</span><b className={moneyTone(statement.storedCents)}>{signedMoney(statement.storedCents / 100)}</b></div>}
      </footer>
    </div>
  </ResponsiveDialog>;
}