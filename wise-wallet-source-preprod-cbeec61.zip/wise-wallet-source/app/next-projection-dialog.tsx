'use client';

import {MaybeDialog} from './maybe-ui/dialog';
import { useEffect, useState } from 'react';
import type { FinanceSummary } from './finance-summary';

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

export function NextProjectionDialog() {
  const [summary, setSummary] = useState<FinanceSummary | null>(null);

  useEffect(() => {
    const handle = (event: MouseEvent) => {
      const element = event.target instanceof Element ? event.target.closest('.summary-card.accent:not(button)') : null;
      if (!element || !element.textContent?.includes('Resultado projetado')) return;
      event.preventDefault();
      const saved = window.sessionStorage.getItem('wise-wallet-finance-summary');
      if (!saved) return;
      try { setSummary(JSON.parse(saved) as FinanceSummary); } catch { setSummary(null); }
    };
    document.addEventListener('click', handle);
    return () => document.removeEventListener('click', handle);
  }, []);

  if (!summary) return null;
  return <MaybeDialog title="Projeção do próximo mês" onClose={()=>setSummary(null)}>
      <p className="formula">Receitas previstas − despesas previstas, incluindo parcelas e recorrências</p>
      <dl className="calculation">
        <div><dt>+ Receitas previstas e recorrentes</dt><dd>{money.format(summary.nextPlannedIncomeCents / 100)}</dd></div>
        <div><dt>− Despesas previstas, parcelas e recorrentes</dt><dd>{money.format(summary.nextPlannedExpenseCents / 100)}</dd></div>
        <div className="total"><dt>Resultado projetado</dt><dd>{money.format(summary.nextMonthProjectedCents / 100)}</dd></div>
      </dl>
      <p className="calculation-note">O período termina em {new Date(`${summary.nextMonthTargetDate}T12:00:00`).toLocaleDateString('pt-BR')}. Pagamentos de fatura não são somados novamente: a despesa já é considerada nas compras do cartão.</p>
  </MaybeDialog>;
}
