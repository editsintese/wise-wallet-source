const accountTypes={checking:'Corrente',savings:'Poupança',cash:'Dinheiro',other:'Investimento',benefit:'Benefício / pré-pago'} as const;
const canonicalTypes={Corrente:'checking',Poupança:'savings',Dinheiro:'cash',Investimento:'other','Benefício / pré-pago':'benefit'} as const;

export const accountTypeFromCanonical=(value:unknown)=>accountTypes[value as keyof typeof accountTypes]||String(value||'Corrente');
export const accountTypeToCanonical=(value:string)=>canonicalTypes[value as keyof typeof canonicalTypes]||'other';
export const isBenefitAccount=(value:string)=>value==='benefit'||value==='Benefício / pré-pago';

export function accountFromDoc(id:string,data:Record<string,unknown>){
 const canonical=Number.isSafeInteger(data.openingBalanceCents);
 return {id,...(Number.isSafeInteger(data.legacyRevision)?{legacyRevision:Number(data.legacyRevision)}:{}),name:String(data.name||''),type:accountTypeFromCanonical(data.type),openingBalance:canonical?Number(data.openingBalanceCents)/100:Number(data.openingBalance||0),version:canonical?Number(data.version):undefined,serverBalance:canonical&&Number.isSafeInteger(data.balanceCents)?Number(data.balanceCents)/100:undefined,...(canonical&&data.bankCheckedAt&&data.bankBalanceStale!==true&&Number.isSafeInteger(data.bankBalanceCents)?{bankBalance:Number(data.bankBalanceCents)/100}:{}),...(data.bankCheckedAt?{bankCheckedAt:String(data.bankCheckedAt)}:{}),...(data.holder?{holder:String(data.holder)}:{}),...(Number(data.conferenceDay)?{conferenceDay:Number(data.conferenceDay)}:{}),...(data.observations?{observations:String(data.observations)}:{}),openingDate:canonical?String(data.openingDate):undefined,archived:data.archived===true||data.archivedAt!=null};
}

export function transactionFromDoc(id:string,data:Record<string,unknown>){
 const canonical=Number.isSafeInteger(data.amountCents);
 return {id,...data,description:String(data.description||''),category:String(data.category||'Sem categoria'),subcategory:String(data.subcategory||data.subcategoria||'')||undefined,owner:String(data.owner||'Família'),amount:canonical?Number(data.amountCents)/100:Number(data.amount||0),kind:(canonical?data.type:data.kind) as 'income'|'expense',status:String(data.status||'planned') as 'realized'|'planned',rawDate:String(canonical?(data.competenceDate||data.dueDate||data.purchaseDate):data.transactionDate),purchaseDate:String(data.purchaseDate||data.transactionDate||''),paidAt:canonical?(data.settlementDate?String(data.settlementDate):undefined):(data.paidAt?String(data.paidAt):undefined),archived:data.status==='cancelled'||(canonical?data.archivedAt!=null:data.archived===true),clientGeneration:String(data.clientGeneration||'')||undefined,version:canonical?Number(data.version):undefined};
}
