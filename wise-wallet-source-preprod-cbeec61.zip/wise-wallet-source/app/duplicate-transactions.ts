import type {TransactionView} from './transaction-model.ts';
type Candidate=TransactionView&{isRecurrenceForecast?:boolean;balanceImpact?:boolean};
/** Possible duplicates only: never remove, merge, settle or change a financial record. */
export function duplicateTransactions(items:Candidate[]):Map<string,string[]>{
 const groups=new Map<string,Set<string>>();const normalize=(value:unknown)=>String(value??'').normalize('NFC').trim().replace(/\s+/g,' ').toLocaleLowerCase('pt-BR');
 for(const item of items){if(item.isRecurrenceForecast||String(item.status)==='cancelled'||!Number.isFinite(item.amount)||item.amount<=0)continue;
  const key=JSON.stringify([normalize(item.description),Math.round(item.amount*100),item.kind,item.status,item.rawDate,item.paidAt||'',item.accountId||'',item.cardId||'',normalize(item.category),normalize(item.subcategory),normalize(item.owner),item.installmentNumber||0,item.installmentCount||0,Boolean(item.historicalOnly),item.balanceImpact===false]);
  if(!groups.has(key))groups.set(key,new Set());groups.get(key)!.add(item.id);
 }
 const result=new Map<string,string[]>();for(const ids of groups.values())if(ids.size>1)for(const id of ids)result.set(id,[...ids]);return result;
}
