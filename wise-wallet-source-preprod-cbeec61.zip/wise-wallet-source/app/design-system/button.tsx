import type {ButtonHTMLAttributes} from 'react';
import {MaybeButton} from '../maybe-ui/primitives';
export type ButtonVariant = 'primary' | 'secondary' | 'text' | 'danger' | 'icon';
export function Button({variant='primary',className='',...props}:ButtonHTMLAttributes<HTMLButtonElement>&{variant?:ButtonVariant}){return <MaybeButton {...props} variant={variant==='secondary'?'outline':variant==='text'||variant==='icon'?'ghost':variant} data-variant={variant} className={`${variant==='icon'?'mb-icon-button ':''}${className}`}/>}
