'use client';

import { useEffect, useState, type InputHTMLAttributes } from 'react';

const MONTHS = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

const capitalized = (value: string) => value.charAt(0).toUpperCase() + value.slice(1);

/**
 * Portuguese label for a native date/month value.
 * iOS and Android format the native picker with the device locale, so the app draws
 * its own text on touch devices while keeping the native picker underneath.
 */
export function formatTemporalValue(type: 'date' | 'month', raw: string) {
  const match = /^(\d{4})-(\d{2})(?:-(\d{2}))?$/.exec(raw);
  if (!match) return raw;
  const [, year, month, day] = match;
  const monthName = MONTHS[Number(month) - 1] || '';
  if (!monthName) return raw;
  if (type === 'month') return `${capitalized(monthName)} de ${year}`;
  return `${Number(day)} ${monthName.slice(0, 3)} ${year}`;
}

type TemporalInputProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & {
  type: 'date' | 'month';
  emptyLabel?: string;
};

/**
 * Native date/month input with a layout-stable, localized value layer.
 * The native control keeps form semantics (name, value, picker); the visible text is
 * rendered by the app only on touch devices, where the native picker paints its own
 * (device-locale) text and intrinsic size.
 */
export function TemporalInput({ type, value, defaultValue, onChange, emptyLabel, ...props }: TemporalInputProps) {
  const controlValue = value === undefined ? undefined : String(value);
  const initialValue = controlValue ?? (defaultValue === undefined ? '' : String(defaultValue));
  const [liveValue, setLiveValue] = useState(initialValue);

  useEffect(() => {
    if (controlValue !== undefined) setLiveValue(controlValue);
  }, [controlValue]);

  const shownValue = controlValue ?? liveValue;
  const fallback = emptyLabel ?? (type === 'month' ? 'Selecionar mês' : 'Selecionar data');

  return (
    <span className="ww-temporal" data-empty={shownValue ? undefined : 'true'}>
      <input
        {...props}
        type={type}
        lang="pt-BR"
        value={controlValue}
        defaultValue={controlValue === undefined ? defaultValue : undefined}
        onChange={(event) => {
          if (controlValue === undefined) setLiveValue(event.target.value);
          onChange?.(event);
        }}
      />
      <span className="ww-temporal-value" aria-hidden="true">
        {shownValue ? formatTemporalValue(type, shownValue) : fallback}
      </span>
    </span>
  );
}
