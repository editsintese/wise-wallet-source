import type { HTMLAttributes, ReactNode } from 'react';

export function SurfaceCard({ children, className = '', ...props }: HTMLAttributes<HTMLElement> & { children: ReactNode }) {
  return <section {...props} className={`ww-card ${className}`.trim()}>{children}</section>;
}
