export function FeedbackState({ tone = 'info', children }: { tone?: 'info' | 'success' | 'error' | 'empty'; children: React.ReactNode }) {
  return <p className="ww-feedback" data-tone={tone} role={tone === 'error' ? 'alert' : 'status'}>{children}</p>;
}
