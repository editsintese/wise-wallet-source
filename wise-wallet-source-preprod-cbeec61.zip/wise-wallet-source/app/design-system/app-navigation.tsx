export const mobileDestinations = ['Visão geral', 'Transações', 'Contas', 'Cartões', 'Recorrências'] as const;

type Props = {
  activeSection: string;
  destinations: readonly string[];
  onNavigate(section: string): void;
  mobile?: boolean;
  onClose?(): void;
};

function NavigationIcon({ name }: { name: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {name === 'Visão geral' && <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></>}
    {(name === 'Transações' || name === 'Lançamentos') && <><path d="M7 4h10v16H7z"/><path d="M9.5 8h5M9.5 12h5M9.5 16h3"/></>}
    {name === 'Importação (ensaio)' && <><path d="M12 3v11M8 10l4 4 4-4"/><path d="M5 15v5h14v-5"/></>}
    {name === 'Calendário' && <><rect x="3" y="5" width="18" height="16" rx="1"/><path d="M7 3v4M17 3v4M3 10h18M7 14h.01M12 14h.01M17 14h.01M7 17h.01M12 17h.01"/></>}
    {name === 'Contas' && <><path d="m3 9 9-6 9 6"/><path d="M5 10h14M6 19h12M8 10v8M12 10v8M16 10v8M4 21h16"/></>}
    {name === 'Cartões' && <><rect x="3" y="5" width="18" height="14" rx="1"/><path d="M3 9h18M7 15h4"/></>}
    {name === 'Recorrências' && <><path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9a7 7 0 0 1 11.9-2L20 12M4 12l2.5 5a7 7 0 0 0 11.9-2"/></>}
    {(name === 'Planejamento' || name === 'Investimentos') && <><path d="M4 19V5M4 19h17"/><path d="m7 15 4-4 3 2 5-6"/><path d="M16 7h3v3"/></>}
    {name === 'Análises' && <><path d="M4 19V5M4 19h17"/><rect x="7" y="12" width="3" height="4"/><rect x="12" y="9" width="3" height="7"/><rect x="17" y="6" width="3" height="10"/></>}
    {name === 'Relatórios' && <><path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 12h7M9 16h7"/></>}
    {(name === 'Categorias' || name === 'Cadastros') && <><path d="M4 5h16M4 12h16M4 19h16"/><circle cx="8" cy="5" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="10" cy="19" r="2"/></>}
    {!['Visão geral','Transações','Lançamentos','Calendário','Contas','Cartões','Recorrências','Planejamento','Investimentos','Análises','Relatórios','Categorias','Cadastros','Importação (ensaio)'].includes(name) && <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>}
  </svg>;
}

export function AppNavigation({ activeSection, destinations, onNavigate, mobile = false, onClose }: Props) {
  const renderItem = (item: string) => <button aria-current={activeSection === item ? 'page' : undefined} className={activeSection === item ? 'nav-item active' : 'nav-item'} key={item} onClick={() => { onNavigate(item); onClose?.(); }}><span className="nav-icon" aria-hidden="true"><NavigationIcon name={item}/></span><small>{item}</small></button>;
  return <nav aria-label={mobile ? 'Navegação móvel' : 'Navegação principal'} className={mobile ? 'bottom-nav' : 'app-navigation'}>
    {destinations.map(renderItem)}
  </nav>;
}
