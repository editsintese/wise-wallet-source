type InstitutionContext = 'account' | 'card' | 'investment';

type LogoEntry = { file: string; label: string };

const logos: Record<string, LogoEntry> = {
  alelo: { file: 'alelo.png', label: 'Alelo' },
  amazon: { file: 'amazon.png', label: 'Amazon' },
  bv: { file: 'bv.png', label: 'BV' },
  inter: { file: 'inter.png', label: 'Inter' },
  itau: { file: 'itau.png', label: 'Itaú' },
  mercadopago: { file: 'mercado-pago.png', label: 'Mercado Pago' },
  porto: { file: 'porto-seguro.png', label: 'Porto Seguro' },
  santander: { file: 'santander.png', label: 'Santander' },
  xp: { file: 'xp.png', label: 'XP' },
};

function institutionKey(name: string, context: InstitutionContext) {
  const normalized = name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR');
  if (context === 'card') {
    if (/\bfree\b/.test(normalized)) return 'santander';
    if (/\bxp\b/.test(normalized)) return 'xp';
    if (/amazon/.test(normalized)) return 'amazon';
    if (/\bporto\b/.test(normalized)) return 'porto';
  }
  if (/mercado\s*pago|mercadopago/.test(normalized)) return 'mercadopago';
  if (/\balelo\b/.test(normalized)) return 'alelo';
  if (/\bsantander\b/.test(normalized)) return 'santander';
  if (/\binter\b/.test(normalized)) return 'inter';
  if (/\bitau\b/.test(normalized)) return 'itau';
  if (/\bxp\b/.test(normalized)) return 'xp';
  if (/\bporto\b/.test(normalized)) return 'porto';
  if (/amazon/.test(normalized)) return 'amazon';
  if (/\bbv\b/.test(normalized)) return 'bv';
  return null;
}

function AccountGlyph() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="m3 9 9-6 9 6M5 10h14M6 19h12M8 10v8M12 10v8M16 10v8M4 21h16" /></svg>;
}

export function InstitutionLogo({ name, context, className = '' }: { name: string; context: InstitutionContext; className?: string }) {
  const key = institutionKey(name, context);
  const logo = key ? logos[key] : undefined;
  return <span className={`institution-logo ${logo ? 'has-institution-logo' : 'is-neutral'} ${className}`.trim()} aria-hidden={logo ? undefined : true}>
    {logo ? <img src={`/financial-institutions/${logo.file}?v=2`} alt={`Logo ${logo.label}`} loading="lazy" /> : <AccountGlyph />}
  </span>;
}
