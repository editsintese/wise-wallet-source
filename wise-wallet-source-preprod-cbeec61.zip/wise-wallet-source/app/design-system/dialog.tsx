'use client';
import type {ReactNode} from 'react';
import {MaybeDialog} from '../maybe-ui/dialog';
export function ResponsiveDialog({open,title,onClose,children}:{open:boolean;title:string;onClose():void;children:ReactNode}){return open?<MaybeDialog title={title} onClose={onClose}>{children}</MaybeDialog>:null}
