import type { ReactNode } from 'react';

export type ChipTone = 'category' | 'subcategory' | 'owner' | 'status' | 'account' | 'payment' | 'neutral';

export function Chip({ tone, children }: { tone: ChipTone; children: ReactNode }) {
  return <span className="ww-chip chip" data-tone={tone}>{children}</span>;
}
