import { useEffect, useRef } from 'react';

/** Own only the navigation drawer; financial dialogs retain their existing behavior. */
export function useNavigationDrawer(open: boolean, onClose: () => void) {
  const ref = useRef<HTMLElement>(null);
  const close = useRef(onClose);
  close.current = onClose;
  useEffect(() => {
    if (!open || !ref.current) return;
    const drawer = ref.current;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const workspace = document.querySelector<HTMLElement>('.workspace');
    const backgrounds = Array.from(document.querySelectorAll<HTMLElement>('.workspace, .sidebar'));
    const states = backgrounds.map(element => ({ element, inert: element.inert }));
    const overflow = workspace?.style.overflowY || '';
    states.forEach(({element}) => { element.inert = true; });
    if (workspace) workspace.style.overflowY = 'hidden';
    const controls = () => Array.from(drawer.querySelectorAll<HTMLElement>('button:not(:disabled), summary, a[href], [tabindex="0"]')).filter(element => element.getClientRects().length > 0);
    (controls()[0] || drawer).focus({preventScroll:true});
    const keydown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); close.current(); }
      if (event.key !== 'Tab') return;
      const elements = controls(), first = elements[0], last = elements[elements.length-1];
      if (!first) { event.preventDefault(); drawer.focus(); return; }
      if (event.shiftKey && (document.activeElement === first || !drawer.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !drawer.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    };
    const desktop = window.matchMedia('(min-width: 901px)');
    const resize = () => { if (desktop.matches) close.current(); };
    drawer.addEventListener('keydown', keydown);
    desktop.addEventListener('change', resize);
    resize();
    return () => {
      drawer.removeEventListener('keydown', keydown);
      desktop.removeEventListener('change', resize);
      states.forEach(({element,inert}) => { element.inert = inert; });
      if (workspace) workspace.style.overflowY = overflow;
      if (previousFocus?.isConnected) previousFocus.focus({preventScroll:true});
    };
  }, [open]);
  return ref;
}
