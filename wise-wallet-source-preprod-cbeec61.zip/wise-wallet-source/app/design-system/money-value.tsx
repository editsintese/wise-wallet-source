const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

export function MoneyValue({ value, size = 'body', showPositiveSign = true }: { value: number; size?: 'body' | 'large'; showPositiveSign?: boolean }) {
  const semantic = value < 0 ? 'expense' : value > 0 ? 'income' : 'neutral';
  const sign = value < 0 ? '−' : value > 0 && showPositiveSign ? '+' : '';
  return <strong className={`ww-money ${semantic}`} data-size={size}>{sign}{money.format(Math.abs(value))}</strong>;
}
