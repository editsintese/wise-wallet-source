// Compatibility API; presentation delegates to the canonical Clareza record row.
export {RecordFinancialRow as FinancialListItem} from '../maybe-ui/record-row';
