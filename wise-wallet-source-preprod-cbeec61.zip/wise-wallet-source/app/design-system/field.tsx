import type {InputHTMLAttributes,ReactNode,SelectHTMLAttributes} from 'react';
type BaseProps={label:string;hint?:string;children:ReactNode};
export function Field({label,hint,children}:BaseProps){return <label className="mb-field"><span className="mb-field-label">{label}</span>{children}{hint&&<small className="mb-field-hint">{hint}</small>}</label>}
export function TextField({label,hint,...props}:InputHTMLAttributes<HTMLInputElement>&{label:string;hint?:string}){return <Field label={label} hint={hint}><input {...props}/></Field>}
export function SelectField({label,hint,children,...props}:SelectHTMLAttributes<HTMLSelectElement>&{label:string;hint?:string;children:ReactNode}){return <Field label={label} hint={hint}><select {...props}>{children}</select></Field>}
export function SegmentedControl({label,children}:{label:string;children:ReactNode}){return <fieldset className="mb-segmented"><legend>{label}</legend><div className="mb-type-tabs">{children}</div></fieldset>}
