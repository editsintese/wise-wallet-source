'use client';

import { InputHTMLAttributes, useState } from 'react';

export function formatCurrencyInput(value: string | number | undefined) {
  const digits = String(value ?? '').replace(/\D/g, '').replace(/^0+(?=\d)/, '') || '0';
  const padded = digits.padStart(3, '0');
  return `${padded.slice(0, -2)} , ${padded.slice(-2)}`.replace(' , ', ',');
}

export function formatCurrencyAmount(value: number | undefined) {
  return formatCurrencyInput(String(Math.round((Number(value) || 0) * 100)));
}

type Props = Omit<InputHTMLAttributes<HTMLInputElement>, 'defaultValue' | 'onChange' | 'value'> & {
  defaultValue?: string | number;
  value?: string;
  onValueChange?(value: string): void;
  allowEmpty?: boolean;
};

export function CurrencyInput({ defaultValue, value, onValueChange, allowEmpty = false, ...props }: Props) {
  const [uncontrolled, setUncontrolled] = useState(() => allowEmpty && (defaultValue === undefined || defaultValue === '') ? '' : typeof defaultValue === 'number' ? formatCurrencyAmount(defaultValue) : formatCurrencyInput(defaultValue));
  const current = value ?? uncontrolled;
  return <input {...props} className={`currency-input ${props.className || ''}`.trim()} inputMode="numeric" value={current} onChange={(event) => {
    const next = allowEmpty && !event.currentTarget.value.replace(/\D/g, '') ? '' : formatCurrencyInput(event.currentTarget.value);
    if (value === undefined) setUncontrolled(next);
    onValueChange?.(next);
  }} />;
}
