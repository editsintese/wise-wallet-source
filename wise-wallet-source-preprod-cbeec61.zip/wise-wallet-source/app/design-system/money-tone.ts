/** Color a financial amount by its signed meaning; exact zero stays neutral. */
export function moneyTone(value: number): 'income' | 'expense' | 'neutral' {
  return value > 0 ? 'income' : value < 0 ? 'expense' : 'neutral';
}
