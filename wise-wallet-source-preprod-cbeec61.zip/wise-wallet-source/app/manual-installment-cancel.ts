import {manualInstallmentReview} from '../packages/finance-domain/bulk-transactions.mjs';
type Row={id:string;amount:number;status:string;rawDate:string;cardId?:string;recurrenceId?:string;investmentId?:string;historicalOnly?:boolean;archived?:boolean;paidAt?:string;installmentGroupId?:string;installmentCount?:number;installmentNumber?:number};
export function planManualInstallmentCancellation(selected:Row,transactions:Row[]){
 const rows=transactions.filter(row=>row.installmentGroupId===selected.installmentGroupId).sort((a,b)=>(a.installmentNumber||0)-(b.installmentNumber||0));
 const count=selected.installmentCount||0,numbers=new Set(rows.map(row=>row.installmentNumber));
 const incomplete=!selected.installmentGroupId||count<2||count>120||rows.length!==count||numbers.size!==count||rows.some(row=>row.installmentCount!==count||!Number.isInteger(row.installmentNumber)||row.installmentNumber!<1||row.installmentNumber!>count);
 const blocked=incomplete?'O grupo está incompleto ou inconsistente. Nenhuma parcela será cancelada.':rows.some(row=>row.status!=='planned'||row.paidAt)?'Há parcela realizada, cancelada ou com pagamento registrado. O grupo inteiro foi bloqueado.':rows.some(row=>row.archived||row.cardId||row.recurrenceId||row.investmentId||row.historicalOnly)?'Há parcela arquivada ou com vínculo incompatível. Confira o grupo antes de cancelar.':'';
 let totalCents=0;for(const row of rows){const cents=Math.round(row.amount*100);if(!Number.isSafeInteger(cents)||cents<=0||Math.abs(row.amount-cents/100)>1e-7||!Number.isSafeInteger(totalCents+cents))return {rows,totalCents:0,blocked:'Há valor inválido no grupo. Nenhuma parcela será cancelada.'};totalCents+=cents;}
 return {rows,totalCents,blocked};
}

export async function manualInstallmentReviewHash(rows:Row[]){const bytes=new TextEncoder().encode(JSON.stringify(manualInstallmentReview(rows)));const digest=await crypto.subtle.digest('SHA-256',bytes);return Array.from(new Uint8Array(digest),byte=>byte.toString(16).padStart(2,'0')).join('');}
