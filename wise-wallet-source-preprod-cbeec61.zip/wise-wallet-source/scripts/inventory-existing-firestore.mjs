import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {auditLegacy} from './audit-legacy-finance.mjs';

const require=createRequire(import.meta.url);
const auth=require('firebase-tools/lib/auth');
const apiv2=require('firebase-tools/lib/apiv2');

const projectId=process.argv[2];
if(!projectId||!/^[a-z][a-z0-9-]{4,29}$/.test(projectId))throw new Error('project-id-required');
const account=auth.getGlobalDefaultAccount();
if(!account?.tokens?.refresh_token)throw new Error('firebase-login-required');
apiv2.setRefreshToken(account.tokens.refresh_token);
const client=new apiv2.Client({urlPrefix:'https://firestore.googleapis.com',apiVersion:'v1'});
const root=`/projects/${projectId}/databases/(default)/documents`;

function decode(value){
 if(!value||typeof value!=='object')return null;
 if('nullValue'in value)return null;if('stringValue'in value)return value.stringValue;if('booleanValue'in value)return value.booleanValue;
 if('integerValue'in value)return Number(value.integerValue);if('doubleValue'in value)return Number(value.doubleValue);if('timestampValue'in value)return value.timestampValue;
 if('arrayValue'in value)return (value.arrayValue.values||[]).map(decode);
 if('mapValue'in value)return decodeFields(value.mapValue.fields||{});
 return undefined;
}
function decodeFields(fields){return Object.fromEntries(Object.entries(fields||{}).map(([key,value])=>[key,decode(value)]));}
const fieldKind=value=>Object.keys(value||{})[0]||'unknown';

async function listCollectionIds(parent){
 const response=await client.post(`${root}/${parent}:listCollectionIds`,{pageSize:100});return response.body.collectionIds||[];
}
async function listDocuments(parent,collectionId){
 const rows=[];let pageToken;
 do{const response=await client.get(`${root}/${parent}/${collectionId}`,{queryParams:{pageSize:300,...(pageToken?{pageToken}:{})}});rows.push(...(response.body.documents||[]));pageToken=response.body.nextPageToken;}while(pageToken);
 return rows;
}

const parent='households/family-wallet';
const collectionIds=(await listCollectionIds(parent)).sort();
const inventory={},decodedByCollection={};let legacyTransactions=[];
for(const collectionId of collectionIds){
 const documents=await listDocuments(parent,collectionId);const fields={};
 for(const document of documents)for(const [name,value]of Object.entries(document.fields||{})){const kind=fieldKind(value);fields[name]??={};fields[name][kind]=(fields[name][kind]||0)+1;}
 inventory[collectionId]={documents:documents.length,fields};
 decodedByCollection[collectionId]=documents.map(document=>({id:document.name.split('/').at(-1),...decodeFields(document.fields)}));
 if(collectionId==='transactions')legacyTransactions=decodedByCollection[collectionId];
}
const toCents=value=>{const cents=Math.round(value*100);return Number.isFinite(value)&&Math.abs(value-cents/100)<=Math.min(1e-7,Number.EPSILON*Math.max(1,Math.abs(value))*2)?cents:null;};
const transactions=decodedByCollection.transactions||[],payments=decodedByCollection.cardPayments||[];
const accounts=(decodedByCollection.accounts||[]).map(account=>{
 const cash=transactions.filter(item=>item.accountId===account.id&&!item.cardId&&item.status==='realized').reduce((sum,item)=>sum+(item.kind==='income'?1:-1)*(toCents(item.amount)||0),0);
 const cardPayments=payments.filter(item=>item.accountId===account.id).reduce((sum,item)=>sum+(toCents(item.amount)||0),0);
 const opening=toCents(account.openingBalance);
 return {id:account.id,type:account.type,openingBalanceCents:opening,cashTransactionNetCents:cash,cardPaymentCents:cardPayments,legacyDisplayedBalanceCents:opening===null?null:opening+cash-cardPayments};
});
const labelPatterns=transactions.filter(item=>item.installmentLabel).reduce((result,item)=>{const pattern=/^\d+\s*\/\s*\d+$/.test(String(item.installmentLabel))?'fraction':String(item.installmentLabel).replace(/\d+/g,'#').slice(0,80);result[pattern]=(result[pattern]||0)+1;return result;},{});
const mappingReview={accounts,labelPatterns,invalidAmountTransactions:transactions.filter(item=>toCents(item.amount)===null||toCents(item.amount)<=0).map(item=>({id:item.id,amount:item.amount,fingerprint:createHash('sha256').update(String(item.description||'')).digest('hex').slice(0,12)})),installmentMetadata:{labels:transactions.filter(item=>item.installmentLabel).length,withNumber:transactions.filter(item=>Number.isInteger(item.installmentNumber)).length,withGroup:transactions.filter(item=>typeof item.installmentGroupId==='string'&&item.installmentGroupId).length}};
const report={schemaVersion:1,mode:'read-only-existing-base-inventory',projectId,householdId:'family-wallet',generatedAt:new Date().toISOString(),collections:inventory,mappingReview,transactionAudit:auditLegacy(legacyTransactions)};
const target=resolve('work','migration','existing-base-inventory.json');await mkdir(resolve('work','migration'),{recursive:true});await writeFile(target,`${JSON.stringify(report,null,2)}\n`,{encoding:'utf8',flag:'w'});
process.stdout.write(`${JSON.stringify({projectId,householdId:'family-wallet',collections:Object.fromEntries(Object.entries(inventory).map(([name,value])=>[name,value.documents])),transactionAudit:report.transactionAudit,report:target},null,2)}\n`);
