import assert from 'node:assert/strict';
import {
  dateForBasis,
  isRecentOccurrence,
  matchesSearch,
  sortTransactions,
} from '../app/transaction-model.ts';

const purchase = {
  id: 'purchase', description: 'Compra de hoje', amount: 120, kind: 'expense', status: 'realized',
  rawDate: '2026-10-05', purchaseDate: '2026-09-01', category: 'Compras', owner: 'Família',
  cardId: 'card', installmentNumber: 1, installmentCount: 3,
};
const futureInstallment = { ...purchase, id: 'future', rawDate: '2026-11-05', installmentNumber: 2, status: 'planned' };

assert.equal(isRecentOccurrence(purchase, '2026-09-01'), true, 'a compra de hoje deve aparecer nos recentes');
assert.equal(isRecentOccurrence(futureInstallment, '2026-09-01'), false, 'parcelas futuras não devem ocupar os recentes');
assert.equal(dateForBasis(purchase, 'occurrence'), '2026-09-01');
assert.equal(dateForBasis(purchase, 'competence'), '2026-10-05');
assert.equal(matchesSearch(purchase, 'familia'), true, 'a busca deve ignorar acentos');
assert.deepEqual(sortTransactions([purchase, { ...purchase, id: 'larger', amount: 500 }], 'amount-desc').map((item) => item.id), ['larger', 'purchase']);
assert.deepEqual(
  sortTransactions([
    { ...purchase, id: 'earlier-purchase', purchaseDate: '2026-08-28', rawDate: '2026-10-05' },
    { ...purchase, id: 'later-purchase', purchaseDate: '2026-09-10', rawDate: '2026-10-05' },
  ], 'date-desc').map((item) => item.id),
  ['later-purchase', 'earlier-purchase'],
  'a ordenação cronológica deve usar a data da compra, não a competência da fatura',
);
assert.deepEqual(
  sortTransactions([
    { ...purchase, id: 'older', createdAt: { seconds: 10 } },
    { ...purchase, id: 'newer', createdAt: { seconds: 20 } },
  ], 'date-desc').map((item) => item.id),
  ['newer', 'older'],
  'lançamentos do mesmo dia devem priorizar o cadastro mais recente',
);

console.log('Transaction model checks passed.');
