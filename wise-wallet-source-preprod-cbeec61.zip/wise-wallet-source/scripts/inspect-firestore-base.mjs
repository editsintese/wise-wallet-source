import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const auth = require('firebase-tools/lib/auth');
const apiv2 = require('firebase-tools/lib/apiv2');
const projectId = process.argv[2] || 'your-firebase-project';
const account = auth.getGlobalDefaultAccount();
if (!account?.tokens?.refresh_token) throw new Error('firebase-login-required');
apiv2.setRefreshToken(account.tokens.refresh_token);
const client = new apiv2.Client({ urlPrefix: 'https://firestore.googleapis.com', apiVersion: 'v1' });
const root = `/projects/${projectId}/databases/(default)/documents`;
const decode = (value) => {
  if ('nullValue' in value) return null;
  if ('stringValue' in value) return value.stringValue;
  if ('booleanValue' in value) return value.booleanValue;
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return value.timestampValue;
  return undefined;
};
const fields = (data) => Object.fromEntries(Object.entries(data || {}).map(([key, value]) => [key, decode(value)]));
async function list(collection) {
  const response = await client.get(`${root}/households/family-wallet/${collection}`, { queryParams: { pageSize: 300 } });
  return (response.body.documents || []).map((document) => ({ id: document.name.split('/').at(-1), ...fields(document.fields) }));
}
const [accounts, cards, investments] = await Promise.all([list('accounts'), list('cards'), list('investments')]);
console.log(JSON.stringify({ accounts, cards, investments }, null, 2));
