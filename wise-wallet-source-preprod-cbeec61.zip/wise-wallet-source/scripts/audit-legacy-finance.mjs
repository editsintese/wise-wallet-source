import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { civilDate, assertCents, sumCents } from '../packages/finance-domain/index.mjs';

// This audits an offline JSON array of legacy transactions, not a Firestore export.
// No credentials, network access, source mutation or personal fields in the report.
export function auditLegacy(rows) {
  if (!Array.isArray(rows)) throw new TypeError('expected-transaction-array');
  const issues = {};
  const flag = (code) => { issues[code] = (issues[code] || 0) + 1; };
  const ids = new Set();
  const groups = new Map();
  const totals = new Map();
  let validRows = 0;
  for (const row of rows) {
    if (!row || typeof row !== 'object' || Array.isArray(row)) { flag('invalid-row'); continue; }
    let valid = true;
    const reject = (code) => { flag(code); valid = false; };
    if (typeof row.id !== 'string' || !row.id.trim()) reject('missing-id');
    else if (ids.has(row.id)) reject('duplicate-id');
    else ids.add(row.id);
    let cents;
    try {
      if (typeof row.amount !== 'number' || !Number.isFinite(row.amount) || row.amount <= 0) throw new Error();
      cents = assertCents(Math.round(row.amount * 100));
      // Accept IEEE-754 representation noise, not silent sub-cent rounding.
      if (cents <= 0 || Math.abs(row.amount - cents / 100) > Math.min(1e-7, Number.EPSILON * Math.max(1, Math.abs(row.amount)) * 2)) throw new Error();
    } catch { reject('invalid-or-subcent-amount'); }
    try { civilDate(row.transactionDate); } catch { reject('invalid-competence-date'); }
    for (const field of ['purchaseDate', 'paidAt']) {
      if (row[field] != null) { try { civilDate(row[field]); } catch { reject(`invalid-${field}`); } }
    }
    if (!['income', 'expense'].includes(row.kind)) reject('invalid-kind');
    if (!['planned', 'realized'].includes(row.status)) reject('invalid-status');
    if (row.archived != null && typeof row.archived !== 'boolean') reject('invalid-archive-flag');
    if (!row.purchaseDate) flag('purchase-date-needs-mapping');
    if (row.status === 'realized' && !row.cardId && !row.paidAt) flag('settlement-date-needs-mapping');
    if (row.archived) flag('archive-financial-semantics-review');
    if (row.installmentLabel) flag('legacy-installment-label-review');
    if (row.installmentGroupId) {
      const { installmentNumber: number, installmentCount: count } = row;
      if (!Number.isInteger(number) || !Number.isInteger(count) || number < 1 || count < 1 || count > 360 || number > count) reject('invalid-installment');
      else {
        const group = groups.get(row.installmentGroupId) || { count, numbers: new Set() };
        if (group.count !== count || group.numbers.has(number)) reject('inconsistent-installment-series');
        group.numbers.add(number);
        groups.set(row.installmentGroupId, group);
      }
    } else if (row.installmentNumber || row.installmentCount) reject('missing-installment-group');
    if (valid) {
      validRows++;
      const key = `${row.transactionDate.slice(0, 7)}|${row.kind}|${row.status}|${row.archived ? 'archived' : 'active'}`;
      const values = totals.get(key) || [];
      values.push(cents);
      totals.set(key, values);
    }
  }
  for (const group of groups.values()) if (group.numbers.size !== group.count) flag('incomplete-installment-series');
  const totalsCents = {};
  for (const [key, values] of [...totals.entries()].sort()) {
    try { totalsCents[key] = sumCents(values); } catch { flag('aggregate-overflow'); }
  }
  return {
    schemaVersion: 1, mode: 'read-only-audit', sourceRows: rows.length, validRows,
    rejectedRows: rows.length - validRows, issues, totalsCents,
    readyForMappingReview: Object.keys(issues).length === 0,
    migrationAuthorized: false,
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    if (process.argv.length !== 3) throw new Error();
    const report = auditLegacy(JSON.parse(await readFile(process.argv[2], 'utf8')));
    process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
    process.exitCode = report.readyForMappingReview ? 0 : 2;
  } catch {
    process.stderr.write('Audit failed: supply one readable JSON transaction array. No source data was changed.\n');
    process.exitCode = 1;
  }
}
