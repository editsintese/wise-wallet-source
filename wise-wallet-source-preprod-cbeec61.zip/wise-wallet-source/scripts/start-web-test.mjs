import {spawn} from 'node:child_process';
const child=spawn(process.execPath,['node_modules/next/dist/bin/next','dev','--hostname','127.0.0.1','--port','3022'],{
  stdio:'inherit',env:{...process.env,NEXT_PUBLIC_USE_FIREBASE_EMULATORS:'true',NEXT_PUBLIC_USE_COMMAND_BACKEND:'true',NEXT_PUBLIC_FIREBASE_API_KEY:'demo-key',NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN:'demo-wise-wallet-web.firebaseapp.com',NEXT_PUBLIC_FIREBASE_PROJECT_ID:'demo-wise-wallet-web',NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET:'demo-wise-wallet-web.appspot.com',NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID:'123456',NEXT_PUBLIC_FIREBASE_APP_ID:'demo-web-app'},
});
child.on('exit',code=>process.exit(code??1));
