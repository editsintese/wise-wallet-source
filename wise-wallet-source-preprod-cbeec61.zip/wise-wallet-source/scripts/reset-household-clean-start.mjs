import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const auth = require('firebase-tools/lib/auth');
const apiv2 = require('firebase-tools/lib/apiv2');

const projectId = process.argv[2] || 'your-firebase-project';
const householdId = 'family-wallet';
const apply = process.argv.includes('--apply');
if (projectId !== 'your-firebase-project') throw new Error('unexpected-project');

const account = auth.getGlobalDefaultAccount();
if (!account?.tokens?.refresh_token) throw new Error('firebase-login-required');
apiv2.setRefreshToken(account.tokens.refresh_token);

const client = new apiv2.Client({ urlPrefix: 'https://firestore.googleapis.com', apiVersion: 'v1' });
const root = `/projects/${projectId}/databases/(default)/documents`;
const householdPath = `households/${householdId}`;

function decode(value) {
  if (!value || typeof value !== 'object') return null;
  if ('nullValue' in value) return null;
  if ('stringValue' in value) return value.stringValue;
  if ('booleanValue' in value) return value.booleanValue;
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return value.timestampValue;
  if ('arrayValue' in value) return (value.arrayValue.values || []).map(decode);
  if ('mapValue' in value) return decodeFields(value.mapValue.fields || {});
  return null;
}

function decodeFields(fields) {
  return Object.fromEntries(Object.entries(fields || {}).map(([key, value]) => [key, decode(value)]));
}

function encode(value) {
  if (value === null) return { nullValue: null };
  if (typeof value === 'string') return { stringValue: value };
  if (typeof value === 'boolean') return { booleanValue: value };
  if (Number.isSafeInteger(value)) return { integerValue: String(value) };
  if (typeof value === 'number' && Number.isFinite(value)) return { doubleValue: value };
  if (Array.isArray(value)) return { arrayValue: { values: value.map(encode) } };
  if (typeof value === 'object') return { mapValue: { fields: Object.fromEntries(Object.entries(value).map(([key, item]) => [key, encode(item)])) } };
  throw new Error('unsupported-firestore-value');
}

async function listCollectionIds(parent) {
  const response = await client.post(`${root}/${parent}:listCollectionIds`, { pageSize: 100 });
  return response.body.collectionIds || [];
}

async function listDocuments(parent, collectionId) {
  const documents = [];
  let pageToken;
  do {
    const response = await client.get(`${root}/${parent}/${collectionId}`, {
      queryParams: { pageSize: 300, ...(pageToken ? { pageToken } : {}) },
    });
    documents.push(...(response.body.documents || []));
    pageToken = response.body.nextPageToken;
  } while (pageToken);
  return documents;
}

function zeroFields(document, keys, nullableKeys = []) {
  const current = decodeFields(document.fields);
  const values = {};
  for (const key of keys) if (Object.hasOwn(current, key)) values[key] = 0;
  for (const key of nullableKeys) if (Object.hasOwn(current, key)) values[key] = null;
  if (!Object.keys(values).length) return null;
  return {
    update: {
      name: document.name,
      fields: Object.fromEntries(Object.entries(values).map(([key, value]) => [key, encode(value)])),
    },
    updateMask: { fieldPaths: Object.keys(values) },
  };
}

const collections = await listCollectionIds(householdPath);
const documentsByCollection = new Map();
for (const collection of collections) {
  documentsByCollection.set(collection, await listDocuments(householdPath, collection));
}

const get = (name) => documentsByCollection.get(name) || [];
const archivedDocuments = [];
for (const [collection, documents] of documentsByCollection) {
  for (const document of documents) {
    const data = decodeFields(document.fields);
    const archived = data.archived === true || data.archivedAt != null || (collection === 'recurrences' && data.active === false);
    if (archived) archivedDocuments.push(document);
  }
}

const expected = {
  transactions: 590,
  recurrences: 37,
  categories: 1,
  cardPayments: 2,
  investmentMovements: 3,
  reconciliations: 3,
  recurrenceOccurrences: 3,
  nativeTransactions: 2,
};
for (const [collection, count] of Object.entries(expected)) {
  if (get(collection).length !== count) {
    throw new Error(`inventory-changed:${collection}:${get(collection).length}:expected-${count}`);
  }
}
if (archivedDocuments.length !== 628) throw new Error(`archived-inventory-changed:${archivedDocuments.length}`);

const deleteDocuments = [...archivedDocuments];
for (const document of archivedDocuments.filter((item) => item.name.includes('/transactions/'))) {
  if (decodeFields(document.fields).schemaVersion !== 1) continue;
  const subcollections = await listCollectionIds(document.name.slice((root + '/').length));
  for (const subcollection of subcollections) {
    for (const revision of await listDocuments(document.name.slice((root + '/').length), subcollection)) {
      deleteDocuments.push(revision);
    }
  }
}
for (const collection of ['cardPayments', 'investmentMovements', 'reconciliations', 'recurrenceOccurrences', 'nativeTransactions']) {
  deleteDocuments.push(...get(collection));
}

const writes = deleteDocuments.map((document) => ({ delete: document.name }));
const updates = [];
for (const document of get('accounts')) {
  const update = zeroFields(document, ['openingBalanceCents', 'balanceCents', 'bankBalanceCents', 'openingBalance', 'version', 'openingBalanceVersion'], ['bankCheckedAt']);
  if (update) {
    const fields = update.update.fields;
    for (const key of ['version', 'openingBalanceVersion']) {
      if (fields[key]) fields[key] = encode((decode(document.fields[key]) || 0) + 1);
    }
    updates.push(update);
  }
}
for (const document of get('cards')) {
  const update = zeroFields(document, ['availableFromBank', 'usedFromBank', 'currentInvoiceFromBank'], ['bankCheckedAt', 'invoiceCheckedAt']);
  if (update) updates.push(update);
}
for (const document of get('investments')) {
  const update = zeroFields(document, ['currentValue', 'investedValue'], ['referenceDate']);
  if (update) updates.push(update);
}
for (const document of get('budgetCategories')) {
  const update = zeroFields(document, ['valor_previsto']);
  if (update) updates.push(update);
}
for (const document of get('budgetInvestmentPositions')) {
  const update = zeroFields(document, ['currentValue', 'contributedValue'], ['referenceDate']);
  if (update) updates.push(update);
}
for (const document of get('monthlyBudgets')) {
  const update = zeroFields(document, [
    'openingBalance', 'expectedIncome', 'expectedInvoices', 'fixedExpenses', 'projectedFreeCash',
    'plannedInvestments', 'currentAvailable', 'committedBalance',
  ]);
  if (update) updates.push(update);
}

const allWrites = [...writes, ...updates];
const report = {
  mode: apply ? 'apply' : 'dry-run',
  projectId,
  householdId,
  archivedDocuments: archivedDocuments.length,
  archiveByCollection: Object.fromEntries([...new Set(archivedDocuments.map((document) => document.name.split('/').at(-2)))].map((collection) => [
    collection,
    archivedDocuments.filter((document) => document.name.split('/').at(-2) === collection).length,
  ])),
  additionalHistoryDocumentsToDelete: deleteDocuments.length - archivedDocuments.length,
  financialDocumentsToZero: updates.length,
  writes: allWrites.length,
};

if (!apply) {
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
  process.exit(0);
}

for (let offset = 0; offset < allWrites.length; offset += 200) {
  await client.post(`${root}:commit`, { writes: allWrites.slice(offset, offset + 200) });
}
process.stdout.write(`${JSON.stringify({ ...report, applied: true }, null, 2)}\n`);
