import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';

const require = createRequire(import.meta.url);
const auth = require('firebase-tools/lib/auth');
const apiv2 = require('firebase-tools/lib/apiv2');
const projectId = process.argv[2] || 'your-firebase-project';
const args = new Set(process.argv.slice(3));
const apply = args.has('--apply');
const confirmation = [...args].find((value) => value.startsWith('--confirm='))?.slice(10);
const input = [...args].find((value) => value.startsWith('--file='))?.slice(7) || 'C:/Users/a481569/Desktop/Pessoa 1/Planilha contas/wise-wallet-firebase-deploy/outputs/orcamento-familiar/orcamento-familiar-modelo.xlsx';
if (apply && confirmation !== projectId) throw new Error('exact-production-confirmation-required');
const authAccount = auth.getGlobalDefaultAccount();
if (!authAccount?.tokens?.refresh_token) throw new Error('firebase-login-required');
apiv2.setRefreshToken(authAccount.tokens.refresh_token);
const firestore = new apiv2.Client({ urlPrefix: 'https://firestore.googleapis.com', apiVersion: 'v1' });
const root = `/projects/${projectId}/databases/(default)/documents`;
const fullRoot = `projects/${projectId}/databases/(default)/documents`;

const decode = (value) => {
  if ('nullValue' in value) return null;
  if ('stringValue' in value) return value.stringValue;
  if ('booleanValue' in value) return value.booleanValue;
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return value.timestampValue;
  return undefined;
};
const decodeFields = (fields) => Object.fromEntries(Object.entries(fields || {}).map(([key, value]) => [key, decode(value)]));
const encode = (value) => {
  if (value === null || value === undefined) return { nullValue: null };
  if (Array.isArray(value)) return { arrayValue: { values: value.map(encode) } };
  if (typeof value === 'object') return { mapValue: { fields: Object.fromEntries(Object.entries(value).map(([key, nested]) => [key, encode(nested)])) } };
  if (typeof value === 'boolean') return { booleanValue: value };
  if (typeof value === 'string') return { stringValue: value };
  if (Number.isSafeInteger(value)) return { integerValue: String(value) };
  if (typeof value === 'number' && Number.isFinite(value)) return { doubleValue: value };
  throw new Error(`unsupported-firestore-value:${typeof value}`);
};
const mergeFields = (fields, patch) => ({ ...fields, ...Object.fromEntries(Object.entries(patch).map(([key, value]) => [key, encode(value)])) });
const cents = (value) => value == null ? null : Math.round(Number(value) * 100);
const normalize = (value) => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const now = new Date().toISOString();

async function list(collection) {
  const documents = [];
  let pageToken;
  do {
    const response = await firestore.get(`${root}/households/family-wallet/${collection}`, { queryParams: { pageSize: 300, ...(pageToken ? { pageToken } : {}) } });
    documents.push(...(response.body.documents || []));
    pageToken = response.body.nextPageToken;
  } while (pageToken);
  return documents.map((document) => ({ id: document.name.split('/').at(-1), fields: document.fields || {}, ...decodeFields(document.fields) }));
}

const reportText = execFileSync(process.execPath, ['scripts/import-family-budget-workbook.mjs', `--file=${input}`], { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
const workbook = JSON.parse(reportText);
if (workbook.unresolved.length) throw new Error(`workbook-has-unresolved-references:${workbook.unresolved.length}`);
const [existingAccounts, existingCards, existingRecurrences, existingInvestments] = await Promise.all([list('accounts'), list('cards'), list('recurrences'), list('investments')]);
const accountByName = new Map(existingAccounts.map((item) => [normalize(item.name), item]));
const cardByName = new Map(existingCards.map((item) => [normalize(item.name), item]));
const recurrenceBySource = new Map(existingRecurrences.filter((item) => item.sourceRecurrenceId).map((item) => [String(item.sourceRecurrenceId), item]));
const recurrenceByFingerprint = new Map(existingRecurrences.map((item) => [`${normalize(item.description)}|${item.kind}|${item.accountId || ''}|${item.cardId || ''}`, item]));
const investmentByName = new Map(existingInvestments.map((item) => [normalize(item.name), item]));
const accountMap = new Map();
const cardMap = new Map();
const writes = [];
const mappings = { accounts: [], cards: [], recurrences: [], incomes: [], investments: [] };
const put = (path, fields) => writes.push({ update: { name: `${fullRoot}/${path}`, fields } });

for (const item of workbook.accounts) {
  const current = accountByName.get(normalize(item.name)) || existingAccounts.find((candidate) => normalize(candidate.name).includes(normalize(item.name)) || normalize(item.name).includes(normalize(candidate.name)));
  const id = current?.id || item.id;
  accountMap.set(item.id, id);
  const patch = {
    schemaVersion: 1, version: Number(current?.version || 1), openingBalanceVersion: Number(current?.openingBalanceVersion || 1), currency: 'BRL', name: item.name,
    type: ({ Corrente: 'checking', Poupança: 'savings', Dinheiro: 'cash', Investimento: 'other' })[item.type] || current?.type || 'other',
    openingBalanceCents: cents(item.openingBalance) ?? Number(current?.openingBalanceCents || 0),
    balanceCents: cents(item.bankBalance) ?? Number(current?.balanceCents || 0),
    openingDate: item.openingDate || current?.openingDate || '', archivedAt: item.active === false ? now : null,
    holder: item.holder, bankBalanceCents: cents(item.bankBalance), bankCheckedAt: item.bankCheckedAt || now,
    conferenceDay: item.conferenceDay, observations: item.observations, sourceAccountId: item.id,
    importedFrom: 'orcamento-familiar-modelo.xlsx', updatedAt: now,
  };
  put(`households/family-wallet/accounts/${id}`, mergeFields(current?.fields || {}, patch));
  mappings.accounts.push({ sourceId: item.id, targetId: id, name: item.name, created: !current, bankBalance: item.bankBalance });
}

for (const item of workbook.cards) {
  const current = cardByName.get(normalize(item.name));
  const id = current?.id || item.id;
  const accountId = accountMap.get(item.accountId) || item.accountId || current?.accountId || '';
  cardMap.set(item.id, id);
  const patch = {
    name: item.name, holder: item.holder, accountId, limit: item.totalLimit ?? current?.limit ?? 0,
    closingDay: item.closingDay ?? 0, dueDay: item.dueDay ?? 0, availableFromBank: item.availableFromBank,
    usedFromBank: item.usedFromBank, bankCheckedAt: item.bankCheckedAt || now, currentInvoiceFromBank: item.currentInvoiceFromBank,
    invoiceCheckedAt: item.invoiceCheckedAt || now, active: item.active !== false, observations: item.observations,
    sourceCardId: item.id, importedFrom: 'orcamento-familiar-modelo.xlsx', updatedAt: now,
  };
  put(`households/family-wallet/cards/${id}`, mergeFields(current?.fields || {}, patch));
  mappings.cards.push({ sourceId: item.id, targetId: id, name: item.name, accountId, created: !current, availableFromBank: item.availableFromBank, currentInvoiceFromBank: item.currentInvoiceFromBank });
}

function writeRecurrence(item, kind) {
  const fingerprint = `${normalize(item.description)}|${kind}|${item.accountId || ''}|${item.cardId || ''}`;
  const current = recurrenceBySource.get(item.id) || recurrenceByFingerprint.get(fingerprint);
  const id = current?.id || item.id;
  const accountId = accountMap.get(item.accountId) || item.accountId || '';
  const cardId = cardMap.get(item.cardId) || item.cardId || '';
  const patch = {
    description: item.description, category: item.category || item.categoryName || '', subcategory: item.subcategory || '', amount: item.expectedAmount ?? 0,
    kind, owner: item.owner || '', accountId, cardId, frequency: item.frequency || 'monthly', dueDay: item.dueDay ?? item.receiveDay ?? null,
    startDate: item.startMonth ? `${item.startMonth}-01` : '', endDate: item.endMonth ? `${item.endMonth}-01` : '', variableAmount: item.variableAmount === true,
    active: item.active !== false, settledMonths: current?.settledMonths || [], sourceRecurrenceId: item.id, importedFrom: 'orcamento-familiar-modelo.xlsx', updatedAt: now,
    observations: item.observations || '', paymentMethod: item.paymentMethod || '', essential: item.essential, mandatory: item.mandatory,
  };
  put(`households/family-wallet/recurrences/${id}`, mergeFields(current?.fields || {}, patch));
  return { sourceId: item.id, targetId: id, description: item.description, kind, created: !current };
}
for (const item of workbook.recurringObligations) mappings.recurrences.push(writeRecurrence(item, item.kind || 'expense'));
for (const item of workbook.recurringIncomes) mappings.incomes.push(writeRecurrence(item, 'income'));

// These supporting tables remain separate from transactional collections so
// importing the base workbook cannot duplicate or rewrite historical entries.
for (const item of workbook.categories) {
  if (typeof item === 'string') continue;
  // Keep the workbook's parent/subcategory split in the same shape consumed
  // by the app, while retaining the original import fields for traceability.
  put(`households/family-wallet/budgetCategories/${item.id}`, mergeFields({}, {
    ...item,
    name: item.name || item.categoryName || '',
    subcategoria: item.subcategoria || item.subcategory || '',
    valor_previsto: item.valor_previsto ?? item.valorPrevisto ?? item.expectedAmount ?? 0,
    updatedAt: now,
    importedFrom: 'orcamento-familiar-modelo.xlsx',
  }));
}
for (const item of workbook.monthlyOccurrences) put(`households/family-wallet/recurrenceOccurrences/${item.id}`, mergeFields({}, { ...item, recurrenceId: item.recurrenceId, accountId: accountMap.get(item.accountId) || item.accountId, importedFrom: 'orcamento-familiar-modelo.xlsx', updatedAt: now }));
for (const item of workbook.monthlyBudgets) put(`households/family-wallet/monthlyBudgets/${item.month}`, mergeFields({}, { ...item, importedFrom: 'orcamento-familiar-modelo.xlsx', updatedAt: now }));
for (const item of workbook.investmentPositions) {
  const current = investmentByName.get(normalize(item.name));
  const id = current?.id || item.id;
  put(`households/family-wallet/budgetInvestmentPositions/${id}`, mergeFields({}, { ...item, importedFrom: 'orcamento-familiar-modelo.xlsx', updatedAt: now }));
  mappings.investments.push({ sourceId: item.id, targetId: id, name: item.name, created: !current, currentValue: item.currentValue });
}
for (const item of workbook.investmentMovements) put(`households/family-wallet/investmentMovements/${item.id}`, mergeFields({}, { ...item, sourceAccountId: accountMap.get(item.sourceAccountId) || item.sourceAccountId, destinationAccountId: accountMap.get(item.destinationAccountId) || item.destinationAccountId, importedFrom: 'orcamento-familiar-modelo.xlsx', updatedAt: now }));
for (const item of workbook.reconciliations) put(`households/family-wallet/reconciliations/${item.id}`, mergeFields({}, { ...item, accountId: accountMap.get(item.accountId) || item.accountId, importedFrom: 'orcamento-familiar-modelo.xlsx', updatedAt: now }));

const plan = { projectId, input, mode: apply ? 'apply' : 'dry-run', writes: writes.length, counts: workbook.counts, mappings, generatedAt: now };
const runId = `family-budget-import-${new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14)}`;
const backup = { runId, projectId, createdAt: now, source: input, existingAccounts, existingCards, existingRecurrences, existingInvestments };
await mkdir(resolve('work', 'migration'), { recursive: true });
const backupPath = resolve('work', 'migration', `${runId}-base-backup.json`);
await writeFile(backupPath, `${JSON.stringify(backup, null, 2)}\n`, { encoding: 'utf8' });
if (!apply) {
  console.log(JSON.stringify({ ...plan, writesPerformed: false, backupPath }, null, 2));
  process.exit(0);
}
for (let index = 0; index < writes.length; index += 450) {
  await firestore.post(`/projects/${projectId}/databases/(default)/documents:commit`, { writes: writes.slice(index, index + 450) });
}
console.log(JSON.stringify({ ...plan, writesPerformed: true, runId, backupPath }, null, 2));
