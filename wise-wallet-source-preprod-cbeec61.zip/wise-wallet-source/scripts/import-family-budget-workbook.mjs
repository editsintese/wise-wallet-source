// The spreadsheet runtime is bundled with Codex rather than installed in the app's node_modules.
import { FileBlob, SpreadsheetFile } from 'file:///C:/Users/a481569/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs';

const input = process.argv.find((value) => value.startsWith('--file='))?.slice(7) || 'C:/Users/a481569/Desktop/Pessoa 1/Planilha contas/Planilha Contas 2026.xlsx';
const writeRequested = process.argv.includes('--write');

function excelDate(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return value == null ? '' : String(value);
  const date = new Date(Date.UTC(1899, 11, 30) + value * 86400000);
  return date.toISOString().slice(0, 10);
}

function clean(value) {
  if (value == null) return '';
  return typeof value === 'string' ? value.trim() : value;
}

function isExample(value) {
  return typeof value === 'string' && /exemplo|ex\.?\s*:|preencha|teste|sample/i.test(value);
}

function numberValue(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  if (typeof value !== 'string' || !value.trim()) return null;
  const normalized = value.replace(/R\$\s*/i, '').replace(/\./g, '').replace(',', '.');
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(input));
const inspection = await workbook.inspect({ kind: 'workbook,sheet,table', maxChars: 120000, tableMaxRows: 500, tableMaxCols: 20, tableMaxCellChars: 160 });
const records = inspection.ndjson.split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
const tables = records.filter((record) => record.kind === 'table');
const bySheet = new Map(tables.map((table) => [table.sheet, table.values || []]));
const sheetNames = records.filter((record) => record.kind === 'sheet').map((record) => record.name);
const report = {
  input,
  mode: writeRequested ? 'write-requested' : 'dry-run',
  writesPerformed: false,
  sheets: sheetNames,
  recurringObligations: [],
  recurringIncomes: [],
  accounts: [],
  cards: [],
  cardPurchases: [],
  investmentSnapshots: [],
  investmentPositions: [],
  investmentMovements: [],
  monthlyOccurrences: [],
  monthlyBudgets: [],
  reconciliations: [],
  categories: [],
  unresolved: [],
  examples: [],
  duplicates: [],
};

const normalizeHeader = (value) => String(value ?? '')
  .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  .trim().toLowerCase().replace(/\s+/g, '_');

function objectRows(rows) {
  const headerIndex = rows.findIndex((row) => row.some((value) => {
    const key = normalizeHeader(value);
    return ['conta_id', 'cartao_id', 'recorrencia_id', 'categoria_id', 'descricao', 'competencia', 'investimento_id', 'movimento_id', 'conciliacao_id'].includes(key);
  }));
  if (headerIndex < 0) return [];
  const headers = (rows[headerIndex] || []).map(normalizeHeader);
  return rows.slice(headerIndex + 1).map((row, offset) => {
    const result = { _row: headerIndex + offset + 2 };
    headers.forEach((header, index) => { if (header) result[header] = clean(row[index]); });
    return result;
  }).filter((row) => Object.values(row).some((value) => value !== '' && value != null && value !== row._row));
}

const booleanValue = (value) => {
  if (typeof value === 'boolean') return value;
  const normalized = String(value ?? '').trim().toLowerCase();
  if (!normalized) return null;
  if (['sim', 's', 'true', '1', 'ativo'].includes(normalized)) return true;
  if (['nao', 'não', 'n', 'false', '0', 'inativo'].includes(normalized)) return false;
  return null;
};

const rowValue = (row, ...keys) => keys.map((key) => row[normalizeHeader(key)]).find((value) => value !== undefined) ?? '';
const rowNumber = (row, ...keys) => numberValue(rowValue(row, ...keys));
const rowDate = (row, ...keys) => excelDate(rowValue(row, ...keys));

const seen = new Map();
function addCardPurchase(item) {
  const fingerprint = [item.card, item.purchaseDate, item.description, item.amount, item.installment].join('|').toLowerCase();
  if (seen.has(fingerprint)) report.duplicates.push({ fingerprint, first: seen.get(fingerprint), duplicate: item });
  else seen.set(fingerprint, item);
  report.cardPurchases.push(item);
}

// New normalized base sheets. Empty cells intentionally remain empty/null so
// the corresponding values can be completed later in Wise.
const accountRows = objectRows(bySheet.get('Contas') || []);
for (const row of accountRows) {
  const id = String(rowValue(row, 'conta_id')).trim();
  const name = String(rowValue(row, 'nome')).trim();
  if (!id && !name) continue;
  report.accounts.push({
    source: 'Contas', row: row._row, id, name,
    type: String(rowValue(row, 'tipo')).trim(),
    holder: String(rowValue(row, 'titular')).trim(),
    openingBalance: rowNumber(row, 'saldo_inicial'),
    openingDate: rowDate(row, 'data_saldo_inicial'),
    bankBalance: rowNumber(row, 'saldo_atual_banco'),
    bankCheckedAt: rowDate(row, 'data_conferencia_saldo', 'data_conferencia'),
    conferenceDay: rowNumber(row, 'dia_conferencia'),
    active: booleanValue(rowValue(row, 'ativa')),
    observations: String(rowValue(row, 'observacoes')).trim(),
  });
}

const cardRows = objectRows(bySheet.get('Cartões') || []);
for (const row of cardRows) {
  const id = String(rowValue(row, 'cartao_id')).trim();
  const name = String(rowValue(row, 'nome')).trim();
  if (!id && !name) continue;
  report.cards.push({
    source: 'Cartões', row: row._row, id, name,
    holder: String(rowValue(row, 'titular')).trim(),
    accountId: String(rowValue(row, 'conta_pagamento_id')).trim(),
    totalLimit: rowNumber(row, 'limite_total'),
    availableFromBank: rowNumber(row, 'limite_disponivel_banco'),
    usedFromBank: rowNumber(row, 'limite_utilizado_calculado'),
    bankCheckedAt: rowDate(row, 'data_conferencia_limite'),
    currentInvoiceFromBank: rowNumber(row, 'fatura_atual_no_banco'),
    invoiceCheckedAt: rowDate(row, 'data_conferencia_fatura'),
    closingDay: rowNumber(row, 'dia_fechamento'),
    dueDay: rowNumber(row, 'dia_vencimento'),
    active: booleanValue(rowValue(row, 'ativo')),
    observations: String(rowValue(row, 'observacoes')).trim(),
  });
}

const categoryRows = objectRows(bySheet.get('Categorias') || []);
if (categoryRows.length) {
  report.categories = categoryRows.filter((row) => row.categoria_id || row.nome).map((row) => ({
    source: 'Categorias', row: row._row,
    id: String(rowValue(row, 'categoria_id')).trim(),
    name: String(rowValue(row, 'nome')).trim(),
    subcategory: String(rowValue(row, 'subcategoria')).trim(),
    kind: String(rowValue(row, 'tipo')).trim(),
    nature: String(rowValue(row, 'natureza')).trim(),
    active: booleanValue(rowValue(row, 'ativo')),
  }));
}

const obligationRows = objectRows(bySheet.get('Orçamento fixo') || []);
if (obligationRows.length) {
  for (const row of obligationRows) {
    const description = String(rowValue(row, 'subcategoria') || rowValue(row, 'descricao')).trim();
    if (!description) continue;
    report.recurringObligations.push({
      source: 'Orçamento fixo', row: row._row,
      id: String(rowValue(row, 'recorrencia_id')).trim(), description,
      categoryId: String(rowValue(row, 'categoria_id')).trim(),
      category: String(rowValue(row, 'descricao')).trim(),
      subcategory: String(rowValue(row, 'subcategoria')).trim(),
      categoryName: String(rowValue(row, 'descricao')).trim(),
      kind: String(rowValue(row, 'tipo')).trim().toLowerCase() === 'receita' ? 'income' : 'expense',
      nature: String(rowValue(row, 'natureza')).trim(),
      expectedAmount: rowNumber(row, 'valor_previsto'),
      variableAmount: booleanValue(rowValue(row, 'valor_variavel')),
      frequency: String(rowValue(row, 'periodicidade')).trim(),
      dueDay: rowNumber(row, 'dia_vencimento'),
      startMonth: String(rowValue(row, 'mes_inicio')).trim(),
      endMonth: String(rowValue(row, 'mes_fim')).trim(),
      accountId: String(rowValue(row, 'conta_pagamento_id')).trim(),
      cardId: String(rowValue(row, 'cartao_id')).trim(),
      owner: String(rowValue(row, 'responsavel')).trim(),
      essential: booleanValue(rowValue(row, 'essencial')),
      mandatory: booleanValue(rowValue(row, 'obrigatoria')),
      active: booleanValue(rowValue(row, 'ativa')),
      paymentMethod: String(rowValue(row, 'forma_pagamento')).trim(),
      observations: String(rowValue(row, 'observacoes')).trim(),
    });
  }
}

const incomeRows = objectRows(bySheet.get('Receitas recorrentes') || []);
for (const row of incomeRows) {
  const description = String(rowValue(row, 'descricao')).trim();
  if (!description) continue;
  report.recurringIncomes.push({
    source: 'Receitas recorrentes', row: row._row,
    id: String(rowValue(row, 'recorrencia_id')).trim(), description,
    category: String(rowValue(row, 'categoria')).trim(),
    expectedAmount: rowNumber(row, 'valor_previsto'),
    frequency: String(rowValue(row, 'periodicidade')).trim(),
    receiveDay: rowNumber(row, 'dia_recebimento'),
    accountId: String(rowValue(row, 'conta_destino_id')).trim(),
    owner: String(rowValue(row, 'responsavel')).trim(),
    nature: String(rowValue(row, 'natureza')).trim(),
    active: booleanValue(rowValue(row, 'ativa')),
    observations: String(rowValue(row, 'observacoes')).trim(),
  });
}

const occurrenceRows = objectRows(bySheet.get('Valores mensais') || []);
for (const row of occurrenceRows) {
  const recurrenceId = String(rowValue(row, 'recorrencia_id')).trim();
  if (!recurrenceId) continue;
  report.monthlyOccurrences.push({
    source: 'Valores mensais', row: row._row,
    id: String(rowValue(row, 'transaction_id')).trim() || `occ-${recurrenceId}-${row._row}`,
    recurrenceId,
    month: rowDate(row, 'competencia'),
    expectedAmount: rowNumber(row, 'valor_previsto'),
    actualAmount: rowNumber(row, 'valor_real'),
    dueDate: rowDate(row, 'vencimento'),
    status: String(rowValue(row, 'status')).trim(),
    paidAt: rowDate(row, 'data_pagamento'),
    accountId: String(rowValue(row, 'conta_pagamento_id')).trim(),
    transactionId: String(rowValue(row, 'transaction_id')).trim(),
    observations: String(rowValue(row, 'observacoes')).trim(),
  });
}

const budgetRows = objectRows(bySheet.get('Orçamento mensal') || []);
for (const row of budgetRows) {
  const month = rowDate(row, 'competencia');
  if (!month) continue;
  report.monthlyBudgets.push({
    source: 'Orçamento mensal', row: row._row, month,
    expectedIncome: rowNumber(row, 'receitas_previstas'), fixedExpenses: rowNumber(row, 'despesas_fixas'),
    expectedInvoices: rowNumber(row, 'faturas_previstas'), plannedInvestments: rowNumber(row, 'investimentos_planejados'),
    openingBalance: rowNumber(row, 'saldo_inicial'), currentAvailable: rowNumber(row, 'saldo_disponivel_atual'),
    committedBalance: rowNumber(row, 'saldo_comprometido'), projectedFreeCash: rowNumber(row, 'saldo_livre_projetado'),
    observations: String(rowValue(row, 'observacoes')).trim(),
  });
}

const positionRows = objectRows(bySheet.get('Posições investimentos') || []);
for (const row of positionRows) {
  const id = String(rowValue(row, 'investimento_id')).trim();
  if (!id) continue;
  report.investmentPositions.push({
    source: 'Posições investimentos', row: row._row, id,
    name: String(rowValue(row, 'nome')).trim(), institution: String(rowValue(row, 'instituicao')).trim(),
    type: String(rowValue(row, 'tipo')).trim(), contributedValue: rowNumber(row, 'valor_aportado'),
    currentValue: rowNumber(row, 'valor_atual'), referenceDate: rowDate(row, 'data_referencia'),
    active: booleanValue(rowValue(row, 'ativo')), observations: String(rowValue(row, 'observacoes')).trim(),
  });
}

const movementRows = objectRows(bySheet.get('Movimentos investimentos') || []);
for (const row of movementRows) {
  const id = String(rowValue(row, 'movimento_id')).trim();
  if (!id) continue;
  report.investmentMovements.push({
    source: 'Movimentos investimentos', row: row._row, id,
    investmentId: String(rowValue(row, 'investimento_id')).trim(), type: String(rowValue(row, 'tipo')).trim(),
    amount: rowNumber(row, 'valor'), date: rowDate(row, 'data'),
    sourceAccountId: String(rowValue(row, 'conta_origem_id')).trim(), destinationAccountId: String(rowValue(row, 'conta_destino_id')).trim(),
    transactionId: String(rowValue(row, 'transaction_id')).trim(), observations: String(rowValue(row, 'observacoes')).trim(),
  });
}

const reconciliationRows = objectRows(bySheet.get('Conciliação') || []);
for (const row of reconciliationRows) {
  const id = String(rowValue(row, 'conciliacao_id')).trim();
  if (!id) continue;
  report.reconciliations.push({
    source: 'Conciliação', row: row._row, id, accountId: String(rowValue(row, 'conta_id')).trim(), date: rowDate(row, 'data'),
    bankBalance: rowNumber(row, 'saldo_no_banco'), appBalance: rowNumber(row, 'saldo_no_app'), difference: rowNumber(row, 'diferenca'),
    status: String(rowValue(row, 'status')).trim(), reason: String(rowValue(row, 'motivo_diferenca')).trim(),
    adjustmentNeeded: booleanValue(rowValue(row, 'ajuste_necessario')), observations: String(rowValue(row, 'observacoes')).trim(),
  });
}

const hasNormalizedBase = accountRows.length || cardRows.length || obligationRows.length || incomeRows.length;
const control = hasNormalizedBase ? [] : (bySheet.get('Controle') || []);
const monthColumns = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
for (let rowIndex = 0; rowIndex < control.length; rowIndex += 1) {
  const row = control[rowIndex] || [];
  const section = clean(row[1]);
  if (section !== 'Entrada' && section !== 'Saída') continue;
  const header = control[rowIndex + 1] || [];
  if (clean(header[1]) !== 'Categoria') continue;
  const kind = section === 'Entrada' ? 'income' : 'expense';
  for (let dataIndex = rowIndex + 2; dataIndex < control.length; dataIndex += 1) {
    const data = control[dataIndex] || [];
    const description = clean(data[2]);
    if (!description || String(description).startsWith('Saldo -')) break;
    if (isExample(description)) report.examples.push({ sheet: 'Controle', row: dataIndex + 1, value: description });
    monthColumns.forEach((monthName, monthIndex) => {
      const amount = numberValue(data[3 + monthIndex]);
      if (amount == null || amount === 0) return;
      report.recurringObligations.push({ source: 'Controle', row: dataIndex + 1, description, category: clean(data[1]) || 'Não informada', kind, month: `2026-${String(monthIndex + 1).padStart(2, '0')}`, expectedAmount: amount, accountId: '', dueDay: null });
    });
  }
}

for (const sheetName of sheetNames.filter((name) => name.startsWith('Cartão - '))) {
  const rows = bySheet.get(sheetName) || [];
  for (let index = 2; index < rows.length; index += 1) {
    const row = rows[index] || [];
    const card = clean(row[1]);
    const description = clean(row[4]);
    const amount = numberValue(row[5]);
    if (!card || !description || amount == null) continue;
    const item = { source: sheetName, card, category: clean(row[2]), purchaseDate: excelDate(row[3]), description, amount, installment: clean(row[6]) };
    if (isExample(description) || isExample(card)) report.examples.push({ sheet: sheetName, row: index + 1, value: description || card });
    addCardPurchase(item);
  }
}

const investment = bySheet.get('Investimento') || [];
const investmentMonths = ['Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
for (let index = 4; index < investment.length; index += 1) {
  const row = investment[index] || [];
  const institution = clean(row[1]);
  const type = clean(row[2]);
  if (!institution || institution === 'Total') continue;
  investmentMonths.forEach((monthName, monthIndex) => {
    const value = numberValue(row[3 + monthIndex]);
    if (value == null || value === 0) return;
    report.investmentSnapshots.push({ source: 'Investimento', row: index + 1, institution, type, month: `2026-${String(monthIndex + 2).padStart(2, '0')}`, value });
  });
}

if (!categoryRows.length) {
  const categories = bySheet.get('Categorias') || [];
  for (let index = 0; index < categories.length; index += 1) {
    const row = categories[index] || [];
    const value = clean(row[1] ?? row[0]);
    if (!value || value === 'Categoria' || value === 'Categorias') continue;
    report.categories.push(value);
    if (isExample(value)) report.examples.push({ sheet: 'Categorias', row: index + 1, value });
  }
}

const accountIds = new Set(report.accounts.map((item) => item.id).filter(Boolean));
const cardIds = new Set(report.cards.map((item) => item.id).filter(Boolean));
report.unresolved.push(...report.recurringObligations.flatMap((item) => [
  ...(!item.accountId && !item.cardId ? [{ source: item.source, row: item.row, field: 'accountId|cardId', description: item.description }] : []),
  ...(item.accountId && accountIds.size && !accountIds.has(item.accountId) ? [{ source: item.source, row: item.row, field: 'accountId', value: item.accountId, description: item.description }] : []),
  ...(item.cardId && cardIds.size && !cardIds.has(item.cardId) ? [{ source: item.source, row: item.row, field: 'cardId', value: item.cardId, description: item.description }] : []),
]));
report.unresolved.push(...report.recurringIncomes.filter((item) => item.accountId && accountIds.size && !accountIds.has(item.accountId)).map((item) => ({ source: item.source, row: item.row, field: 'accountId', value: item.accountId, description: item.description })));
report.unresolved.push(...report.cards.filter((item) => item.accountId && accountIds.size && !accountIds.has(item.accountId)).map((item) => ({ source: item.source, row: item.row, field: 'accountId', value: item.accountId, description: item.name })));
const counts = { accounts: report.accounts.length, cards: report.cards.length, recurringObligations: report.recurringObligations.length, recurringIncomes: report.recurringIncomes.length, monthlyOccurrences: report.monthlyOccurrences.length, monthlyBudgets: report.monthlyBudgets.length, cardPurchases: report.cardPurchases.length, investmentSnapshots: report.investmentSnapshots.length, investmentPositions: report.investmentPositions.length, investmentMovements: report.investmentMovements.length, reconciliations: report.reconciliations.length, categories: report.categories.length, unresolved: report.unresolved.length, examples: report.examples.length, duplicates: report.duplicates.length };
console.log(JSON.stringify({ ...report, counts }, null, 2));
if (writeRequested) console.error('Prévia concluída. Nenhuma gravação foi feita: o vínculo com Firestore exige revisão explícita do mapeamento e da conta autenticada.');
