import {createRequire} from 'node:module';
import {readFile} from 'node:fs/promises';

const require=createRequire(import.meta.url),auth=require('firebase-tools/lib/auth'),apiv2=require('firebase-tools/lib/apiv2');
const [projectId,backupPath,...flags]=process.argv.slice(2),confirmation=flags.find(value=>value.startsWith('--confirm='))?.slice(10);
if(projectId!=='your-firebase-project'||confirmation!==projectId||!backupPath)throw new Error('exact-production-confirmation-required');
const snapshot=JSON.parse(await readFile(backupPath,'utf8'));if(snapshot.projectId!==projectId||snapshot.schemaVersion!==1||!Array.isArray(snapshot.documents)||!Array.isArray(snapshot.addedPaths))throw new Error('invalid-rollback-snapshot');
const account=auth.getGlobalDefaultAccount();if(!account?.tokens?.refresh_token)throw new Error('firebase-login-required');apiv2.setRefreshToken(account.tokens.refresh_token);
const client=new apiv2.Client({urlPrefix:'https://firestore.googleapis.com',apiVersion:'v1'}),root=`projects/${projectId}/databases/(default)/documents`,writes=[];
for(const path of snapshot.addedPaths)writes.push({delete:`${root}/${path}`});
if(!snapshot.householdExisted)writes.push({delete:`${root}/households/family-wallet`});
for(const document of snapshot.documents)writes.push({update:document});
await client.post(`/projects/${projectId}/databases/(default)/documents:commit`,{writes});
process.stdout.write(`${JSON.stringify({projectId,runId:snapshot.runId,restoredDocuments:snapshot.documents.length,deletedAddedDocuments:snapshot.addedPaths.length},null,2)}\n`);
