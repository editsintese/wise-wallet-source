import assert from 'node:assert/strict';
import { calculateFinanceSummary } from '../app/finance-summary.ts';

const base = { category: 'Teste', owner: 'Família' };
const transactions = [
  { ...base, id: 'income', description: 'Salário', amount: 5000, kind: 'income', status: 'realized', rawDate: '2026-09-02', paidAt: '2026-09-02' },
  { ...base, id: 'expense', description: 'Mercado', amount: 400, kind: 'expense', status: 'realized', rawDate: '2026-09-02', paidAt: '2026-09-02' },
  { ...base, id: 'future-current', description: 'Conta prevista', amount: 300, kind: 'expense', status: 'planned', rawDate: '2026-09-20' },
  { ...base, id: 'installment', description: 'Parcela', amount: 200, kind: 'expense', status: 'planned', rawDate: '2026-10-10', cardId: 'card', installmentNumber: 2, installmentCount: 3 },
  { ...base, id: 'archived', description: 'Ignorar', amount: 999, kind: 'expense', status: 'planned', rawDate: '2026-10-10', archived: true },
];
const recurrences = [
  { description: 'Aluguel', amount: 1000, kind: 'expense', startDate: '2026-01-01', settledMonths: ['2026-09'] },
  { description: 'Receita recorrente', amount: 100, kind: 'income', startDate: '2026-10-01', settledMonths: [] },
];

const summary = calculateFinanceSummary(transactions, recurrences, '2026-09-02');
assert.equal(summary.realizedIncomeCents, 500000);
assert.equal(summary.realizedExpenseCents, 40000);
assert.equal(summary.projectedBalanceCents, 430000, 'resultado atual = realizado menos previsão ainda pendente');
assert.equal(summary.nextPlannedIncomeCents, 10000);
assert.equal(summary.nextPlannedExpenseCents, 219900, 'arquivamento preserva a previsão, além de parcela e recorrência');
assert.equal(summary.nextMonthProjectedCents, -209900);
assert.equal(summary.nextMonthTargetDate, '2026-10-31');

const settledToday = calculateFinanceSummary([
  { ...base, id: 'settled', description: 'Conta antecipada', amount: 80, kind: 'expense', status: 'realized', rawDate: '2026-10-10', paidAt: '2026-09-02' },
], [], '2026-09-02');
assert.equal(settledToday.realizedExpenseCents, 8000, 'ao realizar uma previsão hoje, a data de baixa deve alimentar o resumo do mês atual');

console.log('Finance summary checks passed.');
