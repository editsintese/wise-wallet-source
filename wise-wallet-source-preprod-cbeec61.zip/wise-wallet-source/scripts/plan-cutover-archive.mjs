import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const require = createRequire(import.meta.url);
const auth = require('firebase-tools/lib/auth');
const apiv2 = require('firebase-tools/lib/apiv2');
const projectId = process.argv[2] || 'your-firebase-project';
const cutoverDate = [...process.argv].find((value) => value.startsWith('--cutover-date='))?.slice(15) || '2026-08-31';
if (!/^\d{4}-\d{2}-\d{2}$/.test(cutoverDate)) throw new Error('valid-cutover-date-required');
const account = auth.getGlobalDefaultAccount();
if (!account?.tokens?.refresh_token) throw new Error('firebase-login-required');
apiv2.setRefreshToken(account.tokens.refresh_token);
const client = new apiv2.Client({ urlPrefix: 'https://firestore.googleapis.com', apiVersion: 'v1' });
const root = `/projects/${projectId}/databases/(default)/documents`;
const decode = (value) => {
  if ('nullValue' in value) return null;
  if ('stringValue' in value) return value.stringValue;
  if ('booleanValue' in value) return value.booleanValue;
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return value.timestampValue;
  return undefined;
};
const fields = (data) => Object.fromEntries(Object.entries(data || {}).map(([key, value]) => [key, decode(value)]));
async function list(collection) {
  const documents = [];
  let pageToken;
  do {
    const response = await client.get(`${root}/households/family-wallet/${collection}`, { queryParams: { pageSize: 300, ...(pageToken ? { pageToken } : {}) } });
    documents.push(...(response.body.documents || []));
    pageToken = response.body.nextPageToken;
  } while (pageToken);
  return documents.map((document) => ({ id: document.name.split('/').at(-1), ...fields(document.fields) }));
}
const transactions = await list('transactions');
const payments = await list('cardPayments');
const dateOf = (item) => String(item.competenceDate || item.transactionDate || item.dueDate || item.purchaseDate || '');
const historical = transactions.filter((item) => !item.archivedAt && !item.archived && dateOf(item) && dateOf(item) <= cutoverDate);
const future = transactions.filter((item) => !item.archivedAt && !item.archived && dateOf(item) > cutoverDate);
const groups = new Map();
for (const item of transactions) {
  const group = String(item.installmentGroupId || '');
  if (!group) continue;
  const current = groups.get(group) || { groupId: group, count: 0, historical: [], future: [], descriptions: new Set(), cards: new Set() };
  current.count += 1; current.descriptions.add(String(item.description || '')); if (item.cardId) current.cards.add(String(item.cardId));
  if (dateOf(item) <= cutoverDate) current.historical.push(item.id); else current.future.push(item.id);
  groups.set(group, current);
}
const crossingGroups = [...groups.values()].filter((item) => item.historical.length && item.future.length).map((item) => ({ ...item, descriptions: [...item.descriptions], cards: [...item.cards] }));
const report = {
  projectId, householdId: 'family-wallet', cutoverDate, mode: 'read-only', generatedAt: new Date().toISOString(),
  counts: { transactions: transactions.length, historicalTransactions: historical.length, futureTransactions: future.length, crossingInstallmentGroups: crossingGroups.length, historicalCardPayments: payments.filter((item) => String(item.competence || '') <= cutoverDate.slice(0, 7)).length },
  historical: historical.map((item) => ({ id: item.id, date: dateOf(item), description: item.description, amount: item.amountCents != null ? Number(item.amountCents) / 100 : item.amount, kind: item.type || item.kind, accountId: item.accountId || '', cardId: item.cardId || '', installmentGroupId: item.installmentGroupId || '' })),
  crossingInstallmentGroups: crossingGroups,
};
await mkdir(resolve('work', 'migration'), { recursive: true });
const output = resolve('work', 'migration', `cutover-plan-${cutoverDate}.json`);
await writeFile(output, `${JSON.stringify(report, null, 2)}\n`, { encoding: 'utf8' });
console.log(JSON.stringify({ ...report, output }, null, 2));
