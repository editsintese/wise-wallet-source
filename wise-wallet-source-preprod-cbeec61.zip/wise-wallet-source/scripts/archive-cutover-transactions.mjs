import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const require = createRequire(import.meta.url);
const auth = require('firebase-tools/lib/auth');
const apiv2 = require('firebase-tools/lib/apiv2');
const projectId = process.argv[2] || 'your-firebase-project';
const args = new Set(process.argv.slice(3));
const apply = args.has('--apply');
const keepManualSeptember = args.has('--keep-manual-september');
const confirmation = [...args].find((value) => value.startsWith('--confirm='))?.slice(10);
const cutoverDate = [...args].find((value) => value.startsWith('--cutover-date='))?.slice(15) || '2026-08-31';
if (apply && confirmation !== projectId) throw new Error('exact-production-confirmation-required');
const account = auth.getGlobalDefaultAccount();
if (!account?.tokens?.refresh_token) throw new Error('firebase-login-required');
apiv2.setRefreshToken(account.tokens.refresh_token);
const client = new apiv2.Client({ urlPrefix: 'https://firestore.googleapis.com', apiVersion: 'v1' });
const root = `/projects/${projectId}/databases/(default)/documents`;
const fullRoot = `projects/${projectId}/databases/(default)/documents`;
const decode = (value) => {
  if ('nullValue' in value) return null;
  if ('stringValue' in value) return value.stringValue;
  if ('booleanValue' in value) return value.booleanValue;
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return value.timestampValue;
  return undefined;
};
const fields = (data) => Object.fromEntries(Object.entries(data || {}).map(([key, value]) => [key, decode(value)]));
const encode = (value) => value === null || value === undefined ? { nullValue: null } : typeof value === 'boolean' ? { booleanValue: value } : typeof value === 'string' ? { stringValue: value } : Number.isSafeInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
const mergeFields = (source, patch) => ({ ...source, ...Object.fromEntries(Object.entries(patch).map(([key, value]) => [key, encode(value)])) });
async function list() {
  const documents = [];
  let pageToken;
  do {
    const response = await client.get(`${root}/households/family-wallet/transactions`, { queryParams: { pageSize: 300, ...(pageToken ? { pageToken } : {}) } });
    documents.push(...(response.body.documents || []));
    pageToken = response.body.nextPageToken;
  } while (pageToken);
  return documents.map((document) => ({ id: document.name.split('/').at(-1), name: document.name, fields: document.fields || {}, ...fields(document.fields) }));
}
const transactions = await list();
const dateOf = (item) => String(item.competenceDate || item.transactionDate || item.dueDate || item.purchaseDate || '');
const isImported = (item) => item.imported === true || item.clientGeneration === 'imported' || Boolean(item.source) || Boolean(item.importedFrom) || Boolean(item.migrationRun);
const targets = transactions.filter((item) => {
  if (item.archivedAt || item.archived || !dateOf(item)) return false;
  if (keepManualSeptember) return !(dateOf(item).startsWith('2026-09') && !isImported(item));
  return dateOf(item) <= cutoverDate;
});
const runId = keepManualSeptember ? 'cutover-archive-keep-manual-september' : `cutover-archive-${cutoverDate}`;
const backupPath = resolve('work', 'migration', `${runId}-backup.json`);
await mkdir(resolve('work', 'migration'), { recursive: true });
await writeFile(backupPath, `${JSON.stringify({ runId, projectId, cutoverDate, createdAt: new Date().toISOString(), documents: targets }, null, 2)}\n`, { encoding: 'utf8' });
const writes = targets.map((item) => ({ update: { name: `${fullRoot}/households/family-wallet/transactions/${item.id}`, fields: mergeFields(item.fields, { archived: true, archivedAt: new Date().toISOString(), archivedReason: 'cutover-2026-08-31', ...(Number.isSafeInteger(item.version) ? { version: item.version + 1 } : {}) }) } }));
if (!apply) { console.log(JSON.stringify({ projectId, cutoverDate, keepManualSeptember, mode: 'dry-run', targets: targets.length, backupPath, writesPerformed: false }, null, 2)); process.exit(0); }
for (let index = 0; index < writes.length; index += 450) await client.post(`/projects/${projectId}/databases/(default)/documents:commit`, { writes: writes.slice(index, index + 450) });
console.log(JSON.stringify({ projectId, cutoverDate, keepManualSeptember, mode: 'apply', targets: targets.length, backupPath, writesPerformed: true }, null, 2));
