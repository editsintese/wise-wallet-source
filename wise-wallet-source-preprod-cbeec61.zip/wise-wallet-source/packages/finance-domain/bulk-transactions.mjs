import {civilDate} from './index.mjs';
/** Stable, non-secret selection image shared by the web client and server. */
export function bulkSnapshot(data){
 const canonical=data.schemaVersion===1;
 const amountCents=canonical?data.amountCents:Math.round(data.amount*100);
 if(!Number.isSafeInteger(amountCents)||amountCents<=0||(!canonical&&(typeof data.amount!=='number'||Math.abs(data.amount-amountCents/100)>1e-7)))throw Error('invalid-amount');
 const field=value=>value==null?'':String(value);
 return {schema:canonical?'canonical':'legacy',version:canonical?data.version:null,bulkRevision:data.bulkRevision??0,description:field(data.description||''),category:field(data.category||'Sem categoria'),subcategory:field(data.subcategory||data.subcategoria||''),owner:field(data.owner||'Família'),amountCents,kind:field(canonical?data.type:data.kind),status:field(data.status),accountId:field(data.accountId),date:field(canonical?(data.competenceDate||data.dueDate||data.purchaseDate):data.transactionDate||data.rawDate),purchaseDate:field(data.purchaseDate||data.transactionDate||''),settlementDate:field(canonical?data.settlementDate:data.paidAt),archived:canonical?data.archivedAt!=null:data.archived===true||data.archivedAt!=null};
}
export function bulkBlockReason(action,data){
 if(data.isRecurrenceForecast||String(data.id||'').startsWith('virtual-recurrence-'))return 'virtual';
 if(data.cardId)return 'card';
 if(data.recurrenceId)return 'recurrence';
 if(data.investmentId)return 'investment';
 if(data.deletedAt!=null||data.status==='cancelled')return 'cancelled';
 if(data.schemaVersion!=null&&data.schemaVersion!==1)return 'invalid-record';
 if(data.schemaVersion!==1&&(data.amountCents!=null||data.type!=null||data.currency!=null||data.version!=null))return 'mixed-schema';
 let snapshot;try{snapshot=bulkSnapshot(data);}catch{return 'invalid-record';}
 if(!['income','expense'].includes(snapshot.kind)||!['realized','planned'].includes(snapshot.status)||!Number.isSafeInteger(snapshot.bulkRevision)||snapshot.bulkRevision<0||snapshot.bulkRevision>=Number.MAX_SAFE_INTEGER)return 'invalid-record';
 if(snapshot.schema==='canonical'&&(data.currency!=='BRL'||!Number.isSafeInteger(snapshot.version)||snapshot.version<1||snapshot.version>=Number.MAX_SAFE_INTEGER))return 'invalid-record';
 if(action==='pay'){
  try{civilDate(snapshot.date);}catch{return 'invalid-record';}
  if(snapshot.settlementDate)return 'invalid-record';
  if(snapshot.archived)return 'archived';
  if(snapshot.status!=='planned')return 'already-realized';
  if(data.historicalOnly===true||data.balanceImpact===false||!snapshot.accountId)return 'no-cash-account';
 }else if(action==='archive'&&snapshot.archived)return 'already-archived';
 else if(action==='restore'&&!snapshot.archived)return 'not-archived';
 else if(!['archive','restore'].includes(action))return 'invalid-action';
 return null;
}

/** Exact reviewed group image; every installment participates in concurrency checking. */
export function manualInstallmentReview(rows){return rows.map(row=>({id:String(row.id),snapshot:bulkSnapshot(row),number:row.installmentNumber,count:row.installmentCount,groupId:row.installmentGroupId,manualRevision:row.manualRevision??0,manualEntryId:row.manualEntryId??null})).sort((a,b)=>a.id.localeCompare(b.id));}
