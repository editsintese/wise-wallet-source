// Canonical primitives. No Firebase, local timezone, locale coercion or UI dependency.
export function assertCents(value) {
  if (!Number.isSafeInteger(value)) throw new RangeError('invalid-cents');
  return value;
}

export function parseBRL(text) {
  // Explicit pt-BR decimal comma. Group separators require a decimal part.
  if (typeof text !== 'string' || !/^-?(?:\d+|\d{1,3}(?:\.\d{3})+),\d{1,2}$|^-?\d+$/.test(text)) {
    throw new TypeError('invalid-brl');
  }
  const negative = text.startsWith('-');
  const [whole, fraction = ''] = text.replace('-', '').replaceAll('.', '').split(',');
  const absolute = BigInt(whole) * 100n + BigInt(fraction.padEnd(2, '0'));
  return assertCents(Number(negative ? -absolute : absolute));
}

export function sumCents(values) {
  const total = values.reduce((sum, value) => sum + BigInt(assertCents(value)), 0n);
  return assertCents(Number(total));
}

function daysInMonth(year, month) {
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  return [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
}

export function civilDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new TypeError('invalid-civil-date');
  const [year, month, day] = value.split('-').map(Number);
  if (year < 1 || month < 1 || month > 12 || day < 1 || day > daysInMonth(year, month)) throw new RangeError('invalid-civil-date');
  return value;
}

export function addMonths(anchorDate, offset) {
  civilDate(anchorDate);
  if (!Number.isSafeInteger(offset)) throw new RangeError('invalid-month-offset');
  const [year, month, day] = anchorDate.split('-').map(Number);
  const index = year * 12 + month - 1 + offset;
  if (!Number.isSafeInteger(index) || index < 12 || index >= 120000) throw new RangeError('date-out-of-range');
  const nextYear = Math.floor(index / 12);
  const nextMonth = index % 12 + 1;
  return `${String(nextYear).padStart(4, '0')}-${String(nextMonth).padStart(2, '0')}-${String(Math.min(day, daysInMonth(nextYear, nextMonth))).padStart(2, '0')}`;
}

export function splitInstallments(total, count) {
  assertCents(total);
  if (total < 0 || !Number.isInteger(count) || count < 1 || count > 360) throw new RangeError('invalid-installments');
  const quotient = Number(BigInt(total) / BigInt(count));
  const remainder = Number(BigInt(total) % BigInt(count));
  return Array.from({ length: count }, (_, index) => quotient + (index < remainder ? 1 : 0));
}

/** Weekly dates are anchored to the original civil date and never derived from settlement. */
export function weeklyDatesForMonth(startDate, month, endDate = '') {
  civilDate(startDate);
  if (typeof month !== 'string' || !/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) throw new TypeError('invalid-month');
  const first=civilDate(`${month}-01`);
  if(endDate){civilDate(endDate);if(endDate<startDate)throw new RangeError('invalid-end-date');}
  const startMs=Date.parse(`${startDate}T00:00:00Z`),firstMs=Date.parse(`${first}T00:00:00Z`),week=7*24*60*60*1000;
  const endOfMonth=new Date(firstMs);endOfMonth.setUTCMonth(endOfMonth.getUTCMonth()+1);const exclusive=endOfMonth.getTime();
  const endMs=endDate?Date.parse(`${endDate}T00:00:00Z`):Infinity;
  let cursor=startMs+Math.max(0,Math.ceil((firstMs-startMs)/week))*week;const dates=[];
  while(cursor<exclusive&&cursor<=endMs){dates.push(new Date(cursor).toISOString().slice(0,10));cursor+=week;}
  return dates;
}
